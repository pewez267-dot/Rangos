# Fantastic Shortcuts — Forge 1.20.1

Sistema avanzado de reemplazo y simplificación de comandos, de la familia visual de
**FantasticCrates / FantasticSpawners**. Permite a los administradores definir aliases
cortos para cualquier comando registrado, con argumentos dinámicos, integración real con
LuckPerms (sin elevación de privilegios), reemplazo del comando original en el
autocompletado y auditoría completa.

- **Mod ID:** `fantasticshortcuts` · **Forge** 1.20.1 (47.2.0) · **Java** 17
- **Build:** `./gradlew build`

## Comandos (exactamente cuatro)

| Comando | Acción |
|---|---|
| `/fshortcuts` | Abre la GUI de gestión |
| `/fshortcuts create` | Abre el editor para un shortcut nuevo |
| `/fshortcuts edit` | Abre la GUI (selecciona y pulsa Editar) |
| `/fshortcuts delete` | Abre la GUI (selecciona y pulsa Eliminar, con confirmación) |

Todos requieren nivel de permiso `2` (operador) y se validan server-side.

## GUI

`MenuType` + `AbstractContainerMenu` + `AbstractContainerScreen` (que extiende `Screen`,
por lo que conserva el estilo de la familia). Pantalla principal con búsqueda en tiempo
real, lista con scroll y botones Crear / Editar / Eliminar (confirmación). Editor por
pestañas: **General**, **Comando Original** (selector que lee el `CommandDispatcher` real),
**Shortcut** (alias + `{args}`) y **Replace**.

## Ejecución y seguridad (LuckPerms)

Los aliases **no** se registran en el dispatcher del servidor: se interceptan con el
`CommandEvent` de Forge. Cuando un jugador ejecuta un alias:

1. Se resuelve el comando original (sustituyendo `{args}`).
2. Se verifica el permiso **igual que si el jugador hubiera escrito el original**
   (`canUse` del nodo Brigadier contra el `CommandSourceStack` del propio jugador — refleja
   op-level / LuckPerms).
3. Solo si tiene permiso, se ejecuta con `performPrefixedCommand` en el **contexto del
   propio jugador**.

Nunca se ejecuta como consola ni como OP temporal; nunca se eleva, modifica ni se hace
bypass de permisos. Hay además un guard anti-recursión (alias→alias) para no provocar crash.

## Replace Original Command

Por jugador, se reenvía un `ClientboundCommandsPacket` con el árbol filtrado a sus
permisos, **quitando** los originales marcados como `replace` y **añadiendo** los aliases
(con `redirect` al original para heredar sus argumentos/sugerencias cuando se usa `{args}`).
Solo cambia lo que ve el cliente; el servidor conserva su árbol completo. Si el jugador no
tiene permiso para el original, no ve ni el original ni el alias.

> Funciona también para clientes vanilla (sin el mod): el paquete es vanilla y la ejecución
> es server-side. Solo el GUI de administración requiere el mod en el cliente.

## Persistencia, config y auditoría (`config/fantasticshortcuts/`)

- `shortcuts.json` — definiciones (Gson, escritura **asíncrona y atómica**, thread-safe).
- `config.toml` — `ForgeConfigSpec` (`extra_args_behavior`, `show_conflict_warnings`,
  `audit_enabled`, `command_cache_size`, `cache_refresh_on_reload`).
- `audit/audit.log` — eventos con timestamp ISO-8601 UTC (created/edited/deleted/used/
  denied/conflict/invalid), escritura asíncrona.

Caché en memoria `HashMap<alias, Shortcut>` para resolución O(1); se reconstruye al cargar
y en cada CRUD.

## Variables dinámicas

`{args}` en el comando original captura lo que el jugador escriba tras el alias
(`/teleport {args}` + alias `/tp` → `/tp Steve` ejecuta `/teleport Steve`). Sin `{args}`,
los argumentos extra se ignoran o se deniegan según `extra_args_behavior`.


## Cambios

### 1.0.1 — Corrección: los shortcuts desaparecían tras usar uno

**Síntoma:** después de ejecutar un shortcut, todos los demás aliases dejaban de
aparecer (autocompletado / árbol de comandos del cliente) hasta volver a entrar,
reaparecer o cambiar de dimensión.

**Causa:** los aliases solo viven en el árbol de comandos *del cliente*
(`ClientboundCommandsPacket`), que se enviaba al entrar, reaparecer, cambiar de
dimensión y al crear/editar/eliminar. Cuando un jugador usaba un shortcut, el comando
resuelto (o el procesamiento posterior de vanilla) reenviaba al cliente el árbol de
comandos normal del servidor — **sin** los aliases —, sobrescribiendo el árbol
modificado. Nada volvía a inyectar los aliases tras el uso.

**Solución:** tras ejecutar un shortcut, `ShortcutExecutor` vuelve a enviar el árbol
modificado del jugador (`ClientTreeModifier.sendModifiedTree`), encolado en el hilo del
servidor para que se aplique *después* de cualquier reenvío de vanilla. Así todos los
shortcuts siguen visibles después de cada uso. El arreglo no toca la seguridad ni los
permisos: se ejecuta exactamente igual que antes, solo se restaura la visibilidad.


### 1.0.2 — Corrección REAL del bug (los shortcuts seguían desapareciendo)

**Por que 1.0.1 no bastó:** en 1.0.1 reenviaba el árbol de comandos *una sola vez*, justo
después de ejecutar el shortcut. Pero el árbol no siempre se sobrescribe en ese instante:
**LuckPerms** (y otras causas: cambio de OP, `/reload`) recalcula los permisos y reenvía el
árbol del servidor **de forma asíncrona, unos ticks después**. Ese reenvío tardío —sin los
aliases— llegaba *después* de mi reenvío y volvía a borrar los shortcuts.

**Solución definitiva (Mixin):** se intercepta `Commands.sendCommands(ServerPlayer)`, el único
método por el que vanilla/Forge/LuckPerms reenvían el árbol de comandos al cliente. Mediante
un Mixin con inyección en `TAIL`, justo después de que vanilla envía su árbol (sin aliases),
se envía encima nuestro árbol modificado (`ClientTreeModifier.sendModifiedTree`). Así, **cualquier**
resincronización —login, respawn, cambio de dimensión, OP/de-OP, `/reload`, recálculo de
permisos de LuckPerms— termina siempre con los aliases presentes y respetando los permisos
actuales del jugador. El dispatcher del servidor no se toca: la seguridad no cambia.

Notas técnicas: se añadió el plugin MixinGradle y el processor de Mixin para generar el refmap
(`fantasticshortcuts.refmap.json`), y el `MixinConfigs` en el manifest. El parche puntual de
1.0.1 en `ShortcutExecutor` se eliminó por quedar cubierto (y superado) por el Mixin.
