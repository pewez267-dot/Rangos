package com.fantasticshortcuts.mixin;

import com.fantasticshortcuts.brigadier.ClientTreeModifier;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Keeps shortcut aliases present in the client command tree no matter what triggers a
 * command-tree sync.
 *
 * <p>Shortcut aliases live only in the per-player client command tree (sent via
 * {@code ClientboundCommandsPacket}). Vanilla resends that tree — <em>without</em> our
 * aliases — from {@link Commands#sendCommands(ServerPlayer)} on login, op changes,
 * {@code /reload}, and whenever LuckPerms recalculates a player's permissions (which can
 * happen asynchronously, a few ticks after a command runs). Every such resend would make
 * all shortcuts "disappear" from tab-completion until the player relogged.</p>
 *
 * <p>By injecting at the {@code TAIL} of {@code sendCommands}, immediately after vanilla
 * has sent its (alias-less) tree, we send our modified tree on top. The client always ends
 * up with the alias-enriched tree, and because {@link ClientTreeModifier#sendModifiedTree}
 * re-evaluates the player's current permissions, the result also stays correct after
 * permission changes. The server dispatcher is never touched, so security is unaffected.</p>
 */
@Mixin(Commands.class)
public abstract class CommandsMixin {

    @Inject(method = "sendCommands", at = @At("TAIL"))
    private void fantasticshortcuts$appendShortcutAliases(final ServerPlayer player, final CallbackInfo ci) {
        ClientTreeModifier.sendModifiedTree(player);
    }
}
