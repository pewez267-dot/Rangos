#!/usr/bin/env bash
# Headless emulator test runner — verifica el núcleo (CPU/PPU) SIN Minecraft.
# Requiere solo un JDK 17+ en el PATH (javac/java).
#
# Uso:  cd emulator-tests && ./run-tests.sh
set -e

HERE="$(cd "$(dirname "$0")" && pwd)"
PROJ="$(cd "$HERE/.." && pwd)"
SRC="$PROJ/src/main/java"
BUILD="$HERE/.build"

echo "==> Compilando el núcleo del emulador (paquete com.gbaminecraft.emulator)"
rm -rf "$BUILD"
mkdir -p "$BUILD/src/com/gbaminecraft" "$BUILD/out"
cp -r "$SRC/com/gbaminecraft/emulator" "$BUILD/src/com/gbaminecraft/"

# Stub mínimo de GBAMod.LOGGER (la clase real depende de Forge; aquí no la necesitamos)
cat > "$BUILD/src/com/gbaminecraft/GBAMod.java" <<'EOF'
package com.gbaminecraft;
public class GBAMod {
  public static final Log LOGGER = new Log();
  public static class Log {
    public void info(String m){}  public void info(String m, Object a){}
    public void warn(String m){}  public void warn(String m, Object a){}
    public void error(String m){} public void error(String m, Object a){}
    public void error(String m, Throwable t){}
  }
}
EOF

( cd "$BUILD/src" && javac -d "$BUILD/out" $(find . -name '*.java') )

echo "==> Compilando los tests"
javac -cp "$BUILD/out" -d "$BUILD/out" "$HERE/CpuTest.java" "$HERE/PpuTest.java" "$HERE/IntegrationTest.java"

echo
echo "########################  CPU  ########################"
java -cp "$BUILD/out" CpuTest
echo
echo "########################  PPU  ########################"
java -cp "$BUILD/out" PpuTest
echo
echo "##############  INTEGRACION CPU+MEM+PPU  ##############"
java -cp "$BUILD/out" IntegrationTest

echo
echo "==> Listo. Si ves 'X PASARON, 0 FALLARON' en las tres suites, el núcleo está sano."
