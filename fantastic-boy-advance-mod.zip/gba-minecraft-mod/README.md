# GBA Minecraft Mod

Un mod de Minecraft (Forge 1.20.1) que implementa un emulador completo de Game Boy Advance (GBA) dentro del juego. Coloca una consola GBA en tu mundo de Minecraft y juega cualquier ROM `.gba` directamente en la pantalla del bloque.

---

## Características

- **Emulador GBA completo en Java puro** — sin dependencias nativas
  - CPU **ARM7TDMI** completa: modo ARM de 32 bits y modo Thumb de 16 bits
  - **PPU**: modos de video 0–5, 4 capas de fondos regulares/afines, sprites (OBJ), paleta de 15 bits
  - **APU**: 4 canales DMG (Pulse1, Pulse2, Wave, Noise) + 2 canales FIFO DMA (A/B)
  - **Bus de memoria**: BIOS, EWRAM, IWRAM, I/O, VRAM, OAM, ROM (hasta 32 MB), SRAM/Flash
  - **DMA**: 4 canales con modos inmediato, VBlank, HBlank y FIFO de audio
  - **Timers**: 4 timers con prescalers 1/64/256/1024 y modo cascade
  - **Input**: 10 botones del GBA mapeados a teclas del teclado
  - **Detección automática de tipo de guardado**: SRAM, EEPROM, Flash
- **Integración con Minecraft**
  - Bloque **GBA Console** colocable en el mundo
  - Ítem **GBA Cartridge** que almacena la ROM como NBT
  - GUI con pantalla escalada 2× (480×320 píxeles), indicadores de botones y selector de velocidad
  - Comandos `/gba` para cargar ROMs desde la carpeta del mundo
  - Soporte multijugador: cada consola es una instancia independiente
  - Teclas en tiempo real enviadas al servidor vía paquetes de red

---

## Requisitos

- **Java 17** o superior
- **Minecraft 1.20.1**
- **Forge 47.2.20** (`net.minecraftforge:forge:1.20.1-47.2.20`)
- **Parchment mappings** `2023.09.03-1.20.1` (para desarrollo)

---

## Compilación

```bash
# Clonar / extraer el proyecto
cd gba-minecraft-mod

# En Linux/Mac:
./gradlew build

# En Windows:
gradlew.bat build
```

El JAR compilado aparecerá en `build/libs/gba-minecraft-mod-1.0.0.jar`.

> **Nota**: El archivo `gradle/wrapper/gradle-wrapper.jar` no está incluido por ser binario. Si no tienes Gradle instalado, descárgalo desde https://gradle.org/install/ o ejecútalo con tu instalación local de Gradle (`gradle build`).

---

## Instalación

1. Instala **Minecraft Forge 1.20.1** desde https://files.minecraftforge.net/
2. Copia `gba-minecraft-mod-1.0.0.jar` a la carpeta `mods/` de tu instancia de Minecraft
3. Inicia el juego

---

## Uso

### 1. Obtener la consola y el cartucho

```
/gba give       → Da un bloque GBA Console al jugador
/gba cartridge  → Da un GBA Cartridge vacío al jugador
```

### 2. Cargar una ROM

Coloca tu archivo `.gba` en la carpeta `<mundo>/roms/` dentro del mundo de Minecraft.

```
/gba load NombreDelJuego.gba
```

Esto carga la ROM en el cartucho que tengas en la mano. Si no tienes cartucho, crea uno automáticamente.

### 3. Jugar

1. Coloca el bloque **GBA Console** en el mundo
2. Haz clic derecho con el **GBA Cartridge** cargado en la mano — o abre la GUI y pulsa Load
3. Se abre la pantalla de la GBA. ¡A jugar!

### 4. Controles

| Tecla         | Botón GBA |
|---------------|-----------|
| `X`           | A         |
| `Z`           | B         |
| `Enter`       | Start     |
| `Backspace`   | Select    |
| `Flechas`     | D-Pad     |
| `S`           | R         |
| `A`           | L         |

### 5. Velocidad y control

- **1x / 2x / 4x** — botones en la GUI para cambiar la velocidad de emulación
- **Reset** — reinicia la ROM desde el principio
- **Stop** — detiene el emulador (la ROM sigue en el cartucho)
- **FPS** — se muestra en tiempo real en la GUI

---

## Comandos

| Comando                   | Descripción                                      |
|---------------------------|--------------------------------------------------|
| `/gba give`               | Da una GBA Console al jugador                    |
| `/gba cartridge`          | Da un GBA Cartridge vacío                        |
| `/gba load <archivo.gba>` | Carga ROM desde `<mundo>/roms/archivo.gba`       |
| `/gba info`               | Muestra info del cartucho en la mano             |

---

## Arquitectura del emulador

```
GBAEmulator (hilo dedicado a ~16.78 MHz)
├── ARM7TDMI (CPU)
│   ├── Modo ARM  — instrucciones de 32 bits
│   └── Modo Thumb — instrucciones de 16 bits
├── MemoryBus
│   ├── BIOS ROM (16 KB, HLE stub)
│   ├── EWRAM (256 KB)
│   ├── IWRAM (32 KB)
│   ├── I/O Registers (enruta a PPU/APU/Timers/DMA/Input)
│   ├── VRAM (96 KB)
│   ├── OAM (1 KB)
│   ├── Palette RAM (1 KB)
│   ├── ROM (hasta 32 MB)
│   └── SRAM/Flash (64–128 KB)
├── PPU — renderiza 240×160 @ 59.73 Hz
│   ├── Modos 0–5 (regular, afín, bitmap)
│   └── Sprites (128 OBJs, tamaños 8×8 a 64×64)
├── APU — 32768 Hz estéreo
│   ├── CH1: Square con sweep
│   ├── CH2: Square
│   ├── CH3: Wave (Wave RAM 64 nibbles)
│   ├── CH4: Noise (LFSR 15/7 bits)
│   └── FIFO A/B (audio PCM vía DMA)
├── DMA Controller (4 canales)
├── Timer Controller (4 timers)
└── GBAInput (10 botones)
```

---

## Estructura del proyecto

```
gba-minecraft-mod/
├── build.gradle
├── gradle.properties
├── settings.gradle
├── gradlew / gradlew.bat
├── gradle/wrapper/
└── src/main/java/com/gbaminecraft/
    ├── GBAMod.java                     ← Clase principal del mod
    ├── emulator/
    │   ├── GBAEmulator.java            ← Orchestrador principal (hilo)
    │   ├── cpu/ARM7TDMI.java           ← CPU ARM7TDMI completa
    │   ├── memory/MemoryBus.java       ← Bus de memoria y I/O
    │   ├── ppu/PPU.java                ← Unidad de procesamiento gráfico
    │   ├── apu/APU.java                ← Unidad de procesamiento de audio
    │   ├── input/GBAInput.java         ← Manejo de botones
    │   ├── timer/TimerController.java  ← 4 timers hardware
    │   ├── dma/DMAController.java      ← 4 canales DMA
    │   └── cartridge/Cartridge.java    ← Carga y detección de ROMs
    └── minecraft/
        ├── block/GBABlock.java         ← Bloque GBA Console
        ├── client/GBAClientSetup.java  ← Registro de pantalla cliente
        ├── command/GBACommand.java     ← Comandos /gba
        ├── gui/
        │   ├── GBAMenu.java            ← Container del lado servidor
        │   └── GBAScreen.java          ← GUI cliente con pantalla GBA
        ├── item/GBACartridgeItem.java  ← Ítem cartucho con ROM en NBT
        ├── network/GBANetworkHandler.java ← Paquetes cliente↔servidor
        ├── registry/
        │   ├── ModBlocks.java
        │   ├── ModCreativeTabs.java
        │   ├── ModItems.java
        │   ├── ModMenuTypes.java
        │   └── ModTileEntities.java
        └── tileentity/GBATileEntity.java ← Tile entity con instancia del emulador
```

---

## Notas

- **BIOS**: El emulador incluye un stub HLE mínimo. Para máxima compatibilidad, coloca el BIOS oficial de GBA (`gba_bios.bin`, 16 KB) en la carpeta `<mundo>/roms/gba_bios.bin`. El cargador de ROMs lo detectará automáticamente en una futura actualización.
- **ROMs**: Asegúrate de poseer una copia legal del juego. Las ROMs de juegos comerciales tienen derechos de autor.
- **Rendimiento**: El emulador corre en un hilo Java dedicado. En hardware moderno debería mantener 60 FPS estables. Usa el multiplicador de velocidad si necesitas ir más rápido.
- **Guardado**: Los datos de guardado se almacenan en el NBT del tile entity del bloque y persisten al recargar el mundo.

---

## Licencia

MIT — ver LICENSE


---

# 🎮 Fantastic Boy Advance — actualización del front-end (handheld)

Esta actualización añade el modo **handheld de un solo item**, tal como se pidió, encima del núcleo del emulador existente.

## Qué cambia

- **Mod renombrado** a *Fantastic Boy Advance* (displayName).
- **Nuevo item: `Fantastic Boy Advance`** (`fantastic_boy_advance`). Lo sostienes y haces **clic derecho** para encender la consola — no necesitas colocar bloques.
- **Interfaz totalmente clicable** (`FantasticBoyScreen`):
  - **Navegador de ROMs** que lee la carpeta **`RomsGBA`** en la raíz de la instancia (se crea sola).
  - Al elegir una ROM: menú **Iniciar partida nueva / Cargar partida / Editar teclas / Volver**.
  - Durante el juego: pantalla con **relación de aspecto 3:2** (240×160 escalado), **D-pad, A, B, L, R, Start, Select clicables con el ratón** y también por teclado.
  - Botones: **Salir, Guardar estado, Cargar estado, Forzar guardado, Pausa**.
- **Persistencia**:
  - **Forzar guardado / al salir** → guarda la batería (SRAM) en `RomsGBA/saves/<rom>.sav`.
  - **Guardar/Cargar estado** → snapshot en `RomsGBA/states/<rom>.state` (RAM completa + registros de CPU).
- **Mapeo de teclas** editable y persistente en `config/fantasticboyadvance_keys.txt`.

> El bloque/cartucho y los comandos `/gba` anteriores siguen presentes; el item nuevo es la vía principal.

## Carpeta de ROMs

Coloca tus archivos `.gba` en `RomsGBA/` en la raíz de tu instancia (junto a `mods/`, `config/`, etc.). La carpeta se crea automáticamente al abrir la consola por primera vez.

## Compilar (en tu PC con internet)

```bash
cd gba-minecraft-mod
./gradlew build      # Windows: gradlew.bat build
# salida: build/libs/gba-minecraft-mod-1.0.0.jar
```

## ⚠️ Estado honesto del emulador (léelo)

El **núcleo del emulador (CPU/PPU/APU)** es un trabajo en progreso serio pero **incompleto**: todavía tiene bugs conocidos (p. ej. el cálculo de PC en saltos ARM) y **aún no ejecuta con precisión juegos comerciales**. Esta entrega completa la **experiencia de usuario** (item, interfaz, navegador, guardado, mapeo) sobre ese núcleo; lograr que los juegos corran "fluidos y sin bugs" como mGBA requiere mucho más trabajo de ingeniería de emulación, que conviene abordar de forma iterativa (primero arrancar un test ROM, luego juegos 2D simples, etc.).
