package com.gbaminecraft.emulator;

import com.gbaminecraft.GBAMod;
import com.gbaminecraft.emulator.apu.APU;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.SourceDataLine;

/**
 * Real-time audio output for the GBA emulator.
 *
 * The APU produces signed 16-bit stereo PCM at 32768 Hz into a buffer that is
 * marked "ready" each frame. This class drains that buffer to a Java Sound
 * {@link SourceDataLine} so the player actually hears the game. Audio output is
 * optional: if no audio device is available (headless tests), it degrades to a
 * silent no-op instead of throwing.
 */
public final class GBAAudioOutput {

    private SourceDataLine line;
    private boolean enabled = false;
    private volatile boolean muted = false;
    private byte[] byteBuf = new byte[0];

    public GBAAudioOutput() {
        try {
            // 32768 Hz, 16-bit signed, 2 channels, little-endian (matches APU output).
            AudioFormat fmt = new AudioFormat(APU.SAMPLE_RATE, 16, 2, true, false);
            DataLine.Info info = new DataLine.Info(SourceDataLine.class, fmt);
            if (!AudioSystem.isLineSupported(info)) {
                GBAMod.LOGGER.warn("FBA: audio line not supported; running muted.");
                return;
            }
            line = (SourceDataLine) AudioSystem.getLine(info);
            // A small buffer keeps latency low; ~4 frames of stereo audio.
            line.open(fmt, APU.SAMPLE_RATE / 15 * 4);
            line.start();
            enabled = true;
            GBAMod.LOGGER.info("FBA: audio output started.");
        } catch (Throwable t) {
            // No mixer / headless / denied — keep running without sound.
            GBAMod.LOGGER.warn("FBA: audio unavailable, running muted.");
            line = null;
            enabled = false;
        }
    }

    public boolean isEnabled() { return enabled; }
    public void setMuted(boolean m) { this.muted = m; }
    public boolean isMuted() { return muted; }

    /**
     * Submit one frame of stereo samples (interleaved L,R, signed 16-bit).
     * Non-blocking: if the line can't accept everything right now we drop the
     * remainder rather than stall the emulator thread.
     */
    public void submit(short[] samples, int sampleCount) {
        if (!enabled || line == null || muted || samples == null || sampleCount <= 0) return;
        int needed = sampleCount * 2; // 2 bytes per sample
        if (byteBuf.length < needed) byteBuf = new byte[needed];
        for (int i = 0; i < sampleCount; i++) {
            short s = samples[i];
            byteBuf[i * 2]     = (byte) (s & 0xFF);
            byteBuf[i * 2 + 1] = (byte) ((s >> 8) & 0xFF);
        }
        // Only write what fits to avoid blocking the emulation loop.
        int canWrite = Math.min(needed, Math.max(0, line.available()));
        // Keep it sample-aligned (multiple of 4 bytes for 16-bit stereo).
        canWrite &= ~3;
        if (canWrite > 0) line.write(byteBuf, 0, canWrite);
    }

    public void close() {
        if (line != null) {
            try { line.stop(); line.close(); } catch (Throwable ignored) {}
            line = null;
        }
        enabled = false;
    }
}
