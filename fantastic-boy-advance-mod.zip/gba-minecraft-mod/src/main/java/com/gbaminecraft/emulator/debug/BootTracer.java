package com.gbaminecraft.emulator.debug;

import com.gbaminecraft.emulator.cpu.ARM7TDMI;
import com.gbaminecraft.emulator.memory.MemoryBus;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;

/**
 * Lightweight boot/diagnostics tracer. When enabled, records a rolling window
 * of recent CPU state (PC, key registers, mode, video regs) and the BIOS SWIs
 * the game invoked. If a ROM hangs or crashes, dumping this trace shows exactly
 * where it got stuck — the fastest way to find the next thing to fix.
 *
 * Designed to be near-zero cost when disabled.
 */
public final class BootTracer {

    private boolean enabled = false;
    private final int capacity;
    private final long[] pcRing;
    private final int[]  instrRing;
    private int ringPos = 0;
    private long total = 0;

    // SWI histogram (which BIOS calls the game used, and how many times)
    private final long[] swiCounts = new long[256];

    // Detect tight infinite loops (same PC seen repeatedly)
    private long lastPc = -1;
    private int  samePcStreak = 0;
    private long longestStreak = 0;
    private long longestStreakPc = 0;
    private boolean frozen = false;   // set when PC derails to invalid memory
    private long derailPc = 0;

    public BootTracer(int capacity) {
        this.capacity = Math.max(16, capacity);
        this.pcRing   = new long[this.capacity];
        this.instrRing= new int[this.capacity];
    }

    public void setEnabled(boolean v) { enabled = v; }
    public boolean isEnabled()        { return enabled; }

    /** Record one executed instruction. Call from the emulation loop. */
    public void onStep(int pc, int instr) {
        if (!enabled || frozen) return;
        pcRing[ringPos]    = pc & 0xFFFFFFFFL;
        instrRing[ringPos] = instr;
        ringPos = (ringPos + 1) % capacity;
        total++;

        // Derail detector: a valid GBA PC lives in BIOS(0x00), EWRAM(0x02),
        // IWRAM(0x03) or ROM(0x08-0x0D). Anything else means we jumped to junk —
        // freeze the trace so the window shows the instructions that led here.
        int region = (pc >>> 24) & 0xFF;
        boolean validRegion = region == 0x00 || region == 0x02 || region == 0x03
                || (region >= 0x08 && region <= 0x0D);
        if (!validRegion) {
            frozen = true;
            derailPc = pc & 0xFFFFFFFFL;
            return;
        }

        if ((pc & 0xFFFFFFFFL) == lastPc) {
            samePcStreak++;
            if (samePcStreak > longestStreak) {
                longestStreak = samePcStreak;
                longestStreakPc = pc & 0xFFFFFFFFL;
            }
        } else {
            samePcStreak = 0;
            lastPc = pc & 0xFFFFFFFFL;
        }
    }

    public void onSwi(int num) {
        if (!enabled) return;
        swiCounts[num & 0xFF]++;
    }

    /** Build a human-readable diagnostic report. */
    public String report(ARM7TDMI cpu, MemoryBus bus) {
        StringBuilder sb = new StringBuilder();
        sb.append("==== Fantastic Boy Advance — Boot Trace ====\n");
        sb.append("Instrucciones ejecutadas: ").append(total).append('\n');
        sb.append(String.format("PC actual: 0x%08X  (Thumb=%b)%n", cpu.getPC(), cpu.isThumb()));
        sb.append("Registros R0-R15:\n");
        for (int i = 0; i < 16; i++) {
            sb.append(String.format("  R%-2d=0x%08X", i, cpu.regs[i]));
            if ((i & 3) == 3) sb.append('\n');
        }
        sb.append(String.format("CPSR=0x%08X%n", cpu.cpsr));

        // Video state — tells us if the game ever set up the display
        sb.append(String.format("DISPCNT=0x%04X DISPSTAT=0x%04X VCOUNT=%d%n",
                bus.read16(0x04000000), bus.read16(0x04000004), bus.read16(0x04000006)));
        sb.append(String.format("IME=%d IE=0x%04X IF=0x%04X%n",
                bus.read16(0x04000208) & 1, bus.read16(0x04000200), bus.read16(0x04000202)));
        sb.append(String.format("User IRQ handler [0x03007FFC]=0x%08X%n", bus.read32(0x03007FFC)));

        // Hang detector
        if (longestStreak > 1000) {
            sb.append(String.format("POSIBLE BUCLE: PC 0x%08X repetido %d veces%n",
                    longestStreakPc, longestStreak));
        }
        if (frozen) {
            sb.append(String.format("*** DESCARRILAMIENTO: PC saltó a 0x%08X (memoria inválida) ***%n", derailPc));
            sb.append("Las últimas instrucciones de abajo son las que llevaron al salto.\n");
        }

        // SWI histogram
        sb.append("SWIs usadas por el juego:\n");
        boolean any = false;
        for (int i = 0; i < 256; i++) {
            if (swiCounts[i] > 0) {
                any = true;
                sb.append(String.format("  SWI 0x%02X (%s): %d%n", i, swiName(i), swiCounts[i]));
            }
        }
        if (!any) sb.append("  (ninguna todavía)\n");

        // Recent PC window
        sb.append("Últimas instrucciones (PC : opcode):\n");
        int shown = Math.min(capacity, (int) Math.min(total, capacity));
        for (int k = 0; k < shown; k++) {
            int idx = ((ringPos - shown + k) % capacity + capacity) % capacity;
            sb.append(String.format("  0x%08X : 0x%08X%n", pcRing[idx], instrRing[idx]));
        }
        return sb.toString();
    }

    public void dumpToFile(Path file, ARM7TDMI cpu, MemoryBus bus) {
        try (BufferedWriter w = new BufferedWriter(new FileWriter(file.toFile()))) {
            w.write(report(cpu, bus));
        } catch (IOException ignored) {}
    }

    private static String swiName(int n) {
        switch (n) {
            case 0x00: return "SoftReset";
            case 0x01: return "RegisterRamReset";
            case 0x02: return "Halt";
            case 0x04: return "IntrWait";
            case 0x05: return "VBlankIntrWait";
            case 0x06: return "Div";
            case 0x08: return "Sqrt";
            case 0x0B: return "CpuSet";
            case 0x0C: return "CpuFastSet";
            case 0x0E: return "BgAffineSet";
            case 0x0F: return "ObjAffineSet";
            case 0x11: return "LZ77Wram";
            case 0x12: return "LZ77Vram";
            case 0x13: return "HuffUnComp";
            case 0x14: return "RLWram";
            case 0x15: return "RLVram";
            default:   return "?";
        }
    }

    public void reset() {
        ringPos = 0; total = 0; lastPc = -1; samePcStreak = 0;
        longestStreak = 0; longestStreakPc = 0;
        frozen = false; derailPc = 0;
        java.util.Arrays.fill(swiCounts, 0);
    }
}
