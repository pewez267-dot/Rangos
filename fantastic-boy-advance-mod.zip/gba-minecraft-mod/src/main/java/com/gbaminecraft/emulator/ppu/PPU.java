package com.gbaminecraft.emulator.ppu;

import com.gbaminecraft.emulator.memory.MemoryBus;

/**
 * GBA Picture Processing Unit (PPU).
 * Renders backgrounds (modes 0-5) and sprites (OBJs) to a 240x160 framebuffer.
 * Each pixel is ARGB8888.
 */
public class PPU {

    public static final int SCREEN_WIDTH  = 240;
    public static final int SCREEN_HEIGHT = 160;

    // Timing constants (cycles at ~16.78 MHz)
    public static final int CYCLES_PER_DOT    = 4;
    public static final int DOTS_PER_LINE     = 308; // 240 visible + 68 HBlank
    public static final int LINES_PER_FRAME   = 228; // 160 visible + 68 VBlank
    public static final int CYCLES_PER_LINE   = DOTS_PER_LINE * CYCLES_PER_DOT;
    public static final int CYCLES_PER_HBLANK = 68 * CYCLES_PER_DOT;
    public static final int CYCLES_PER_FRAME  = DOTS_PER_LINE * LINES_PER_FRAME * CYCLES_PER_DOT;

    // Interrupt bits
    public static final int IRQ_VBLANK = 1 << 0;
    public static final int IRQ_HBLANK = 1 << 1;
    public static final int IRQ_VCOUNT = 1 << 2;

    // Framebuffer (ARGB)
    private final int[] framebuffer  = new int[SCREEN_WIDTH * SCREEN_HEIGHT];
    private final int[] scanlineBuf  = new int[SCREEN_WIDTH];

    // Memory
    private byte[] vram;
    private byte[] palette;
    private byte[] oam;
    private MemoryBus bus;

    // I/O Registers (mirrored from bus)
    private int DISPCNT  = 0;
    private int DISPSTAT = 0;
    private int VCOUNT   = 0;
    private int[] BG_CNT    = new int[4];
    private int[] BG_HOFS   = new int[4];
    private int[] BG_VOFS   = new int[4];
    private int[] BG_PA     = new int[2]; // BG2, BG3
    private int[] BG_PB     = new int[2];
    private int[] BG_PC     = new int[2];
    private int[] BG_PD     = new int[2];
    private int[] BG_RefX   = new int[2];
    private int[] BG_RefY   = new int[2];
    private int   WIN0H, WIN0V, WIN1H, WIN1V;
    private int   WININ, WINOUT;
    private int   BLDCNT, BLDALPHA, BLDY;
    private int   MOSAIC;

    // Internal affine reference points (latched at VBlank)
    private int[] affineRefX = new int[2];
    private int[] affineRefY = new int[2];

    // Cycle counter
    private int cycleCnt = 0;
    private int scanline  = 0;

    private boolean newFrame = false;

    public PPU(MemoryBus bus) {
        this.bus = bus;
        this.vram    = bus.getVRAM();
        this.palette = bus.getPalette();
        this.oam     = bus.getOAM();
    }

    // ── Main tick ─────────────────────────────────────────────────────────
    public void tick(int cycles) {
        cycleCnt += cycles;

        if (cycleCnt >= CYCLES_PER_LINE) {
            cycleCnt -= CYCLES_PER_LINE;
            advanceScanline();
        }
    }

    private void advanceScanline() {
        scanline++;

        if (scanline >= LINES_PER_FRAME) {
            scanline = 0;
            newFrame = true;
            // Latch affine reference points
            affineRefX[0] = BG_RefX[0];
            affineRefX[1] = BG_RefX[1];
            affineRefY[0] = BG_RefY[0];
            affineRefY[1] = BG_RefY[1];
        }

        VCOUNT = scanline;
        updateDISPSTAT();

        if (scanline < SCREEN_HEIGHT) {
            renderScanline(scanline);
            // Advance affine backgrounds
            affineRefX[0] += (short) BG_PB[0];
            affineRefX[1] += (short) BG_PB[1];
            affineRefY[0] += (short) BG_PD[0];
            affineRefY[1] += (short) BG_PD[1];
        }
    }

    private void updateDISPSTAT() {
        // VBlank flag
        if (scanline >= SCREEN_HEIGHT && scanline < LINES_PER_FRAME - 1) {
            DISPSTAT |= 1;
            if ((DISPSTAT & (1 << 3)) != 0) bus.requestInterrupt(IRQ_VBLANK);
        } else {
            DISPSTAT &= ~1;
        }
        // HBlank flag
        DISPSTAT |= 2; // always set during hblank period
        if ((DISPSTAT & (1 << 4)) != 0) bus.requestInterrupt(IRQ_HBLANK);
        // VCount match
        int lyc = (DISPSTAT >>> 8) & 0xFF;
        if (scanline == lyc) {
            DISPSTAT |= (1 << 2);
            if ((DISPSTAT & (1 << 5)) != 0) bus.requestInterrupt(IRQ_VCOUNT);
        } else {
            DISPSTAT &= ~(1 << 2);
        }
    }

    // ── Scanline render ────────────────────────────────────────────────────
    private void renderScanline(int y) {
        int bgMode = DISPCNT & 0x7;
        boolean display = (DISPCNT & (1 << 7)) == 0; // forced blank when bit7 set

        if (!display) {
            int white = 0xFFFFFFFF;
            for (int x = 0; x < SCREEN_WIDTH; x++) framebuffer[y * SCREEN_WIDTH + x] = white;
            return;
        }

        // Fill with backdrop
        int backdrop = readPalette(0);
        for (int x = 0; x < SCREEN_WIDTH; x++) scanlineBuf[x] = backdrop;

        switch (bgMode) {
            case 0: renderMode0(y); break;
            case 1: renderMode1(y); break;
            case 2: renderMode2(y); break;
            case 3: renderMode3(y); break;
            case 4: renderMode4(y); break;
            case 5: renderMode5(y); break;
        }

        renderSprites(y, bgMode);

        System.arraycopy(scanlineBuf, 0, framebuffer, y * SCREEN_WIDTH, SCREEN_WIDTH);
    }

    // ── Mode 0: four regular BGs ───────────────────────────────────────────
    private void renderMode0(int y) {
        // Render BGs in priority order (lowest priority first)
        for (int priority = 3; priority >= 0; priority--) {
            for (int bg = 3; bg >= 0; bg--) {
                if ((DISPCNT & (1 << (8 + bg))) == 0) continue;
                if ((BG_CNT[bg] & 3) != priority) continue;
                renderRegularBG(bg, y);
            }
        }
    }

    // ── Mode 1: BG0+BG1 regular, BG2 affine ──────────────────────────────
    private void renderMode1(int y) {
        for (int priority = 3; priority >= 0; priority--) {
            for (int bg = 2; bg >= 0; bg--) {
                if ((DISPCNT & (1 << (8 + bg))) == 0) continue;
                if ((BG_CNT[bg] & 3) != priority) continue;
                if (bg == 2) renderAffineBG(0, y);
                else renderRegularBG(bg, y);
            }
        }
    }

    // ── Mode 2: BG2+BG3 affine ────────────────────────────────────────────
    private void renderMode2(int y) {
        for (int priority = 3; priority >= 0; priority--) {
            for (int bg = 3; bg >= 2; bg--) {
                if ((DISPCNT & (1 << (8 + bg))) == 0) continue;
                if ((BG_CNT[bg] & 3) != priority) continue;
                renderAffineBG(bg - 2, y);
            }
        }
    }

    // ── Mode 3: 240x160 15-bit bitmap ─────────────────────────────────────
    private void renderMode3(int y) {
        if ((DISPCNT & (1 << 10)) == 0) return;
        int base = y * SCREEN_WIDTH * 2;
        for (int x = 0; x < SCREEN_WIDTH; x++) {
            int color15 = ((vram[base + x*2] & 0xFF)) | ((vram[base + x*2+1] & 0xFF) << 8);
            scanlineBuf[x] = color15toARGB(color15);
        }
    }

    // ── Mode 4: 240x160 8bpp paletted, 2 pages ────────────────────────────
    private void renderMode4(int y) {
        if ((DISPCNT & (1 << 10)) == 0) return;
        int page = ((DISPCNT & (1 << 4)) != 0) ? 0xA000 : 0;
        int base = page + y * SCREEN_WIDTH;
        for (int x = 0; x < SCREEN_WIDTH; x++) {
            int idx = vram[base + x] & 0xFF;
            scanlineBuf[x] = idx == 0 ? readPalette(0) : readPalette(idx);
        }
    }

    // ── Mode 5: 160x128 15-bit bitmap, 2 pages ────────────────────────────
    private void renderMode5(int y) {
        if ((DISPCNT & (1 << 10)) == 0) return;
        if (y >= 128) return;
        int page = ((DISPCNT & (1 << 4)) != 0) ? 0xA000 : 0;
        int base = page + y * 160 * 2;
        for (int x = 0; x < 160; x++) {
            int color15 = (vram[base + x*2] & 0xFF) | ((vram[base + x*2+1] & 0xFF) << 8);
            scanlineBuf[x] = color15toARGB(color15);
        }
    }

    // ── Regular BG render ─────────────────────────────────────────────────
    private void renderRegularBG(int bg, int y) {
        int cnt      = BG_CNT[bg];
        int screenBase = ((cnt >>> 8) & 0x1F) * 0x800;
        int charBase   = ((cnt >>> 2) & 0x3)  * 0x4000;
        boolean color256 = (cnt & (1 << 7)) != 0;
        int sizeMode   = (cnt >>> 14) & 0x3;

        int scrollX = BG_HOFS[bg] & 0x1FF;
        int scrollY = BG_VOFS[bg] & 0x1FF;

        int mapWidth  = (sizeMode & 1) != 0 ? 512 : 256;
        int mapHeight = (sizeMode & 2) != 0 ? 512 : 256;

        int bgY = (y + scrollY) % mapHeight;

        for (int x = 0; x < SCREEN_WIDTH; x++) {
            int bgX = (x + scrollX) % mapWidth;

            int tileX = bgX / 8;
            int tileY = bgY / 8;
            int pixX  = bgX % 8;
            int pixY  = bgY % 8;

            // Screen block selection
            int screenBlock = 0;
            if (sizeMode == 1) screenBlock = tileX / 32;
            else if (sizeMode == 2) screenBlock = tileY / 32;
            else if (sizeMode == 3) screenBlock = (tileY / 32) * 2 + (tileX / 32);

            int mapOff = screenBase + screenBlock * 0x800
                       + (tileY % 32) * 64 + (tileX % 32) * 2;
            if (mapOff + 1 >= vram.length) continue;
            int tileAttr = (vram[mapOff] & 0xFF) | ((vram[mapOff + 1] & 0xFF) << 8);
            int tileNum  = tileAttr & 0x3FF;
            boolean flipH = (tileAttr & (1 << 10)) != 0;
            boolean flipV = (tileAttr & (1 << 11)) != 0;
            int palBank   = (tileAttr >>> 12) & 0xF;

            int pxOff = flipH ? (7 - pixX) : pixX;
            int pyOff = flipV ? (7 - pixY) : pixY;

            int colorIdx;
            if (color256) {
                int off = charBase + tileNum * 64 + pyOff * 8 + pxOff;
                colorIdx = off < vram.length ? (vram[off] & 0xFF) : 0;
                if (colorIdx != 0) scanlineBuf[x] = readPalette(colorIdx);
            } else {
                int off = charBase + tileNum * 32 + pyOff * 4 + pxOff / 2;
                int nibble = off < vram.length ? (vram[off] & 0xFF) : 0;
                colorIdx = (pxOff & 1) != 0 ? (nibble >>> 4) : (nibble & 0xF);
                if (colorIdx != 0) scanlineBuf[x] = readPalette(palBank * 16 + colorIdx);
            }
        }
    }

    // ── Affine BG render ──────────────────────────────────────────────────
    private void renderAffineBG(int idx, int y) {
        int bg = idx + 2;
        int cnt = BG_CNT[bg];
        int screenBase = ((cnt >>> 8) & 0x1F) * 0x800;
        int charBase   = ((cnt >>> 2) & 0x3)  * 0x4000;
        boolean wrap   = (cnt & (1 << 13)) != 0;
        int sizeMode   = (cnt >>> 14) & 0x3;
        int mapSize    = 128 << sizeMode; // 128, 256, 512, 1024

        int pa = (short) BG_PA[idx];
        int pc = (short) BG_PC[idx];
        int refX = affineRefX[idx];
        int refY = affineRefY[idx];

        for (int x = 0; x < SCREEN_WIDTH; x++) {
            int bgX = (refX + pa * x) >> 8;
            int bgY = (refY + pc * x) >> 8;

            if (wrap) {
                bgX = ((bgX % mapSize) + mapSize) % mapSize;
                bgY = ((bgY % mapSize) + mapSize) % mapSize;
            } else if (bgX < 0 || bgX >= mapSize || bgY < 0 || bgY >= mapSize) {
                continue;
            }

            int tileX = bgX / 8, tileY = bgY / 8;
            int pixX  = bgX % 8, pixY  = bgY % 8;
            int mapOff = screenBase + tileY * (mapSize / 8) + tileX;
            if (mapOff >= vram.length) continue;
            int tileNum = vram[mapOff] & 0xFF;
            int off = charBase + tileNum * 64 + pixY * 8 + pixX;
            int colorIdx = off < vram.length ? (vram[off] & 0xFF) : 0;
            if (colorIdx != 0) scanlineBuf[x] = readPalette(colorIdx + 256);
        }
    }

    // ── Sprite render ─────────────────────────────────────────────────────
    private static final int[][] OBJ_SIZE = {
        {8,8},  {16,16}, {32,32}, {64,64},  // Square
        {16,8}, {32,8},  {32,16}, {64,32},  // Horizontal
        {8,16}, {8,32},  {16,32}, {32,64}   // Vertical
    };

    private void renderSprites(int y, int bgMode) {
        boolean use1D = (DISPCNT & (1 << 6)) != 0;
        int spriteCharBase = (bgMode >= 3) ? 0x14000 : 0x10000;

        // Parse OAM (128 sprites)
        for (int sp = 127; sp >= 0; sp--) {
            int oamOff = sp * 8;
            int attr0  = (oam[oamOff]     & 0xFF) | ((oam[oamOff + 1] & 0xFF) << 8);
            int attr1  = (oam[oamOff + 2] & 0xFF) | ((oam[oamOff + 3] & 0xFF) << 8);
            int attr2  = (oam[oamOff + 4] & 0xFF) | ((oam[oamOff + 5] & 0xFF) << 8);

            int objMode = (attr0 >>> 8) & 0x3;
            if (objMode == 2) continue; // hidden

            int shape  = (attr0 >>> 14) & 0x3;
            int size   = (attr1 >>> 14) & 0x3;
            int sizeIdx = shape * 4 + size;
            if (sizeIdx >= OBJ_SIZE.length) continue;
            int w = OBJ_SIZE[sizeIdx][0];
            int h = OBJ_SIZE[sizeIdx][1];

            int sprY = attr0 & 0xFF;
            if (sprY > 160) sprY -= 256;

            if (y < sprY || y >= sprY + h) continue;

            int sprX = attr1 & 0x1FF;
            if (sprX >= SCREEN_WIDTH) sprX -= 512;

            boolean flipH   = (attr1 & (1 << 12)) != 0 && objMode == 0;
            boolean flipV   = (attr1 & (1 << 13)) != 0 && objMode == 0;
            boolean color256 = (attr0 & (1 << 13)) != 0;
            int palBank   = color256 ? 0 : ((attr2 >>> 12) & 0xF);
            int tileNum   = attr2 & 0x3FF;
            int priority  = (attr2 >>> 10) & 0x3;

            int lineInSprite = y - sprY;
            if (flipV) lineInSprite = h - 1 - lineInSprite;

            int tilesPerRow = use1D ? (w / 8) : (color256 ? 16 : 32);
            int tileRow = lineInSprite / 8;
            int pixRow  = lineInSprite % 8;

            for (int px = 0; px < w; px++) {
                int screenX = sprX + px;
                if (screenX < 0 || screenX >= SCREEN_WIDTH) continue;

                int pxOff = flipH ? (w - 1 - px) : px;
                int tileCol = pxOff / 8;
                int pixCol  = pxOff % 8;

                int tileIdx;
                if (use1D) {
                    tileIdx = color256 ? tileNum + tileRow * (w / 8) * 2 + tileCol * 2
                                       : tileNum + tileRow * (w / 8) + tileCol;
                } else {
                    tileIdx = color256 ? (tileNum & ~1) + tileRow * 32 + tileCol * 2
                                       : tileNum + tileRow * 32 + tileCol;
                }

                int colorIdx;
                if (color256) {
                    int off = spriteCharBase + tileIdx * 32 + pixRow * 8 + pixCol;
                    colorIdx = off < vram.length ? (vram[off] & 0xFF) : 0;
                    if (colorIdx != 0) scanlineBuf[screenX] = readPalette(256 + colorIdx);
                } else {
                    int off = spriteCharBase + tileIdx * 32 + pixRow * 4 + pixCol / 2;
                    int nibble = off < vram.length ? (vram[off] & 0xFF) : 0;
                    colorIdx = (pixCol & 1) != 0 ? (nibble >>> 4) : (nibble & 0xF);
                    if (colorIdx != 0) scanlineBuf[screenX] = readPalette(256 + palBank * 16 + colorIdx);
                }
            }
        }
    }

    // ── Palette helpers ────────────────────────────────────────────────────
    private int readPalette(int idx) {
        int off = idx * 2;
        if (off + 1 >= palette.length) return 0xFF000000;
        int color15 = (palette[off] & 0xFF) | ((palette[off + 1] & 0xFF) << 8);
        return color15toARGB(color15);
    }

    private static int color15toARGB(int c) {
        int r = (c & 0x1F) << 3;
        int g = ((c >>> 5) & 0x1F) << 3;
        int b = ((c >>> 10) & 0x1F) << 3;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    // ── I/O register access ───────────────────────────────────────────────
    public int readRegister(int offset) {
        switch (offset) {
            case 0x00: return DISPCNT & 0xFF;
            case 0x01: return (DISPCNT >>> 8) & 0xFF;
            case 0x04: return DISPSTAT & 0xFF;
            case 0x05: return (DISPSTAT >>> 8) & 0xFF;
            case 0x06: return VCOUNT & 0xFF;
            case 0x07: return 0;
            case 0x08: return BG_CNT[0] & 0xFF;
            case 0x09: return (BG_CNT[0] >>> 8) & 0xFF;
            case 0x0A: return BG_CNT[1] & 0xFF;
            case 0x0B: return (BG_CNT[1] >>> 8) & 0xFF;
            case 0x0C: return BG_CNT[2] & 0xFF;
            case 0x0D: return (BG_CNT[2] >>> 8) & 0xFF;
            case 0x0E: return BG_CNT[3] & 0xFF;
            case 0x0F: return (BG_CNT[3] >>> 8) & 0xFF;
            default:   return 0;
        }
    }

    public void writeRegister(int offset, int val) {
        switch (offset) {
            case 0x00: DISPCNT  = (DISPCNT  & 0xFF00) | val; break;
            case 0x01: DISPCNT  = (DISPCNT  & 0x00FF) | (val << 8); break;
            case 0x04: DISPSTAT = (DISPSTAT & 0xFF00) | (val & 0xF8); break; // lower bits read-only
            case 0x05: DISPSTAT = (DISPSTAT & 0x00FF) | (val << 8); break;
            case 0x08: BG_CNT[0] = (BG_CNT[0] & 0xFF00) | val; break;
            case 0x09: BG_CNT[0] = (BG_CNT[0] & 0x00FF) | (val << 8); break;
            case 0x0A: BG_CNT[1] = (BG_CNT[1] & 0xFF00) | val; break;
            case 0x0B: BG_CNT[1] = (BG_CNT[1] & 0x00FF) | (val << 8); break;
            case 0x0C: BG_CNT[2] = (BG_CNT[2] & 0xFF00) | val; break;
            case 0x0D: BG_CNT[2] = (BG_CNT[2] & 0x00FF) | (val << 8); break;
            case 0x0E: BG_CNT[3] = (BG_CNT[3] & 0xFF00) | val; break;
            case 0x0F: BG_CNT[3] = (BG_CNT[3] & 0x00FF) | (val << 8); break;
            case 0x10: BG_HOFS[0] = (BG_HOFS[0] & 0xFF00) | val; break;
            case 0x11: BG_HOFS[0] = (BG_HOFS[0] & 0x00FF) | (val << 8); break;
            case 0x12: BG_VOFS[0] = (BG_VOFS[0] & 0xFF00) | val; break;
            case 0x13: BG_VOFS[0] = (BG_VOFS[0] & 0x00FF) | (val << 8); break;
            case 0x14: BG_HOFS[1] = (BG_HOFS[1] & 0xFF00) | val; break;
            case 0x15: BG_HOFS[1] = (BG_HOFS[1] & 0x00FF) | (val << 8); break;
            case 0x16: BG_VOFS[1] = (BG_VOFS[1] & 0xFF00) | val; break;
            case 0x17: BG_VOFS[1] = (BG_VOFS[1] & 0x00FF) | (val << 8); break;
            case 0x18: BG_HOFS[2] = (BG_HOFS[2] & 0xFF00) | val; break;
            case 0x19: BG_HOFS[2] = (BG_HOFS[2] & 0x00FF) | (val << 8); break;
            case 0x1A: BG_VOFS[2] = (BG_VOFS[2] & 0xFF00) | val; break;
            case 0x1B: BG_VOFS[2] = (BG_VOFS[2] & 0x00FF) | (val << 8); break;
            case 0x1C: BG_HOFS[3] = (BG_HOFS[3] & 0xFF00) | val; break;
            case 0x1D: BG_HOFS[3] = (BG_HOFS[3] & 0x00FF) | (val << 8); break;
            case 0x1E: BG_VOFS[3] = (BG_VOFS[3] & 0xFF00) | val; break;
            case 0x1F: BG_VOFS[3] = (BG_VOFS[3] & 0x00FF) | (val << 8); break;
            case 0x20: BG_PA[0] = (BG_PA[0] & 0xFF00) | val; break;
            case 0x21: BG_PA[0] = (BG_PA[0] & 0x00FF) | (val << 8); break;
            case 0x22: BG_PB[0] = (BG_PB[0] & 0xFF00) | val; break;
            case 0x23: BG_PB[0] = (BG_PB[0] & 0x00FF) | (val << 8); break;
            case 0x24: BG_PC[0] = (BG_PC[0] & 0xFF00) | val; break;
            case 0x25: BG_PC[0] = (BG_PC[0] & 0x00FF) | (val << 8); break;
            case 0x26: BG_PD[0] = (BG_PD[0] & 0xFF00) | val; break;
            case 0x27: BG_PD[0] = (BG_PD[0] & 0x00FF) | (val << 8); break;
            case 0x28: BG_RefX[0] = (BG_RefX[0] & 0xFFFFFF00) | val; break;
            case 0x29: BG_RefX[0] = (BG_RefX[0] & 0xFFFF00FF) | (val << 8); break;
            case 0x2A: BG_RefX[0] = (BG_RefX[0] & 0xFF00FFFF) | (val << 16); break;
            case 0x2B: BG_RefX[0] = (BG_RefX[0] & 0x00FFFFFF) | (val << 24); break;
            case 0x2C: BG_RefY[0] = (BG_RefY[0] & 0xFFFFFF00) | val; break;
            case 0x2D: BG_RefY[0] = (BG_RefY[0] & 0xFFFF00FF) | (val << 8); break;
            case 0x2E: BG_RefY[0] = (BG_RefY[0] & 0xFF00FFFF) | (val << 16); break;
            case 0x2F: BG_RefY[0] = (BG_RefY[0] & 0x00FFFFFF) | (val << 24); break;
            case 0x50: BLDCNT  = (BLDCNT  & 0xFF00) | val; break;
            case 0x51: BLDCNT  = (BLDCNT  & 0x00FF) | (val << 8); break;
            case 0x52: BLDALPHA= (BLDALPHA& 0xFF00) | val; break;
            case 0x53: BLDALPHA= (BLDALPHA& 0x00FF) | (val << 8); break;
            case 0x54: BLDY   = val; break;
        }
    }

    // ── Getters ────────────────────────────────────────────────────────────
    public int[] getFramebuffer() { return framebuffer; }
    public int   getScanline()    { return scanline; }
    public boolean isVBlank()     { return scanline >= SCREEN_HEIGHT; }

    public boolean pollNewFrame() {
        if (newFrame) { newFrame = false; return true; }
        return false;
    }

    public void reset() {
        DISPCNT = 0; DISPSTAT = 0; VCOUNT = 0;
        java.util.Arrays.fill(BG_CNT, 0);
        java.util.Arrays.fill(framebuffer, 0xFF000000);
        cycleCnt = 0;
        scanline = 0;
        newFrame = false;
    }
}
