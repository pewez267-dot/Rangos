// 
// Decompiled by Procyon v0.6.0
// 

package com.fscrates.crate;

import net.minecraft.nbt.Tag;
import java.util.Iterator;
import net.minecraft.nbt.CompoundTag;
import java.util.UUID;
import java.util.function.Supplier;
import java.util.function.Function;
import net.minecraft.server.level.ServerLevel;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.world.level.saveddata.SavedData;

public class CooldownData extends SavedData
{
    public static final String NAME = "fscrates_cooldowns";
    private final Map<String, Long> expiry;
    
    public CooldownData() {
        this.expiry = new HashMap<String, Long>();
    }
    
    public static CooldownData get(final ServerLevel anyLevel) {
        final ServerLevel overworld = anyLevel.m_7654_().m_129783_();
        return (CooldownData)overworld.m_8895_().m_164861_((Function)CooldownData::load, (Supplier)CooldownData::new, "fscrates_cooldowns");
    }
    
    private static String key(final UUID player, final String crateId) {
        return player.toString() + "|" + crateId;
    }
    
    public long remainingSeconds(final UUID player, final String crateId) {
        final Long until = this.expiry.get(key(player, crateId));
        if (until == null) {
            return 0L;
        }
        final long remainingMs = until - System.currentTimeMillis();
        return (remainingMs <= 0L) ? 0L : ((remainingMs + 999L) / 1000L);
    }
    
    public boolean isReady(final UUID player, final String crateId) {
        return this.remainingSeconds(player, crateId) <= 0L;
    }
    
    public void startCooldown(final UUID player, final String crateId, final int seconds) {
        if (seconds <= 0) {
            return;
        }
        this.expiry.put(key(player, crateId), System.currentTimeMillis() + seconds * 1000L);
        this.m_77762_();
    }
    
    public static CooldownData load(final CompoundTag tag) {
        final CooldownData data = new CooldownData();
        final CompoundTag stored = tag.m_128469_("cooldowns");
        for (final String k : stored.m_128431_()) {
            data.expiry.put(k, stored.m_128454_(k));
        }
        return data;
    }
    
    public CompoundTag m_7176_(final CompoundTag tag) {
        final CompoundTag stored = new CompoundTag();
        final long now = System.currentTimeMillis();
        for (final Map.Entry<String, Long> e : this.expiry.entrySet()) {
            if (e.getValue() > now) {
                stored.m_128356_((String)e.getKey(), (long)e.getValue());
            }
        }
        tag.m_128365_("cooldowns", (Tag)stored);
        return tag;
    }
}
