// 
// Decompiled by Procyon v0.6.0
// 

package com.fscrates.config;

import net.minecraft.ChatFormatting;

public enum Rarity
{
    COMMON("common", "Comun", ChatFormatting.WHITE, 13685464), 
    RARE("rare", "Rara", ChatFormatting.AQUA, 5630965), 
    EPIC("epic", "Epica", ChatFormatting.LIGHT_PURPLE, 14446320), 
    LEGENDARY("legendary", "Legendaria", ChatFormatting.GOLD, 16757288), 
    MYTHIC("mythic", "Mitica", ChatFormatting.RED, 16732240);
    
    private final String id;
    private final String displayName;
    private final ChatFormatting color;
    private final int rgb;
    
    private Rarity(final String id, final String displayName, final ChatFormatting color, final int rgb) {
        this.id = id;
        this.displayName = displayName;
        this.color = color;
        this.rgb = rgb;
    }
    
    public String id() {
        return this.id;
    }
    
    public String displayName() {
        return this.displayName;
    }
    
    public ChatFormatting color() {
        return this.color;
    }
    
    public int rgb() {
        return this.rgb;
    }
    
    public float redF() {
        return (this.rgb >> 16 & 0xFF) / 255.0f;
    }
    
    public float greenF() {
        return (this.rgb >> 8 & 0xFF) / 255.0f;
    }
    
    public float blueF() {
        return (this.rgb & 0xFF) / 255.0f;
    }
    
    public Rarity next() {
        final Rarity[] v = values();
        return v[(this.ordinal() + 1) % v.length];
    }

    /**
     * Factor de TAMANO visual del cofre por rareza (legendary y mythic son mas
     * grandes). Es la UNICA fuente de verdad del tamano: lo usa el render del
     * cofre (CrateBakedModels.renderScale) y tambien las PARTICULAS para envolver
     * el cofre real (anillos, halos, espiral...) en vez del bloque de 1x1.
     */
    public float sizeScale() {
        switch (this) {
            case LEGENDARY: return 2.85f;  // un poco mas grande (sin tocar la mitica)
            case MYTHIC:    return 2.30f;  // igual que antes
            case EPIC:      return 1.30f;  // un poco mas grande que comun/rara
            default:        return 1.0f;   // comun y rara
        }
    }
    
    public static Rarity byName(final String name) {
        if (name == null) {
            return Rarity.COMMON;
        }
        for (final Rarity r : values()) {
            if (r.name().equalsIgnoreCase(name) || r.id.equalsIgnoreCase(name)) {
                return r;
            }
        }
        return Rarity.COMMON;
    }
}
