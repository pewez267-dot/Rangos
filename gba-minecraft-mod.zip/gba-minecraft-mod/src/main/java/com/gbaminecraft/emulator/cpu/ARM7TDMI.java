package com.gbaminecraft.emulator.cpu;

import com.gbaminecraft.emulator.memory.MemoryBus;

/**
 * ARM7TDMI CPU Emulator — full ARM + Thumb mode implementation.
 * Emulates the GBA's 16.78 MHz ARM7TDMI processor.
 */
public class ARM7TDMI {

    // ── Registers ──────────────────────────────────────────────────────────
    public final int[] regs = new int[16];   // R0-R15 (current-mode view)
    public int cpsr = 0x1F;                  // Current Program Status Register (System mode at start)
    public int spsr = 0;                     // Saved PSR

    // Banked registers for each mode
    private final int[] bankedR8Fiq  = new int[2];
    private final int[] bankedR9Fiq  = new int[2];
    private final int[] bankedR10Fiq = new int[2];
    private final int[] bankedR11Fiq = new int[2];
    private final int[] bankedR12Fiq = new int[2];
    private final int[] bankedR13    = new int[6]; // User/FIQ/IRQ/SVC/ABT/UND
    private final int[] bankedR14    = new int[6];
    private final int[] bankedSPSR   = new int[5]; // FIQ/IRQ/SVC/ABT/UND

    // CPSR flags
    private static final int FLAG_N = 1 << 31;
    private static final int FLAG_Z = 1 << 30;
    private static final int FLAG_C = 1 << 29;
    private static final int FLAG_V = 1 << 28;
    private static final int FLAG_T = 1 << 5;    // Thumb mode
    private static final int FLAG_F = 1 << 6;    // FIQ disable
    private static final int FLAG_I = 1 << 7;    // IRQ disable

    // CPU modes (bits 4:0 of CPSR)
    private static final int MODE_USER = 0x10;
    private static final int MODE_FIQ  = 0x11;
    private static final int MODE_IRQ  = 0x12;
    private static final int MODE_SVC  = 0x13;
    private static final int MODE_ABT  = 0x17;
    private static final int MODE_UND  = 0x1B;
    private static final int MODE_SYS  = 0x1F;

    // Cycle count
    public long cycles = 0;

    private final MemoryBus bus;
    public boolean halted = false;
    public boolean stopped = false;

    // IntrWait/VBlankIntrWait HLE state
    private boolean intrWaitActive = false;
    private int     intrWaitMask   = 0;
    public static boolean DEBUG_SWI = Boolean.getBoolean("debugSwi");
    private int swiLogCount = 0;
    // PC ring-buffer trace: dump recent PCs when reaching TRACE_TARGET.
    public static int TRACE_TARGET = (int)Long.parseLong(System.getProperty("traceTarget","0"),16);
    public static int WIN_LO = (int)Long.parseLong(System.getProperty("winLo","0"),16);
    public static int WIN_HI = (int)Long.parseLong(System.getProperty("winHi","0"),16);
    private int winPrinted = 0;
    private int lastStepPc = 0;
    private final int[] pcRing = new int[64];
    private int pcRingPos = 0;
    private int traceDumps = 0;
    // BIOS interrupt-acknowledge flags live at 0x03007FF8 (mirror 0x03FFFFF8).
    private static final int BIOS_IF_ADDR = 0x03007FF8;

    // Pipeline prefetch
    private int pipeline0, pipeline1;
    private boolean pipelineFilled = false;

    public ARM7TDMI(MemoryBus bus) {
        this.bus = bus;
        reset();
    }

    public void reset() {
        for (int i = 0; i < 16; i++) regs[i] = 0;
        cpsr  = MODE_SYS;
        spsr  = 0;
        halted = false;
        stopped = false;
        pipelineFilled = false;
        // SP initial values
        bankedR13[modeIndex(MODE_SVC)] = 0x03007FE0;
        bankedR13[modeIndex(MODE_IRQ)] = 0x03007FA0;
        bankedR13[modeIndex(MODE_SYS)] = 0x03007F00;
        regs[13] = 0x03007F00;
        regs[15] = 0x08000000; // ROM start
        cycles = 0;
    }

    // ── Cycle step ─────────────────────────────────────────────────────────
    /** Execute one instruction. Returns cycles consumed. */
    public int step() {
        if (halted || stopped) return 1;

        if (WIN_HI != 0) {
            int p = regs[15] & 0x0FFFFFFF;
            if (p >= WIN_LO && p <= WIN_HI && winPrinted < 300) {
                System.out.printf("W PC=%08X T=%d r0=%08X r1=%08X r2=%08X r3=%08X r4=%08X r5=%08X sp=%08X lr=%08X cpsr=%08X%n",
                    regs[15], isThumb()?1:0, regs[0], regs[1], regs[2], regs[3], regs[4], regs[5], regs[13], regs[14], cpsr);
                winPrinted++;
            }
        }

        if (TRACE_TARGET != 0) {
            boolean hit;
            if (TRACE_TARGET == 1) {
                long up = regs[15] & 0xFFFFFFFFL;
                long prev = lastStepPc & 0xFFFFFFFFL;
                // A control-flow change into BIOS/unmapped (<0x02000000) from valid memory.
                hit = up < 0x02000000L && prev >= 0x02000000L
                      && up != prev + 2 && up != prev + 4;
            } else {
                hit = (regs[15] & ~1) == (TRACE_TARGET & ~1);
            }
            pcRing[pcRingPos] = regs[15];
            pcRingPos = (pcRingPos + 1) & 63;
            lastStepPc = regs[15];
            if (hit && traceDumps < 2) {
                traceDumps++;
                System.out.println("==== reached " + Integer.toHexString(TRACE_TARGET)
                    + " | r14(LR)=" + Integer.toHexString(regs[14])
                    + " r0=" + Integer.toHexString(regs[0]) + " ====");
                for (int i = 0; i < 64; i++) {
                    int idx = (pcRingPos + i) & 63;
                    System.out.printf("  %2d: %08X%n", i - 64, pcRing[idx]);
                }
            }
        }

        if (isThumb()) {
            return stepThumb();
        } else {
            return stepARM();
        }
    }

    // ── ARM mode ───────────────────────────────────────────────────────────
    private int stepARM() {
        int pc = regs[15];
        int instr = bus.read32(pc & ~3);
        regs[15] = pc + 4;
        cycles += 1;

        if (!checkCondition((instr >>> 28) & 0xF)) return 1;

        int type = (instr >>> 25) & 0x7;
        int bit4 = (instr >>> 4) & 1;
        int bit7 = (instr >>> 7) & 1;

        // Decode
        if ((instr & 0x0FFFFFF0) == 0x012FFF10) {
            // BX
            return armBX(instr);
        } else if ((instr & 0x0E000000) == 0x0A000000) {
            // B / BL
            return armBranch(instr);
        } else if ((instr & 0x0FB00FF0) == 0x01000090) {
            // SWP / SWPB
            return armSWP(instr);
        } else if ((instr & 0x0FC000F0) == 0x00000090) {
            // MUL / MLA
            return armMultiply(instr);
        } else if ((instr & 0x0F8000F0) == 0x00800090) {
            // MULL / MLAL
            return armMultiplyLong(instr);
        } else if ((instr & 0x0E000090) == 0x00000090 && bit4 == 1 && bit7 == 1 && type < 2) {
            // Halfword data transfer
            return armHalfwordTransfer(instr);
        } else if ((instr & 0x0C000000) == 0x04000000) {
            // Single data transfer (LDR/STR)
            return armSingleTransfer(instr);
        } else if ((instr & 0x0E000000) == 0x08000000) {
            // Block data transfer (LDM/STM)
            return armBlockTransfer(instr);
        } else if ((instr & 0x0F000000) == 0x0F000000) {
            // SWI
            return armSWI(instr);
        } else if ((instr & 0x0C000000) == 0x00000000) {
            // Data processing / PSR transfer
            return armDataProcessing(instr);
        } else if ((instr & 0x0E000000) == 0x0C000000) {
            // Coprocessor - not used on GBA, ignore
            return 1;
        }

        return 1; // Undefined
    }

    // ── ARM: Condition check ───────────────────────────────────────────────
    private boolean checkCondition(int cond) {
        boolean n = (cpsr & FLAG_N) != 0;
        boolean z = (cpsr & FLAG_Z) != 0;
        boolean c = (cpsr & FLAG_C) != 0;
        boolean v = (cpsr & FLAG_V) != 0;
        switch (cond) {
            case 0x0: return z;
            case 0x1: return !z;
            case 0x2: return c;
            case 0x3: return !c;
            case 0x4: return n;
            case 0x5: return !n;
            case 0x6: return v;
            case 0x7: return !v;
            case 0x8: return c && !z;
            case 0x9: return !c || z;
            case 0xA: return n == v;
            case 0xB: return n != v;
            case 0xC: return !z && (n == v);
            case 0xD: return z || (n != v);
            case 0xE: return true;
            case 0xF: return false; // Never (or UNPREDICTABLE in some ARMs)
        }
        return false;
    }

    // ── ARM: Data Processing ───────────────────────────────────────────────
    private int armDataProcessing(int instr) {
        int opcode = (instr >>> 21) & 0xF;
        boolean s   = (instr & (1 << 20)) != 0;
        int rn = (instr >>> 16) & 0xF;
        int rd = (instr >>> 12) & 0xF;
        boolean imm = (instr & (1 << 25)) != 0;

        // MRS
        if ((instr & 0x0FBF0FFF) == 0x010F0000) {
            rd = (instr >>> 12) & 0xF;
            boolean useSPSR = (instr & (1 << 22)) != 0;
            regs[rd] = useSPSR ? spsr : cpsr;
            return 1;
        }
        // MSR
        if ((instr & 0x0FB0F000) == 0x0120F000) {
            boolean useSPSR = (instr & (1 << 22)) != 0;
            int operand = getShifterOperand(instr, false).value;
            int mask = 0;
            if ((instr & (1 << 16)) != 0) mask |= 0x000000FF;
            if ((instr & (1 << 17)) != 0) mask |= 0x0000FF00;
            if ((instr & (1 << 18)) != 0) mask |= 0x00FF0000;
            if ((instr & (1 << 19)) != 0) mask |= 0xFF000000;
            if (useSPSR) {
                spsr = (spsr & ~mask) | (operand & mask);
            } else {
                int oldMode = cpsr & 0x1F;
                cpsr = (cpsr & ~mask) | (operand & mask);
                int newMode = cpsr & 0x1F;
                if (oldMode != newMode) switchMode(oldMode, newMode);
            }
            return 1;
        }

        ShifterResult sr = getShifterOperand(instr, s);
        int rnVal = (rn == 15) ? (regs[15] + 4) : regs[rn];
        int op2 = sr.value;
        boolean shiftCarry = sr.carry;
        int result;
        boolean writeResult = true;
        boolean logical = false;
        int carryIn = (cpsr & FLAG_C) != 0 ? 1 : 0;

        switch (opcode) {
            case 0x0: result = rnVal & op2; logical = true; break;               // AND
            case 0x1: result = rnVal ^ op2; logical = true; break;               // EOR
            case 0x2: result = rnVal - op2; if (s) setSubFlags(rnVal, op2, result, true); break;            // SUB
            case 0x3: result = op2 - rnVal; if (s) setSubFlags(op2, rnVal, result, true); break;            // RSB
            case 0x4: result = rnVal + op2; if (s) setAddFlags(rnVal, op2, result, true); break;            // ADD
            case 0x5: result = rnVal + op2 + carryIn; if (s) setAddFlagsCarry(rnVal, op2, carryIn, result); break; // ADC
            case 0x6: result = rnVal - op2 - (1 - carryIn); if (s) setSubFlagsCarry(rnVal, op2, carryIn, result); break; // SBC
            case 0x7: result = op2 - rnVal - (1 - carryIn); if (s) setSubFlagsCarry(op2, rnVal, carryIn, result); break; // RSC
            case 0x8: result = rnVal & op2; writeResult = false; logical = true; if (s) { setNZFlags(result); setCPSRCarry(shiftCarry); } break; // TST
            case 0x9: result = rnVal ^ op2; writeResult = false; logical = true; if (s) { setNZFlags(result); setCPSRCarry(shiftCarry); } break; // TEQ
            case 0xA: result = rnVal - op2; writeResult = false; if (s) setSubFlags(rnVal, op2, result, true); break; // CMP
            case 0xB: result = rnVal + op2; writeResult = false; if (s) setAddFlags(rnVal, op2, result, true); break; // CMN
            case 0xC: result = rnVal | op2; logical = true; break;               // ORR
            case 0xD: result = op2; logical = true; break;                        // MOV
            case 0xE: result = rnVal & ~op2; logical = true; break;              // BIC
            case 0xF: result = ~op2; logical = true; break;                       // MVN
            default:  result = 0; break;
        }

        // Logical write-back ops set N,Z and carry-from-shifter; V unchanged.
        if (s && logical && writeResult) {
            setNZFlags(result);
            setCPSRCarry(shiftCarry);
        }

        if (writeResult) {
            if (rd == 15) {
                if (s) {
                    int oldMode = cpsr & 0x1F;
                    cpsr = spsr;
                    int newMode = cpsr & 0x1F;
                    if (oldMode != newMode) switchMode(oldMode, newMode);
                }
                if ((cpsr & FLAG_T) != 0) regs[15] = result & ~1;
                else                      regs[15] = result & ~3;
                pipelineFilled = false;
                return 3;
            }
            regs[rd] = result;
        }
        return 1;
    }

    private int sub(int a, int b, boolean s) { return a - b; }
    private int add(int a, int b, boolean s) { return a + b; }

    private void setSubFlags(int a, int b, int result, boolean s) {
        if (!s) return;
        setNZFlags(result);
        setCPSRCarry((Integer.toUnsignedLong(a) >= Integer.toUnsignedLong(b)));
        setCPSROverflow(((a ^ b) & (a ^ result)) < 0);
    }

    private void setAddFlags(int a, int b, int result, boolean s) {
        if (!s) return;
        setNZFlags(result);
        setCPSRCarry(Integer.toUnsignedLong(a) + Integer.toUnsignedLong(b) > 0xFFFFFFFFL);
        setCPSROverflow(!((a ^ b) < 0) && ((a ^ result) < 0));
    }

    private void setAddFlagsCarry(int a, int b, int carry, int result) {
        setNZFlags(result);
        setCPSRCarry(Integer.toUnsignedLong(a) + Integer.toUnsignedLong(b) + carry > 0xFFFFFFFFL);
        setCPSROverflow(!((a ^ b) < 0) && ((a ^ result) < 0));
    }

    private void setSubFlagsCarry(int a, int b, int carry, int result) {
        setNZFlags(result);
        long ua = Integer.toUnsignedLong(a);
        long ub = Integer.toUnsignedLong(b);
        setCPSRCarry(ua >= ub + (1 - carry));
        setCPSROverflow(((a ^ b) & (a ^ result)) < 0);
    }

    private void setNZFlags(int result) {
        if (result < 0)  cpsr |= FLAG_N; else cpsr &= ~FLAG_N;
        if (result == 0) cpsr |= FLAG_Z; else cpsr &= ~FLAG_Z;
    }

    private void setCPSRCarry(boolean c) {
        if (c) cpsr |= FLAG_C; else cpsr &= ~FLAG_C;
    }

    private void setCPSROverflow(boolean v) {
        if (v) cpsr |= FLAG_V; else cpsr &= ~FLAG_V;
    }

    // ── Shifter operand ────────────────────────────────────────────────────
    private ShifterResult getShifterOperand(int instr, boolean s) {
        boolean immForm = (instr & (1 << 25)) != 0;
        if (immForm) {
            int imm8  = instr & 0xFF;
            int rot   = ((instr >>> 8) & 0xF) << 1;
            int val   = Integer.rotateRight(imm8, rot);
            boolean carry = rot == 0 ? ((cpsr & FLAG_C) != 0) : ((val >> 31) != 0);
            return new ShifterResult(val, carry);
        }
        // Register form
        int rm = instr & 0xF;
        int rmVal = regs[rm];
        if (rm == 15) rmVal += 4; // regs[15] is instrAddr+4; PC operand = instrAddr+8
        int shiftType = (instr >>> 5) & 0x3;
        boolean regShift = (instr & (1 << 4)) != 0;
        int shiftAmt;
        if (regShift) {
            int rs = (instr >>> 8) & 0xF;
            shiftAmt = regs[rs] & 0xFF;
        } else {
            shiftAmt = (instr >>> 7) & 0x1F;
        }
        return applyShift(rmVal, shiftType, shiftAmt, regShift);
    }

    private ShifterResult applyShift(int val, int type, int amount, boolean isRegShift) {
        boolean carry = (cpsr & FLAG_C) != 0;
        if (amount == 0 && !isRegShift) {
            if (type == 3) {
                // RRX
                boolean oldCarry = carry;
                carry = (val & 1) != 0;
                val = (val >>> 1) | (oldCarry ? (1 << 31) : 0);
            }
            return new ShifterResult(val, carry);
        }
        switch (type) {
            case 0: // LSL
                if (amount >= 32) { carry = amount == 32 && (val & 1) != 0; val = 0; }
                else if (amount > 0) { carry = (val >>> (32 - amount)) != 0; val <<= amount; }
                break;
            case 1: // LSR
                if (amount >= 32) { carry = amount == 32 && (val < 0); val = 0; }
                else if (amount > 0) { carry = ((val >>> (amount - 1)) & 1) != 0; val >>>= amount; }
                break;
            case 2: // ASR
                if (amount >= 32) { carry = val < 0; val = val < 0 ? -1 : 0; }
                else if (amount > 0) { carry = ((val >>> (amount - 1)) & 1) != 0; val >>= amount; }
                break;
            case 3: // ROR
                amount &= 31;
                if (amount > 0) { carry = ((val >>> (amount - 1)) & 1) != 0; val = Integer.rotateRight(val, amount); }
                break;
        }
        return new ShifterResult(val, carry);
    }

    // ── ARM: Branch ────────────────────────────────────────────────────────
    private int armBranch(int instr) {
        // On entry regs[15] = instrAddr + 4 (set during fetch in stepARM).
        // ARM execution PC value is instrAddr + 8, so branch target = regs[15] + 4 + offset.
        boolean link = (instr & (1 << 24)) != 0;
        int offset = (instr << 8) >> 6; // sign-extend 24-bit, shift left 2
        if (link) regs[14] = regs[15]; // return address = instrAddr + 4 = next instruction
        regs[15] = regs[15] + 4 + offset;
        pipelineFilled = false;
        return 3;
    }

    // Corrected branch with proper accounting
    private int armBranchCorrect(int instrAddr, int instr) {
        boolean link = (instr & (1 << 24)) != 0;
        int offset = (instr << 8) >> 6;
        if (link) regs[14] = instrAddr + 4;
        regs[15] = instrAddr + 8 + offset;
        pipelineFilled = false;
        return 3;
    }

    // ── ARM: Branch and Exchange ───────────────────────────────────────────
    private int armBX(int instr) {
        int rm = instr & 0xF;
        int target = regs[rm];
        if ((target & 1) != 0) {
            cpsr |= FLAG_T;
            regs[15] = target & ~1;
        } else {
            cpsr &= ~FLAG_T;
            regs[15] = target & ~3;
        }
        pipelineFilled = false;
        return 3;
    }

    // ── ARM: Multiply ──────────────────────────────────────────────────────
    private int armMultiply(int instr) {
        boolean accumulate = (instr & (1 << 21)) != 0;
        boolean s = (instr & (1 << 20)) != 0;
        int rd = (instr >>> 16) & 0xF;
        int rn = (instr >>> 12) & 0xF;
        int rs = (instr >>> 8)  & 0xF;
        int rm = instr & 0xF;

        long result = Integer.toUnsignedLong(regs[rm]) * Integer.toUnsignedLong(regs[rs]);
        if (accumulate) result += regs[rn];
        regs[rd] = (int) result;
        if (s) setNZFlags(regs[rd]);
        return accumulate ? 4 : 3;
    }

    private int armMultiplyLong(int instr) {
        boolean sign     = (instr & (1 << 22)) != 0;
        boolean accumulate = (instr & (1 << 21)) != 0;
        boolean s        = (instr & (1 << 20)) != 0;
        int rdHi = (instr >>> 16) & 0xF;
        int rdLo = (instr >>> 12) & 0xF;
        int rs   = (instr >>> 8)  & 0xF;
        int rm   = instr & 0xF;

        long result;
        if (sign) {
            result = (long)regs[rm] * (long)regs[rs];
        } else {
            result = Integer.toUnsignedLong(regs[rm]) * Integer.toUnsignedLong(regs[rs]);
        }
        if (accumulate) {
            long acc = ((long)regs[rdHi] << 32) | Integer.toUnsignedLong(regs[rdLo]);
            result += acc;
        }
        regs[rdLo] = (int) result;
        regs[rdHi] = (int)(result >>> 32);
        if (s) {
            if (result < 0) cpsr |= FLAG_N; else cpsr &= ~FLAG_N;
            if (result == 0) cpsr |= FLAG_Z; else cpsr &= ~FLAG_Z;
        }
        return accumulate ? 5 : 4;
    }

    // ── ARM: SWP ──────────────────────────────────────────────────────────
    private int armSWP(int instr) {
        boolean byte_ = (instr & (1 << 22)) != 0;
        int rn = (instr >>> 16) & 0xF;
        int rd = (instr >>> 12) & 0xF;
        int rm = instr & 0xF;
        int addr = regs[rn];
        if (byte_) {
            int tmp = bus.read8(addr) & 0xFF;
            bus.write8(addr, (byte) regs[rm]);
            regs[rd] = tmp;
        } else {
            int tmp = bus.read32(addr);
            bus.write32(addr, regs[rm]);
            regs[rd] = tmp;
        }
        return 4;
    }

    // ── ARM: Single Data Transfer ──────────────────────────────────────────
    private int armSingleTransfer(int instr) {
        boolean imm    = (instr & (1 << 25)) == 0;
        boolean pre    = (instr & (1 << 24)) != 0;
        boolean up     = (instr & (1 << 23)) != 0;
        boolean byte_  = (instr & (1 << 22)) != 0;
        boolean wb     = (instr & (1 << 21)) != 0;
        boolean load   = (instr & (1 << 20)) != 0;
        int rn = (instr >>> 16) & 0xF;
        int rd = (instr >>> 12) & 0xF;

        int base = regs[rn];
        if (rn == 15) base += 4; // regs[15] is instrAddr+4; PC base = instrAddr+8

        int offset;
        if (imm) {
            offset = instr & 0xFFF;
        } else {
            int rm = instr & 0xF;
            int shiftType = (instr >>> 5) & 0x3;
            int shiftAmt  = (instr >>> 7) & 0x1F;
            offset = applyShift(regs[rm], shiftType, shiftAmt, false).value;
        }

        int addr = pre ? (up ? base + offset : base - offset) : base;

        if (load) {
            if (byte_) {
                regs[rd] = bus.read8(addr) & 0xFF;
            } else {
                regs[rd] = bus.read32(addr);
                // Rotate unaligned reads
                int rot = (addr & 3) * 8;
                if (rot != 0) regs[rd] = Integer.rotateRight(regs[rd], rot);
            }
            if (rd == 15) { regs[15] &= ~3; pipelineFilled = false; }
        } else {
            int val = regs[rd];
            if (rd == 15) val += 12;
            if (byte_) bus.write8(addr, (byte) val);
            else        bus.write32(addr, val);
        }

        if (!pre) addr = up ? base + offset : base - offset;
        if ((!load || rd != rn) && (wb || !pre)) regs[rn] = addr;

        return load ? 3 : 2;
    }

    // ── ARM: Halfword Data Transfer ────────────────────────────────────────
    private int armHalfwordTransfer(int instr) {
        boolean pre    = (instr & (1 << 24)) != 0;
        boolean up     = (instr & (1 << 23)) != 0;
        boolean imm    = (instr & (1 << 22)) != 0;
        boolean wb     = (instr & (1 << 21)) != 0;
        boolean load   = (instr & (1 << 20)) != 0;
        int rn = (instr >>> 16) & 0xF;
        int rd = (instr >>> 12) & 0xF;
        int sh = (instr >>> 5) & 0x3;

        int offset = imm ? ((instr & 0xF00) >>> 4) | (instr & 0xF) : regs[instr & 0xF];
        int base   = regs[rn];
        int addr   = pre ? (up ? base + offset : base - offset) : base;

        if (load) {
            switch (sh) {
                case 1: regs[rd] = bus.read16(addr) & 0xFFFF; break;          // LDRH
                case 2: regs[rd] = (byte)(bus.read8(addr) & 0xFF); break;      // LDRSB
                case 3: regs[rd] = (short)(bus.read16(addr) & 0xFFFF); break;  // LDRSH
            }
        } else {
            if (sh == 1) bus.write16(addr, (short) regs[rd]);                  // STRH
        }

        if (!pre) addr = up ? base + offset : base - offset;
        if (!load || rd != rn) {
            if (wb || !pre) regs[rn] = addr;
        }
        return load ? 3 : 2;
    }

    // ── ARM: Block Data Transfer ───────────────────────────────────────────
    private int armBlockTransfer(int instr) {
        boolean pre    = (instr & (1 << 24)) != 0;
        boolean up     = (instr & (1 << 23)) != 0;
        boolean s      = (instr & (1 << 22)) != 0;
        boolean wb     = (instr & (1 << 21)) != 0;
        boolean load   = (instr & (1 << 20)) != 0;
        int rn = (instr >>> 16) & 0xF;
        int regList = instr & 0xFFFF;

        int base  = regs[rn];
        int count = Integer.bitCount(regList);
        if (count == 0) count = 0; // empty list edge case ignored

        // Lowest address accessed and the writeback base value.
        int addr;
        int finalBase;
        if (up) {
            finalBase = base + count * 4;
            addr = pre ? base + 4 : base;            // IB : IA
        } else {
            finalBase = base - count * 4;
            addr = pre ? base - count * 4            // DB
                       : base - count * 4 + 4;       // DA
        }

        boolean restoreCpsr = false;
        // Registers are always accessed lowest-numbered at lowest address.
        for (int i = 0; i < 16; i++) {
            if ((regList & (1 << i)) != 0) {
                if (load) {
                    regs[i] = bus.read32(addr);
                    if (i == 15) {
                        if (s) restoreCpsr = true;
                        if ((regs[15] & 1) != 0 && s) { /* thumb via spsr handled below */ }
                        regs[15] &= ~1;
                        pipelineFilled = false;
                    }
                } else {
                    int val = regs[i];
                    if (i == 15) val += 8; // stored PC = instrAddr + 12 (regs[15] is instrAddr+4)
                    bus.write32(addr, val);
                }
                addr += 4;
            }
        }

        if (wb && (!load || (regList & (1 << rn)) == 0)) {
            regs[rn] = finalBase;
        }

        if (restoreCpsr) {
            int oldMode = cpsr & 0x1F;
            cpsr = spsr;
            int newMode = cpsr & 0x1F;
            if (oldMode != newMode) switchMode(oldMode, newMode);
            if ((cpsr & FLAG_T) != 0) regs[15] &= ~1; else regs[15] &= ~3;
        }

        return count + (load ? 2 : 1);
    }

    // ── ARM: SWI ──────────────────────────────────────────────────────────
    private int armSWI(int instr) {
        int comment = (instr >>> 16) & 0xFF;
        return hleSWI(comment);
    }

    // ── Thumb mode ─────────────────────────────────────────────────────────
    private int stepThumb() {
        int pc = regs[15];
        int instr = bus.read16(pc & ~1) & 0xFFFF;
        regs[15] = pc + 2;
        cycles += 1;

        int top5 = instr >>> 11;
        int top3 = instr >>> 13;

        if (top5 == 0x1E || top5 == 0x1F) { return thumbBL(instr, pc); }
        else if ((instr & 0xFF00) == 0xDF00) { return thumbSWI(instr); }
        else if ((instr & 0xFF00) == 0xBE00) { return 1; } // BKPT
        else if ((instr & 0xF000) == 0xE000) { return thumbBranch(instr); }
        else if ((instr & 0xF000) == 0xD000) { return thumbCondBranch(instr); }
        else if ((instr & 0xF000) == 0xC000) { return thumbLDMSTM(instr); }
        else if ((instr & 0xFF00) == 0xB000) { return thumbAddSP(instr); }
        else if ((instr & 0xF600) == 0xB400) { return thumbPushPop(instr); }
        else if ((instr & 0xF000) == 0xA000) { return thumbLoadAddr(instr); }
        else if ((instr & 0xF000) == 0x9000) { return thumbSPRelLoad(instr); }
        else if ((instr & 0xF000) == 0x8000) { return thumbHalfword(instr); }
        else if ((instr & 0xE000) == 0x6000) { return thumbLoadStore(instr); }
        else if ((instr & 0xF200) == 0x5200) { return thumbLoadStoreSH(instr); }
        else if ((instr & 0xF200) == 0x5000) { return thumbLoadStoreReg(instr); }
        else if ((instr & 0xF800) == 0x4800) { return thumbLoadPCRel(instr); }
        else if ((instr & 0xE000) == 0x4000) {
            if ((instr & 0xFF00) == 0x4700) return thumbBX(instr);
            else if ((instr & 0xFC00) == 0x4400) return thumbHiOps(instr);
            else return thumbALU(instr);
        }
        else if ((instr & 0xE000) == 0x2000) { return thumbImm(instr); }
        else if ((instr & 0xF800) == 0x1800) { return thumbAddSub(instr); }
        else if (top3 == 0) { return thumbMoveShift(instr); }

        return 1;
    }

    private int thumbMoveShift(int instr) {
        int op     = (instr >>> 11) & 0x3;
        int offset = (instr >>> 6) & 0x1F;
        int rs     = (instr >>> 3) & 0x7;
        int rd     = instr & 0x7;
        ShifterResult sr = applyShift(regs[rs], op, offset, false);
        regs[rd] = sr.value;
        setNZFlags(regs[rd]);
        setCPSRCarry(sr.carry);
        cpsr &= ~FLAG_V;
        return 1;
    }

    private int thumbAddSub(int instr) {
        boolean imm = (instr & (1 << 10)) != 0;
        boolean sub = (instr & (1 << 9))  != 0;
        int rs = (instr >>> 3) & 0x7;
        int rd = instr & 0x7;
        int op2 = imm ? ((instr >>> 6) & 0x7) : regs[(instr >>> 6) & 0x7];
        if (sub) { regs[rd] = regs[rs] - op2; setSubFlags(regs[rs], op2, regs[rd], true); }
        else      { regs[rd] = regs[rs] + op2; setAddFlags(regs[rs], op2, regs[rd], true); }
        return 1;
    }

    private int thumbImm(int instr) {
        int op  = (instr >>> 11) & 0x3;
        int rd  = (instr >>> 8)  & 0x7;
        int imm = instr & 0xFF;
        switch (op) {
            case 0: regs[rd] = imm; setNZFlags(regs[rd]); break; // MOV
            case 1: { long r = Integer.toUnsignedLong(regs[rd]) - imm; setSubFlags(regs[rd], imm, (int)r, true); break; } // CMP
            case 2: { int r = regs[rd] + imm; setAddFlags(regs[rd], imm, r, true); regs[rd] = r; break; } // ADD
            case 3: { int r = regs[rd] - imm; setSubFlags(regs[rd], imm, r, true); regs[rd] = r; break; } // SUB
        }
        return 1;
    }

    private int thumbALU(int instr) {
        int op = (instr >>> 6) & 0xF;
        int rs = (instr >>> 3) & 0x7;
        int rd = instr & 0x7;
        int rsVal = regs[rs];
        int rdVal = regs[rd];
        int result;
        switch (op) {
            case 0x0: result = rdVal & rsVal; setNZFlags(result); regs[rd] = result; break; // AND
            case 0x1: result = rdVal ^ rsVal; setNZFlags(result); regs[rd] = result; break; // EOR
            case 0x2: { // LSL
                int amt = rsVal & 0xFF;
                boolean c = amt == 0 ? ((cpsr & FLAG_C) != 0) : amt < 32 ? ((rdVal >>> (32 - amt)) & 1) != 0 : (amt == 32 && (rdVal & 1) != 0);
                result = amt >= 32 ? 0 : rdVal << amt;
                regs[rd] = result; setNZFlags(result); setCPSRCarry(c); break;
            }
            case 0x3: { // LSR
                int amt = rsVal & 0xFF;
                boolean c = amt == 0 ? ((cpsr & FLAG_C) != 0) : amt < 32 ? ((rdVal >>> (amt-1)) & 1) != 0 : (amt == 32 && rdVal < 0);
                result = amt >= 32 ? 0 : rdVal >>> amt;
                regs[rd] = result; setNZFlags(result); setCPSRCarry(c); break;
            }
            case 0x4: { // ASR
                int amt = rsVal & 0xFF; if (amt > 31) amt = 31;
                boolean c = ((rdVal >>> (amt == 0 ? 0 : amt-1)) & 1) != 0;
                result = rdVal >> amt;
                regs[rd] = result; setNZFlags(result); setCPSRCarry(c); break;
            }
            case 0x5: { int c=(cpsr&FLAG_C)!=0?1:0; result=rdVal+rsVal+c; setAddFlagsCarry(rdVal,rsVal,c,result); regs[rd]=result; break; } // ADC
            case 0x6: { int c=(cpsr&FLAG_C)!=0?1:0; result=rdVal-rsVal-(1-c); setSubFlagsCarry(rdVal,rsVal,c,result); regs[rd]=result; break; } // SBC
            case 0x7: { // ROR
                int amt = rsVal & 0xFF;
                boolean c = amt == 0 ? ((cpsr & FLAG_C) != 0) : ((rdVal >>> ((amt-1)&31)) & 1) != 0;
                result = amt == 0 ? rdVal : Integer.rotateRight(rdVal, amt & 31);
                regs[rd] = result; setNZFlags(result); setCPSRCarry(c); break;
            }
            case 0x8: result = rdVal & rsVal; setNZFlags(result); break; // TST
            case 0x9: result = -rsVal; setSubFlags(0, rsVal, result, true); regs[rd] = result; break; // NEG
            case 0xA: { long r=(long)rdVal-rsVal; setSubFlags(rdVal,rsVal,(int)r,true); break; } // CMP
            case 0xB: { long r=(long)rdVal+rsVal; setAddFlags(rdVal,rsVal,(int)r,true); break; } // CMN
            case 0xC: result = rdVal | rsVal; setNZFlags(result); regs[rd] = result; break; // ORR
            case 0xD: { result = rdVal * rsVal; regs[rd] = result; setNZFlags(result); break; } // MUL
            case 0xE: result = rdVal & ~rsVal; setNZFlags(result); regs[rd] = result; break; // BIC
            case 0xF: result = ~rsVal; setNZFlags(result); regs[rd] = result; break; // MVN
            default: break;
        }
        return 1;
    }

    private int thumbHiOps(int instr) {
        int op  = (instr >>> 8) & 0x3;
        int h1  = (instr >>> 7) & 0x1;
        int h2  = (instr >>> 6) & 0x1;
        int rs  = ((instr >>> 3) & 0x7) | (h2 << 3);
        int rd  = (instr & 0x7) | (h1 << 3);
        int rsVal = regs[rs];
        switch (op) {
            case 0: regs[rd] = regs[rd] + rsVal; if (rd == 15) { regs[15] &= ~1; pipelineFilled = false; } break; // ADD
            case 1: { long r = (long)regs[rd] - rsVal; setSubFlags(regs[rd], rsVal, (int)r, true); break; } // CMP
            case 2: regs[rd] = rsVal; if (rd == 15) { regs[15] &= ~1; pipelineFilled = false; } break; // MOV
        }
        return op == 0 || op == 2 ? (rd == 15 ? 3 : 1) : 1;
    }

    private int thumbBX(int instr) {
        int rs = (instr >>> 3) & 0xF;
        int target = regs[rs];
        if ((target & 1) != 0) {
            cpsr |= FLAG_T;
            regs[15] = target & ~1;
        } else {
            cpsr &= ~FLAG_T;
            regs[15] = target & ~3;
        }
        pipelineFilled = false;
        return 3;
    }

    private int thumbLoadStore(int instr) {
        boolean load   = (instr & (1 << 11)) != 0;
        boolean byte_  = (instr & (1 << 12)) != 0;
        int offset = ((instr >>> 6) & 0x1F) << (byte_ ? 0 : 2);
        int rb = (instr >>> 3) & 0x7;
        int rd = instr & 0x7;
        int addr = regs[rb] + offset;
        if (load) {
            regs[rd] = byte_ ? (bus.read8(addr) & 0xFF) : bus.read32(addr);
        } else {
            if (byte_) bus.write8(addr, (byte) regs[rd]);
            else       bus.write32(addr, regs[rd]);
        }
        return load ? 3 : 2;
    }

    private int thumbLoadStoreReg(int instr) {
        boolean load = (instr & (1 << 11)) != 0;
        boolean byte_ = (instr & (1 << 10)) != 0;
        int ro = (instr >>> 6) & 0x7;
        int rb = (instr >>> 3) & 0x7;
        int rd = instr & 0x7;
        int addr = regs[rb] + regs[ro];
        if (load) {
            regs[rd] = byte_ ? (bus.read8(addr) & 0xFF) : bus.read32(addr);
        } else {
            if (byte_) bus.write8(addr, (byte) regs[rd]);
            else       bus.write32(addr, regs[rd]);
        }
        return load ? 3 : 2;
    }

    private int thumbLoadStoreSH(int instr) {
        int op = (instr >>> 10) & 0x3;
        int ro = (instr >>> 6) & 0x7;
        int rb = (instr >>> 3) & 0x7;
        int rd = instr & 0x7;
        int addr = regs[rb] + regs[ro];
        switch (op) {
            case 0: bus.write16(addr, (short) regs[rd]); break;  // STRH
            case 1: regs[rd] = (byte)(bus.read8(addr)); break;   // LDSB
            case 2: regs[rd] = bus.read16(addr) & 0xFFFF; break; // LDRH
            case 3: regs[rd] = (short)(bus.read16(addr)); break;  // LDSH
        }
        return op == 0 ? 2 : 3;
    }

    private int thumbHalfword(int instr) {
        boolean load   = (instr & (1 << 11)) != 0;
        int offset = ((instr >>> 6) & 0x1F) << 1;
        int rb = (instr >>> 3) & 0x7;
        int rd = instr & 0x7;
        int addr = regs[rb] + offset;
        if (load) regs[rd] = bus.read16(addr) & 0xFFFF;
        else      bus.write16(addr, (short) regs[rd]);
        return load ? 3 : 2;
    }

    private int thumbSPRelLoad(int instr) {
        boolean load = (instr & (1 << 11)) != 0;
        int rd  = (instr >>> 8) & 0x7;
        int offset = (instr & 0xFF) << 2;
        int addr = regs[13] + offset;
        if (load) regs[rd] = bus.read32(addr);
        else      bus.write32(addr, regs[rd]);
        return load ? 3 : 2;
    }

    private int thumbLoadAddr(int instr) {
        boolean sp = (instr & (1 << 11)) != 0;
        int rd  = (instr >>> 8) & 0x7;
        int offset = (instr & 0xFF) << 2;
        if (sp) regs[rd] = regs[13] + offset;
        else    regs[rd] = ((regs[15] + 2) & ~3) + offset;
        return 1;
    }

    private int thumbAddSP(int instr) {
        boolean neg = (instr & (1 << 7)) != 0;
        int offset  = (instr & 0x7F) << 2;
        regs[13] += neg ? -offset : offset;
        return 1;
    }

    private int thumbPushPop(int instr) {
        boolean load  = (instr & (1 << 11)) != 0;
        boolean lr    = (instr & (1 << 8))  != 0;
        int regList   = instr & 0xFF;

        if (!load) {
            if (lr) regs[13] -= 4;
            for (int i = 7; i >= 0; i--) {
                if ((regList & (1 << i)) != 0) regs[13] -= 4;
            }
            int addr = regs[13];
            for (int i = 0; i < 8; i++) {
                if ((regList & (1 << i)) != 0) { bus.write32(addr, regs[i]); addr += 4; }
            }
            if (lr) { bus.write32(addr, regs[14]); }
        } else {
            int addr = regs[13];
            for (int i = 0; i < 8; i++) {
                if ((regList & (1 << i)) != 0) { regs[i] = bus.read32(addr); addr += 4; regs[13] += 4; }
            }
            if (lr) {
                int target = bus.read32(addr);
                regs[13] += 4;
                if ((target & 1) != 0) { regs[15] = target & ~1; }
                else { cpsr &= ~FLAG_T; regs[15] = target & ~3; }
                pipelineFilled = false;
            }
        }
        return Integer.bitCount(regList) + (lr ? 1 : 0) + (load ? 2 : 1);
    }

    private int thumbLDMSTM(int instr) {
        boolean load  = (instr & (1 << 11)) != 0;
        int rb      = (instr >>> 8) & 0x7;
        int regList = instr & 0xFF;
        int addr    = regs[rb];

        for (int i = 0; i < 8; i++) {
            if ((regList & (1 << i)) != 0) {
                if (load) regs[i] = bus.read32(addr);
                else      bus.write32(addr, regs[i]);
                addr += 4;
            }
        }
        regs[rb] = addr;
        return Integer.bitCount(regList) + (load ? 2 : 1);
    }

    private int thumbCondBranch(int instr) {
        int cond   = (instr >>> 8) & 0xF;
        if (!checkCondition(cond)) return 1;
        int offset = (int)(byte)(instr & 0xFF);
        regs[15] += (offset << 1) + 2; // PC = instrAddr+4 = regs[15]+2
        pipelineFilled = false;
        return 3;
    }

    private int thumbBranch(int instr) {
        int offset = ((instr & 0x7FF) << 21) >> 20;
        regs[15] += offset + 2; // PC = instrAddr+4 = regs[15]+2
        pipelineFilled = false;
        return 3;
    }

    private int thumbBL(int instr, int pc) {
        boolean second = (instr & (1 << 11)) != 0;
        if (!second) {
            // High part: LR = (instrAddr + 4) + signext(offset11) << 12.
            int off = ((instr & 0x7FF) << 21) >> 9;
            regs[14] = (regs[15] + 2) + off;
        } else {
            // Low part: target = LR + offset11<<1; new LR = return addr | 1.
            int off = (instr & 0x7FF) << 1;
            int target = regs[14] + off;
            regs[14] = regs[15] | 1;     // regs[15] = instrAddr_2 + 2 = addr after BL
            regs[15] = target & ~1;
            pipelineFilled = false;
            return 4;
        }
        return 1;
    }

    private int thumbLoadPCRel(int instr) {
        int rd = (instr >>> 8) & 0x7;
        int offset = (instr & 0xFF) << 2;
        int addr = ((regs[15] + 2) & ~3) + offset; // PC = instrAddr + 4, word aligned
        regs[rd] = bus.read32(addr);
        return 3;
    }

    private int thumbSWI(int instr) {
        int comment = instr & 0xFF;
        return hleSWI(comment);
    }

    // ── BIOS High-Level Emulation ───────────────────────────────────────────
    // Performs the BIOS function in Java and returns to the instruction after
    // the SWI. No mode switch or BIOS code execution is needed.
    private int hleSWI(int comment) {
        if (DEBUG_SWI && swiLogCount < 80) {
            System.out.printf("[SWI %02X] r0=%08X r1=%08X r2=%08X PC=%08X%n",
                    comment, regs[0], regs[1], regs[2], regs[15]);
            swiLogCount++;
        }
        switch (comment) {
            case 0x00: // SoftReset
                softReset();
                return 3;
            case 0x01: // RegisterRamReset
                registerRamReset(regs[0]);
                return 3;
            case 0x02: // Halt
                halted = true;
                return 3;
            case 0x03: // Stop / Sleep — treat like Halt
                halted = true;
                return 3;
            case 0x04: // IntrWait(r0=discardOld, r1=mask)
                return intrWait(regs[0] != 0, regs[1]);
            case 0x05: // VBlankIntrWait == IntrWait(1, 1)
                return intrWait(true, 0x0001);
            case 0x06: { // Div: r0=num, r1=den -> r0=quot, r1=rem, r3=abs(quot)
                int num = regs[0], den = regs[1];
                if (den != 0) {
                    regs[0] = num / den;
                    regs[1] = num % den;
                    regs[3] = Math.abs(regs[0]);
                }
                return 3;
            }
            case 0x07: { // DivArm: r0=den, r1=num
                int den = regs[0], num = regs[1];
                if (den != 0) {
                    regs[0] = num / den;
                    regs[1] = num % den;
                    regs[3] = Math.abs(regs[0]);
                }
                return 3;
            }
            case 0x08: { // Sqrt(r0) unsigned
                long v = regs[0] & 0xFFFFFFFFL;
                regs[0] = (int)Math.sqrt((double)v);
                return 3;
            }
            case 0x09: { // ArcTan
                regs[0] = arcTan(regs[0]);
                return 3;
            }
            case 0x0A: { // ArcTan2
                regs[0] = arcTan2(regs[0], regs[1]);
                return 3;
            }
            case 0x0B: // CpuSet
                cpuSet(regs[0], regs[1], regs[2]);
                return 3;
            case 0x0C: // CpuFastSet
                cpuFastSet(regs[0], regs[1], regs[2]);
                return 3;
            case 0x0D: // GetBiosChecksum
                regs[0] = 0xBAAE187F; // value of the real GBA BIOS
                return 3;
            case 0x0E: // BgAffineSet
                bgAffineSet(regs[0], regs[1], regs[2]);
                return 3;
            case 0x0F: // ObjAffineSet
                objAffineSet(regs[0], regs[1], regs[2], regs[3]);
                return 3;
            case 0x10: // BitUnPack
                bitUnPack(regs[0], regs[1], regs[2]);
                return 3;
            case 0x11: // LZ77UnCompWram (8-bit writes)
                lz77UnComp(regs[0], regs[1], false);
                return 3;
            case 0x12: // LZ77UnCompVram (16-bit writes)
                lz77UnComp(regs[0], regs[1], true);
                return 3;
            case 0x13: // HuffUnComp
                huffUnComp(regs[0], regs[1]);
                return 3;
            case 0x14: // RLUnCompWram
                rlUnComp(regs[0], regs[1], false);
                return 3;
            case 0x15: // RLUnCompVram
                rlUnComp(regs[0], regs[1], true);
                return 3;
            case 0x16: // Diff8bitUnFilterWram
                diffUnFilter(regs[0], regs[1], 8, false);
                return 3;
            case 0x17: // Diff8bitUnFilterVram
                diffUnFilter(regs[0], regs[1], 8, true);
                return 3;
            case 0x18: // Diff16bitUnFilter
                diffUnFilter(regs[0], regs[1], 16, true);
                return 3;
            case 0x19: // SoundBias — no-op
                return 3;
            case 0x1F: // MidiKey2Freq — approximate, rarely critical
                regs[0] = 0;
                return 3;
            case 0x25: // MultiBoot — report success/none
                regs[0] = 1;
                return 3;
            default:
                // Unknown SWI — ignore and continue.
                return 3;
        }
    }

    // VBlankIntrWait / IntrWait HLE: spin by re-running the SWI until the
    // requested interrupt has been acknowledged (BIOS_IF flags at 0x03007FF8).
    private int intrWait(boolean discardOld, int mask) {
        if (!intrWaitActive) {
            intrWaitActive = true;
            intrWaitMask = mask;
            if (discardOld) {
                int cur = bus.read16(BIOS_IF_ADDR) & 0xFFFF;
                bus.write16(BIOS_IF_ADDR, (short)(cur & ~mask));
            }
        }
        int flags = bus.read16(BIOS_IF_ADDR) & 0xFFFF;
        if ((flags & intrWaitMask) != 0) {
            // Acknowledge matched bits and finish.
            bus.write16(BIOS_IF_ADDR, (short)(flags & ~intrWaitMask));
            intrWaitActive = false;
            return 3;
        }
        // Not yet — halt and rewind PC so the SWI re-runs when an IRQ wakes us.
        halted = true;
        if ((cpsr & FLAG_T) != 0) regs[15] -= 2; else regs[15] -= 4;
        return 3;
    }

    private void softReset() {
        for (int i = 0; i < 16; i++) regs[i] = 0;
        cpsr = MODE_SYS;
        bankedR13[modeIndex(MODE_SVC)] = 0x03007FE0;
        bankedR13[modeIndex(MODE_IRQ)] = 0x03007FA0;
        bankedR13[modeIndex(MODE_SYS)] = 0x03007F00;
        regs[13] = 0x03007F00;
        regs[15] = 0x08000000;
        intrWaitActive = false;
        halted = false;
        pipelineFilled = false;
    }

    private void registerRamReset(int flags) {
        if ((flags & 0x01) != 0) for (int a = 0x02000000; a < 0x02040000; a += 4) bus.write32(a, 0); // EWRAM
        if ((flags & 0x02) != 0) for (int a = 0x03000000; a < 0x03007E00; a += 4) bus.write32(a, 0); // IWRAM (keep BIOS area)
        if ((flags & 0x04) != 0) for (int a = 0x05000000; a < 0x05000400; a += 4) bus.write32(a, 0); // Palette
        if ((flags & 0x08) != 0) for (int a = 0x06000000; a < 0x06018000; a += 4) bus.write32(a, 0); // VRAM
        if ((flags & 0x10) != 0) for (int a = 0x07000000; a < 0x07000400; a += 4) bus.write32(a, 0); // OAM
        // Bits 5-7 reset SIO/sound/other registers — clear common display regs.
        if ((flags & 0x80) != 0) { bus.write16(0x04000000, (short)0x0080); }
    }

    private int arcTan(int tan) {
        // BIOS ArcTan: input/output in 1.14/1.16-ish fixed point. Approximate.
        double x = tan / 16384.0;
        double r = Math.atan(x);
        return (int)(r * 0x10000 / (2 * Math.PI)) & 0xFFFF;
    }

    private int arcTan2(int x, int y) {
        double r = Math.atan2((short)y, (short)x);
        if (r < 0) r += 2 * Math.PI;
        return (int)(r * 0x10000 / (2 * Math.PI)) & 0xFFFF;
    }

    private void cpuSet(int src, int dst, int control) {
        int count = control & 0x1FFFFF;
        boolean fixed = (control & (1 << 24)) != 0;
        boolean word  = (control & (1 << 26)) != 0;
        if (word) {
            src &= ~3; dst &= ~3;
            int val = bus.read32(src);
            for (int i = 0; i < count; i++) {
                if (!fixed) val = bus.read32(src + i * 4);
                bus.write32(dst + i * 4, val);
            }
        } else {
            src &= ~1; dst &= ~1;
            int val = bus.read16(src) & 0xFFFF;
            for (int i = 0; i < count; i++) {
                if (!fixed) val = bus.read16(src + i * 2) & 0xFFFF;
                bus.write16(dst + i * 2, (short)val);
            }
        }
    }

    private void cpuFastSet(int src, int dst, int control) {
        int count = control & 0x1FFFFF;
        boolean fixed = (control & (1 << 24)) != 0;
        count = (count + 7) & ~7; // rounded up to 8 words
        src &= ~3; dst &= ~3;
        int val = bus.read32(src);
        for (int i = 0; i < count; i++) {
            if (!fixed) val = bus.read32(src + i * 4);
            bus.write32(dst + i * 4, val);
        }
    }

    private void bgAffineSet(int src, int dst, int count) {
        for (int i = 0; i < count; i++) {
            int sx = bus.read32(src);       // origin x (s32 24.8)
            int sy = bus.read32(src + 4);   // origin y
            int cx = bus.read16(src + 8) & 0xFFFF;  // display center x (s16)
            int cy = bus.read16(src + 10) & 0xFFFF;
            int sclX = (short) bus.read16(src + 12);
            int sclY = (short) bus.read16(src + 14);
            int angle = (bus.read16(src + 16) >> 8) & 0xFF;
            double rad = angle / 128.0 * Math.PI;
            double cos = Math.cos(rad), sin = Math.sin(rad);
            int pa = (int)(cos * sclX);
            int pb = (int)(-sin * sclX);
            int pc = (int)(sin * sclY);
            int pd = (int)(cos * sclY);
            bus.write16(dst, (short)pa);
            bus.write16(dst + 2, (short)pb);
            bus.write16(dst + 4, (short)pc);
            bus.write16(dst + 6, (short)pd);
            int startX = sx - (int)((cos * sclX) * (short)cx - (sin * sclX) * (short)cy);
            int startY = sy - (int)((sin * sclY) * (short)cx + (cos * sclY) * (short)cy);
            bus.write32(dst + 8, startX);
            bus.write32(dst + 12, startY);
            src += 20; dst += 16;
        }
    }

    private void objAffineSet(int src, int dst, int count, int stride) {
        for (int i = 0; i < count; i++) {
            int sclX = (short) bus.read16(src);
            int sclY = (short) bus.read16(src + 2);
            int angle = (bus.read16(src + 4) >> 8) & 0xFF;
            double rad = angle / 128.0 * Math.PI;
            double cos = Math.cos(rad), sin = Math.sin(rad);
            int pa = (int)(cos * sclX);
            int pb = (int)(-sin * sclX);
            int pc = (int)(sin * sclY);
            int pd = (int)(cos * sclY);
            bus.write16(dst, (short)pa);
            bus.write16(dst + stride, (short)pb);
            bus.write16(dst + stride * 2, (short)pc);
            bus.write16(dst + stride * 3, (short)pd);
            src += 6; dst += stride * 4;
        }
    }

    private void bitUnPack(int src, int dst, int infoPtr) {
        int len     = bus.read16(infoPtr) & 0xFFFF;
        int srcBits = bus.read8(infoPtr + 2) & 0xFF;
        int dstBits = bus.read8(infoPtr + 3) & 0xFF;
        int dataOff = bus.read32(infoPtr + 4);
        int offset  = dataOff & 0x7FFFFFFF;
        boolean zeroFlag = (dataOff & 0x80000000) != 0;
        int outBuf = 0, outBits = 0, outAddr = dst;
        for (int i = 0; i < len; i++) {
            int b = bus.read8(src + i) & 0xFF;
            for (int bit = 0; bit < 8; bit += srcBits) {
                int unit = (b >> bit) & ((1 << srcBits) - 1);
                if (unit != 0 || zeroFlag) unit += offset;
                outBuf |= unit << outBits;
                outBits += dstBits;
                if (outBits >= 32) {
                    bus.write32(outAddr, outBuf);
                    outAddr += 4; outBuf = 0; outBits = 0;
                }
            }
        }
        if (outBits > 0) bus.write32(outAddr, outBuf);
    }

    // LZ77 (GBA BIOS variant). Header: byte0=0x10, bytes1-3 = decompressed size.
    private void lz77UnComp(int src, int dst, boolean vram) {
        int header = bus.read32(src);
        int size = (header >>> 8) & 0xFFFFFF;
        src += 4;
        int out = 0;
        byte[] buf = new byte[size];
        while (out < size) {
            int flags = bus.read8(src++) & 0xFF;
            for (int i = 0; i < 8 && out < size; i++) {
                if ((flags & (0x80 >> i)) != 0) {
                    int b1 = bus.read8(src++) & 0xFF;
                    int b2 = bus.read8(src++) & 0xFF;
                    int len = (b1 >> 4) + 3;
                    int disp = ((b1 & 0xF) << 8 | b2) + 1;
                    for (int j = 0; j < len && out < size; j++) {
                        buf[out] = buf[out - disp];
                        out++;
                    }
                } else {
                    buf[out++] = (byte)(bus.read8(src++) & 0xFF);
                }
            }
        }
        writeBuf(dst, buf, vram);
    }

    private void rlUnComp(int src, int dst, boolean vram) {
        int header = bus.read32(src);
        int size = (header >>> 8) & 0xFFFFFF;
        src += 4;
        byte[] buf = new byte[size];
        int out = 0;
        while (out < size) {
            int flag = bus.read8(src++) & 0xFF;
            int len = flag & 0x7F;
            if ((flag & 0x80) != 0) { // compressed run
                len += 3;
                int b = bus.read8(src++) & 0xFF;
                for (int i = 0; i < len && out < size; i++) buf[out++] = (byte)b;
            } else { // uncompressed
                len += 1;
                for (int i = 0; i < len && out < size; i++) buf[out++] = (byte)(bus.read8(src++) & 0xFF);
            }
        }
        writeBuf(dst, buf, vram);
    }

    private void huffUnComp(int src, int dst) {
        int header = bus.read32(src);
        int dataBits = header & 0xF;
        int size = (header >>> 8) & 0xFFFFFF;
        int treeStart = src + 4;
        int treeSize = ((bus.read8(treeStart) & 0xFF) + 1) * 2;
        int bitstream = treeStart + treeSize;
        byte[] buf = new byte[size];
        int out = 0, outBits = 0, outByte = 0;
        int node = treeStart + 1;
        int rootByte = bus.read8(treeStart + 1) & 0xFF; // not used directly
        int treeRoot = treeStart + 1;
        node = treeRoot;
        int bsPos = bitstream;
        int word = bus.read32(bsPos); bsPos += 4;
        int bitsLeft = 32;
        int curNode = treeRoot;
        while (out < size) {
            int bit = (word >> 31) & 1;
            word <<= 1; bitsLeft--;
            int nodeVal = bus.read8(curNode) & 0xFF;
            int offset = (nodeVal & 0x3F);
            int next = (curNode & ~1) + offset * 2 + 2 + bit;
            boolean leaf = (bit == 0) ? (nodeVal & 0x80) != 0 : (nodeVal & 0x40) != 0;
            curNode = next;
            if (leaf) {
                int data = bus.read8(curNode) & 0xFF;
                outByte |= (data & ((1 << dataBits) - 1)) << outBits;
                outBits += dataBits;
                if (outBits >= 8) {
                    if (out < size) buf[out++] = (byte)outByte;
                    outByte = 0; outBits = 0;
                }
                curNode = treeRoot;
            }
            if (bitsLeft == 0) { word = bus.read32(bsPos); bsPos += 4; bitsLeft = 32; }
        }
        writeBuf(dst, buf, false);
    }

    private void diffUnFilter(int src, int dst, int unitBits, boolean vram) {
        int header = bus.read32(src);
        int size = (header >>> 8) & 0xFFFFFF;
        src += 4;
        byte[] buf = new byte[size];
        if (unitBits == 8) {
            int prev = 0, out = 0;
            while (out < size) {
                prev = (prev + (bus.read8(src++) & 0xFF)) & 0xFF;
                buf[out++] = (byte)prev;
            }
        } else { // 16-bit
            int prev = 0, out = 0;
            while (out + 1 < size) {
                prev = (prev + (bus.read16(src) & 0xFFFF)) & 0xFFFF;
                src += 2;
                buf[out++] = (byte)prev;
                buf[out++] = (byte)(prev >> 8);
            }
        }
        writeBuf(dst, buf, vram);
    }

    private void writeBuf(int dst, byte[] buf, boolean vram) {
        if (vram) {
            for (int i = 0; i + 1 < buf.length; i += 2) {
                int v = (buf[i] & 0xFF) | ((buf[i + 1] & 0xFF) << 8);
                bus.write16(dst + i, (short)v);
            }
            if ((buf.length & 1) != 0) {
                int last = buf.length - 1;
                bus.write16(dst + last - 1, (short)((buf[last] & 0xFF) << 8 | (bus.read8(dst + last - 1) & 0xFF)));
            }
        } else {
            for (int i = 0; i < buf.length; i++) bus.write8(dst + i, buf[i]);
        }
    }

    // ── Interrupts ─────────────────────────────────────────────────────────
    public void triggerIRQ() {
        if ((cpsr & FLAG_I) != 0) return;
        if (DEBUG_SWI && swiLogCount < 90) {
            System.out.printf("[IRQ] handlerPtr=%08X IE=%04X IF=%04X PC=%08X%n",
                bus.read32(0x03007FFC), bus.read16(0x04000200) & 0xFFFF,
                bus.read16(0x04000202) & 0xFFFF, regs[15]);
            swiLogCount++;
        }
        int oldMode = cpsr & 0x1F;
        // regs[15] holds the address of the next (interrupted) instruction.
        // BIOS returns via SUBS PC, LR, #4, so LR = resume + 4.
        int lr = regs[15] + 4;
        bankedSPSR[spsrIndex(MODE_IRQ)] = cpsr;
        cpsr = (cpsr & ~0x3F) | MODE_IRQ | FLAG_I;
        cpsr &= ~FLAG_T;
        switchMode(oldMode, MODE_IRQ);
        regs[14] = lr;
        regs[15] = 0x18; // IRQ vector
        pipelineFilled = false;
        halted = false;
    }

    // ── Mode switching ─────────────────────────────────────────────────────
    // r8-r12 are banked ONLY for FIQ mode; all other modes share them.
    private void switchMode(int oldMode, int newMode) {
        if (oldMode == newMode) return;

        // Save outgoing mode's SP/LR/SPSR.
        int oi = modeIndex(oldMode);
        bankedR13[oi] = regs[13];
        bankedR14[oi] = regs[14];
        int osi = spsrIndex(oldMode);
        if (osi >= 0) bankedSPSR[osi] = spsr;

        // Swap r8-r12 only when crossing the FIQ boundary.
        boolean oldFiq = (oldMode == MODE_FIQ);
        boolean newFiq = (newMode == MODE_FIQ);
        if (oldFiq != newFiq) {
            if (oldFiq) {
                // Leaving FIQ: stash FIQ r8-r12, restore user r8-r12.
                bankedR8Fiq[1] = regs[8];  bankedR9Fiq[1] = regs[9];
                bankedR10Fiq[1] = regs[10]; bankedR11Fiq[1] = regs[11];
                bankedR12Fiq[1] = regs[12];
                regs[8] = bankedR8Fiq[0];  regs[9] = bankedR9Fiq[0];
                regs[10] = bankedR10Fiq[0]; regs[11] = bankedR11Fiq[0];
                regs[12] = bankedR12Fiq[0];
            } else {
                // Entering FIQ: stash user r8-r12, load FIQ r8-r12.
                bankedR8Fiq[0] = regs[8];  bankedR9Fiq[0] = regs[9];
                bankedR10Fiq[0] = regs[10]; bankedR11Fiq[0] = regs[11];
                bankedR12Fiq[0] = regs[12];
                regs[8] = bankedR8Fiq[1];  regs[9] = bankedR9Fiq[1];
                regs[10] = bankedR10Fiq[1]; regs[11] = bankedR11Fiq[1];
                regs[12] = bankedR12Fiq[1];
            }
        }

        // Load incoming mode's SP/LR/SPSR.
        int ni = modeIndex(newMode);
        regs[13] = bankedR13[ni];
        regs[14] = bankedR14[ni];
        int nsi = spsrIndex(newMode);
        if (nsi >= 0) spsr = bankedSPSR[nsi];
    }

    private int modeIndex(int mode) {
        switch (mode) {
            case MODE_USER: case MODE_SYS: return 0;
            case MODE_FIQ: return 1;
            case MODE_IRQ: return 2;
            case MODE_SVC: return 3;
            case MODE_ABT: return 4;
            case MODE_UND: return 5;
            default:       return 0;
        }
    }

    private int spsrIndex(int mode) {
        switch (mode) {
            case MODE_FIQ: return 0;
            case MODE_IRQ: return 1;
            case MODE_SVC: return 2;
            case MODE_ABT: return 3;
            case MODE_UND: return 4;
            default:       return -1;
        }
    }

    public boolean isThumb() { return (cpsr & FLAG_T) != 0; }

    public int getPC() { return regs[15]; }
    public void setPC(int pc) { regs[15] = pc; pipelineFilled = false; }

    // ── Inner record ──────────────────────────────────────────────────────
    private static class ShifterResult {
        final int value;
        final boolean carry;
        ShifterResult(int v, boolean c) { value = v; carry = c; }
    }
}
