package com.gbaminecraft.emulator.memory;

/**
 * GBA Flash memory emulation (1 Mbit / 128 KB, two 64 KB banks).
 * Implements the bootleg-AGB command protocol used by Pokémon games:
 *   unlock:  write 0xAA -> 0x5555, 0x55 -> 0x2AAA, CMD -> 0x5555
 *   CMDs:    0x90 enter chip-ID, 0xF0 exit ID, 0xA0 program byte,
 *            0x80 erase prefix (then 0x10 chip / 0x30 sector erase),
 *            0xB0 bank switch (next write to 0x0000 selects the bank)
 * In ID mode, reads of offset 0/1 return the manufacturer/device ID.
 */
public class Flash {
    public static final int SIZE = 0x20000; // 128 KB
    private final byte[] data = new byte[SIZE];

    // Sanyo LE26FV10N1TS (FLASH1M_V102/V103): manufacturer 0x62, device 0x13.
    private static final int MANUFACTURER_ID = 0x62;
    private static final int DEVICE_ID       = 0x13;

    private int state = 0;        // unlock state machine step
    private boolean idMode = false;
    private boolean eraseArmed = false;
    private boolean programArmed = false;
    private boolean bankArmed = false;
    private int bank = 0;         // 0 or 1 (64 KB each)

    public Flash() {
        java.util.Arrays.fill(data, (byte) 0xFF); // erased state
    }

    public int read8(int offset) {
        offset &= 0xFFFF;
        if (idMode) {
            if (offset == 0x0000) return MANUFACTURER_ID;
            if (offset == 0x0001) return DEVICE_ID;
        }
        return data[bank * 0x10000 + offset] & 0xFF;
    }

    public void write8(int offset, int val) {
        offset &= 0xFFFF;
        val &= 0xFF;

        // A program operation consumes exactly the next write.
        if (programArmed) {
            data[bank * 0x10000 + offset] = (byte) val;
            programArmed = false;
            state = 0;
            return;
        }
        // A bank switch consumes the next write to offset 0x0000.
        if (bankArmed) {
            if (offset == 0x0000) bank = val & 1;
            bankArmed = false;
            state = 0;
            return;
        }

        // Command unlock sequence.
        if (offset == 0x5555 && val == 0xAA && state == 0) { state = 1; return; }
        if (offset == 0x2AAA && val == 0x55 && state == 1) { state = 2; return; }
        if (offset == 0x5555 && state == 2) {
            switch (val) {
                case 0x90: idMode = true;  break;   // enter ID
                case 0xF0: idMode = false; break;   // exit ID
                case 0x80: eraseArmed = true; break; // erase prefix
                case 0xA0: programArmed = true; break; // program next write
                case 0xB0: bankArmed = true; break;    // bank switch next write
                case 0x10: // chip erase (needs erase prefix)
                    if (eraseArmed) { java.util.Arrays.fill(data, (byte) 0xFF); eraseArmed = false; }
                    break;
                default: break;
            }
            if (val != 0x80) state = 0;
            else state = 0;
            return;
        }
        // Sector erase: 0x30 written to a sector base after the 0x80 prefix unlock.
        if (val == 0x30 && eraseArmed) {
            int base = bank * 0x10000 + (offset & 0xF000);
            for (int i = 0; i < 0x1000 && base + i < SIZE; i++) data[base + i] = (byte) 0xFF;
            eraseArmed = false;
            state = 0;
            return;
        }
        // Unrecognized — reset the state machine.
        state = 0;
    }

    public byte[] getData() { return data; }
    public void reset() {
        state = 0; idMode = false; eraseArmed = false;
        programArmed = false; bankArmed = false; bank = 0;
    }
}
