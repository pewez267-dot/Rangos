package com.fspawner.network;

import com.fspawner.client.ClientPacketHandler;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class OpenScreenPacket {

    private final CompoundTag configNbt;
    private final EditContext context;

    public OpenScreenPacket(CompoundTag configNbt, EditContext context) {
        this.configNbt = configNbt;
        this.context = context;
    }

    public OpenScreenPacket(CompoundTag configNbt) {
        this(configNbt, EditContext.newSession());
    }

    public static void encode(OpenScreenPacket msg, FriendlyByteBuf buf) {
        buf.writeNbt(msg.configNbt);
        msg.context.encode(buf);
    }

    public static OpenScreenPacket decode(FriendlyByteBuf buf) {
        CompoundTag tag = buf.readNbt();
        EditContext ctx = EditContext.decode(buf);
        return new OpenScreenPacket(tag, ctx);
    }

    public static void handle(OpenScreenPacket msg, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() ->
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                ClientPacketHandler.openScreen(msg.configNbt, msg.context))
        );
        context.setPacketHandled(true);
    }
}
