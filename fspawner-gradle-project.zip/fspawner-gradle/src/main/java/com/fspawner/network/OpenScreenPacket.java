// 
// Decompiled by Procyon v0.6.0
// 

package com.fspawner.network;

import net.minecraftforge.fml.DistExecutor;
import com.fspawner.client.ClientPacketHandler;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.nbt.CompoundTag;

public class OpenScreenPacket
{
    private final CompoundTag configNbt;
    
    public OpenScreenPacket(final CompoundTag configNbt) {
        this.configNbt = configNbt;
    }
    
    public static void encode(final OpenScreenPacket msg, final FriendlyByteBuf buf) {
        buf.m_130079_(msg.configNbt);
    }
    
    public static OpenScreenPacket decode(final FriendlyByteBuf buf) {
        return new OpenScreenPacket(buf.m_130260_());
    }
    
    public static void handle(final OpenScreenPacket msg, final Supplier<NetworkEvent.Context> ctx) {
        final NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientPacketHandler.openScreen(msg.configNbt)));
        context.setPacketHandled(true);
    }
}
