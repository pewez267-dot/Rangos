package com.fspawner.network;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;

/**
 * Origen de una sesión de edición. El servidor lo usa al guardar
 * para devolver el item al slot correcto o actualizar el bloque colocado.
 */
public final class EditContext {

    public enum Source { NEW, MAIN_HAND, OFF_HAND, BLOCK }

    public final Source source;
    public final int slot;          // sólo para item: índice de inventario, -1 si no aplica
    public final BlockPos pos;      // sólo para BLOCK

    private EditContext(Source source, int slot, BlockPos pos) {
        this.source = source;
        this.slot = slot;
        this.pos = pos;
    }

    public static EditContext newSession() { return new EditContext(Source.NEW, -1, null); }
    public static EditContext mainHand(int slot) { return new EditContext(Source.MAIN_HAND, slot, null); }
    public static EditContext offHand() { return new EditContext(Source.OFF_HAND, -1, null); }
    public static EditContext block(BlockPos pos) { return new EditContext(Source.BLOCK, -1, pos); }

    public void encode(FriendlyByteBuf buf) {
        buf.writeEnum(this.source);
        buf.writeInt(this.slot);
        buf.writeBoolean(this.pos != null);
        if (this.pos != null) buf.writeBlockPos(this.pos);
    }

    public static EditContext decode(FriendlyByteBuf buf) {
        Source src = buf.readEnum(Source.class);
        int slot = buf.readInt();
        BlockPos pos = buf.readBoolean() ? buf.readBlockPos() : null;
        return new EditContext(src, slot, pos);
    }
}
