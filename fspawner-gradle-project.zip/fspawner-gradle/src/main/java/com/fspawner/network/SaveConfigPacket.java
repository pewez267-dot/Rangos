// 
// Decompiled by Procyon v0.6.0
// 

package com.fspawner.network;

import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerPlayer;
import com.fspawner.item.SpawnerItemBuilder;
import com.fspawner.config.SpawnerConfig;
import net.minecraft.network.chat.Component;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.nbt.CompoundTag;

public class SaveConfigPacket
{
    private final CompoundTag configNbt;
    
    public SaveConfigPacket(final CompoundTag configNbt) {
        this.configNbt = configNbt;
    }
    
    public static void encode(final SaveConfigPacket msg, final FriendlyByteBuf buf) {
        buf.m_130079_(msg.configNbt);
    }
    
    public static SaveConfigPacket decode(final FriendlyByteBuf buf) {
        return new SaveConfigPacket(buf.m_130260_());
    }
    
    public static void handle(final SaveConfigPacket msg, final Supplier<NetworkEvent.Context> ctx) {
        final NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() -> {
            final ServerPlayer player = context.getSender();
            if (player == null) {
                return;
            }
            else if (!player.m_20310_(4)) {
                player.m_213846_((Component)Component.m_237115_("fspawner.command.no_permission"));
                return;
            }
            else if (msg.configNbt == null) {
                return;
            }
            else {
                final SpawnerConfig cfg = SpawnerConfig.load(msg.configNbt);
                final ItemStack stack = SpawnerItemBuilder.build(cfg);
                if (!player.m_150109_().m_36054_(stack)) {
                    player.m_36176_(stack, false);
                }
                player.m_213846_((Component)Component.m_237115_("fspawner.command.given"));
                return;
            }
        });
        context.setPacketHandled(true);
    }
}
