package com.fspawner.network;

import com.fspawner.config.SpawnerConfig;
import com.fspawner.item.SpawnerItemBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SaveConfigPacket {

    private final CompoundTag configNbt;
    private final EditContext context;

    public SaveConfigPacket(CompoundTag configNbt, EditContext context) {
        this.configNbt = configNbt;
        this.context = context;
    }

    public SaveConfigPacket(CompoundTag configNbt) {
        this(configNbt, EditContext.newSession());
    }

    public static void encode(SaveConfigPacket msg, FriendlyByteBuf buf) {
        buf.writeNbt(msg.configNbt);
        msg.context.encode(buf);
    }

    public static SaveConfigPacket decode(FriendlyByteBuf buf) {
        CompoundTag tag = buf.readNbt();
        EditContext ctx = EditContext.decode(buf);
        return new SaveConfigPacket(tag, ctx);
    }

    public static void handle(SaveConfigPacket msg, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player == null || msg.configNbt == null) return;
            if (!player.hasPermissions(2)) {
                player.sendSystemMessage(Component.translatable("fspawner.command.no_permission"));
                return;
            }
            SpawnerConfig cfg = SpawnerConfig.load(msg.configNbt);
            applyTo(player, cfg, msg.context);
        });
        context.setPacketHandled(true);
    }

    private static void applyTo(ServerPlayer player, SpawnerConfig cfg, EditContext src) {
        switch (src.source) {
            case BLOCK -> applyToBlock(player, cfg, src.pos);
            case MAIN_HAND -> replaceHand(player, cfg, InteractionHand.MAIN_HAND, src.slot);
            case OFF_HAND -> replaceHand(player, cfg, InteractionHand.OFF_HAND, -1);
            default -> giveNew(player, cfg);
        }
    }

    private static void giveNew(ServerPlayer player, SpawnerConfig cfg) {
        ItemStack stack = SpawnerItemBuilder.build(cfg);
        if (!player.getInventory().add(stack)) player.drop(stack, false);
        player.sendSystemMessage(Component.translatable("fspawner.command.given"));
    }

    private static void replaceHand(ServerPlayer player, SpawnerConfig cfg, InteractionHand hand, int hintSlot) {
        Inventory inv = player.getInventory();
        ItemStack stack = SpawnerItemBuilder.build(cfg);
        if (hand == InteractionHand.MAIN_HAND && hintSlot >= 0 && hintSlot < inv.items.size()
                && SpawnerItemBuilder.isFantasticSpawner(inv.getItem(hintSlot))) {
            inv.setItem(hintSlot, stack);
        } else {
            player.setItemInHand(hand, stack);
        }
        player.sendSystemMessage(Component.translatable("fspawner.command.updated"));
    }

    private static void applyToBlock(ServerPlayer player, SpawnerConfig cfg, BlockPos pos) {
        if (pos == null) { giveNew(player, cfg); return; }
        ServerLevel level = player.serverLevel();
        BlockEntity be = level.getBlockEntity(pos);
        if (!(be instanceof SpawnerBlockEntity)) {
            player.sendSystemMessage(Component.literal("§cEl bloque ya no existe."));
            return;
        }
        CompoundTag beTag = SpawnerItemBuilder.buildBlockEntityTag(cfg);
        beTag.putString("id", "minecraft:mob_spawner");
        beTag.putInt("x", pos.getX());
        beTag.putInt("y", pos.getY());
        beTag.putInt("z", pos.getZ());
        be.load(beTag);
        be.setChanged();
        BlockState state = level.getBlockState(pos);
        level.sendBlockUpdated(pos, state, state, Block.UPDATE_CLIENTS | Block.UPDATE_IMMEDIATE);
        player.sendSystemMessage(Component.translatable("fspawner.command.block_updated"));
    }
}
