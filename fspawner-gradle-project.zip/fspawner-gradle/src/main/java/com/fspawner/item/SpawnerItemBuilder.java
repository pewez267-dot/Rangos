package com.fspawner.item;

import com.fspawner.config.EntityEntry;
import com.fspawner.config.SpawnerConfig;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;

import java.util.Map;

public final class SpawnerItemBuilder {

    private SpawnerItemBuilder() {}

    public static ItemStack build(SpawnerConfig cfg) {
        ItemStack stack = new ItemStack(Items.SPAWNER); // spawner
        stack.getOrCreateTag().put("fspawner", cfg.save());
        stack.getOrCreateTag().put("BlockEntityTag", buildBlockEntityTag(cfg));

        String name = (cfg.itemName == null || cfg.itemName.isEmpty())
                ? "§d\u2726 Fantastic Spawner \u2726" : cfg.itemName;
        stack.setHoverName(Component.literal(name));

        EnchantmentHelper.setEnchantments(Map.of(Enchantments.UNBREAKING, 1), stack);
        stack.getOrCreateTag().putInt("HideFlags", 1);
        return stack;
    }

    public static CompoundTag buildBlockEntityTag(SpawnerConfig cfg) {
        CompoundTag tag = new CompoundTag();
        int maxNearby = cfg.bossMode ? 1 : Math.max(1, cfg.maxNearbyEntities);
        int spawnCount = cfg.bossMode ? 1 : Math.max(1, cfg.spawnCount);
        int minDelay = Math.max(0, Math.min(cfg.spawnDelayMin, cfg.spawnDelayMax)) + Math.max(0, cfg.extraCooldown);
        int maxDelay = Math.max(cfg.spawnDelayMin, cfg.spawnDelayMax) + Math.max(0, cfg.extraCooldown);

        tag.putShort("Delay", (short) minDelay);
        tag.putShort("MinSpawnDelay", (short) minDelay);
        tag.putShort("MaxSpawnDelay", (short) Math.max(1, maxDelay));
        tag.putShort("SpawnCount", (short) spawnCount);
        tag.putShort("MaxNearbyEntities", (short) maxNearby);
        tag.putShort("RequiredPlayerRange", (short) (cfg.requiresPlayer ? Math.max(0, cfg.activationRange) : 0));
        tag.putShort("SpawnRange", (short) Math.max(1, cfg.spawnRange));

        ListTag potentials = new ListTag();
        if (cfg.entityMode == SpawnerConfig.EntityMode.POOL && cfg.entities.size() > 1) {
            for (EntityEntry e : cfg.entities) {
                potentials.add(potentialEntry(cfg, e.id, e.weight, true));
            }
        } else {
            potentials.add(potentialEntry(cfg, cfg.primaryEntityId(), 1, true));
        }
        tag.put("SpawnPotentials", potentials);

        CompoundTag spawnData = new CompoundTag();
        spawnData.put("entity", EntityNbtBuilder.build(cfg, cfg.primaryEntityId(), true));
        spawnData.put("custom_spawn_rules", customSpawnRules());
        tag.put("SpawnData", spawnData);

        // Marker en ForgeData del BE para reconstrucción tras placement.
        CompoundTag forgeData = tag.contains("ForgeData") ? tag.getCompound("ForgeData") : new CompoundTag();
        CompoundTag marker = new CompoundTag();
        marker.put("cfg", cfg.save());
        forgeData.put("fspawner", marker);
        tag.put("ForgeData", forgeData);
        return tag;
    }

    private static CompoundTag customSpawnRules() {
        return new CompoundTag();
    }

    private static CompoundTag potentialEntry(SpawnerConfig cfg, String entityId, int weight, boolean includeFullConfig) {
        CompoundTag entry = new CompoundTag();
        entry.putInt("weight", Math.max(1, weight));
        CompoundTag data = new CompoundTag();
        data.put("entity", EntityNbtBuilder.build(cfg, entityId, includeFullConfig));
        data.put("custom_spawn_rules", customSpawnRules());
        entry.put("data", data);
        return entry;
    }

    public static boolean isFantasticSpawner(ItemStack stack) {
        return stack != null
            && stack.is(Items.SPAWNER)
            && stack.hasTag()
            && stack.getTag().contains("fspawner");
    }

    public static SpawnerConfig readConfig(ItemStack stack) {
        if (!isFantasticSpawner(stack)) return null;
        return SpawnerConfig.load(stack.getTag().getCompound("fspawner"));
    }

    public static ItemStack fromBlockEntityNbt(CompoundTag beTag) {
        CompoundTag cfgTag = extractConfigForEditing(beTag);
        if (cfgTag == null) return null;
        return build(SpawnerConfig.load(cfgTag));
    }

    public static boolean isFantasticSpawnerBlock(CompoundTag beTag) {
        return extractConfigForEditing(beTag) != null;
    }

    /**
     * Devuelve el CompoundTag de configuración guardado en el bloque,
     * o un cfg "vacío" reconstruido a partir de SpawnData/SpawnPotentials
     * si es un spawner vanilla (permite editar incluso spawners no-FSpawner).
     */
    public static CompoundTag extractConfigForEditing(CompoundTag beTag) {
        if (beTag == null) return null;
        if (beTag.contains("ForgeData")) {
            CompoundTag marker = beTag.getCompound("ForgeData").getCompound("fspawner");
            if (marker.contains("cfg")) {
                CompoundTag cfg = marker.getCompound("cfg");
                if (!cfg.isEmpty()) return cfg;
            }
        }
        CompoundTag entity = null;
        if (beTag.contains("SpawnData")) {
            entity = beTag.getCompound("SpawnData").getCompound("entity");
        }
        if ((entity == null || entity.isEmpty()) && beTag.contains("SpawnPotentials")) {
            ListTag list = beTag.getList("SpawnPotentials", 10);
            if (!list.isEmpty()) {
                entity = list.getCompound(0).getCompound("data").getCompound("entity");
            }
        }
        if (entity != null && !entity.isEmpty()) {
            CompoundTag forgeData = entity.getCompound("ForgeData");
            CompoundTag marker = forgeData.getCompound("fspawner");
            if (marker.contains("cfg")) return marker.getCompound("cfg");
        }
        // Reconstrucción mínima desde un spawner vanilla
        SpawnerConfig fallback = new SpawnerConfig();
        fallback.entities.clear();
        if (entity != null && entity.contains("id")) {
            fallback.entities.add(new EntityEntry(entity.getString("id")));
        } else {
            fallback.entities.add(new EntityEntry("minecraft:zombie"));
        }
        if (beTag.contains("MinSpawnDelay")) fallback.spawnDelayMin = beTag.getShort("MinSpawnDelay");
        if (beTag.contains("MaxSpawnDelay")) fallback.spawnDelayMax = beTag.getShort("MaxSpawnDelay");
        if (beTag.contains("SpawnCount")) fallback.spawnCount = beTag.getShort("SpawnCount");
        if (beTag.contains("SpawnRange")) fallback.spawnRange = beTag.getShort("SpawnRange");
        if (beTag.contains("MaxNearbyEntities")) fallback.maxNearbyEntities = beTag.getShort("MaxNearbyEntities");
        if (beTag.contains("RequiredPlayerRange")) fallback.activationRange = beTag.getShort("RequiredPlayerRange");
        return fallback.save();
    }
}
