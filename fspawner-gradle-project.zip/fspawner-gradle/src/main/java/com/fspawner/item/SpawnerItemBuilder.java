// 
// Decompiled by Procyon v0.6.0
// 

package com.fspawner.item;

import java.util.Iterator;
import com.fspawner.config.EntityEntry;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import java.util.Map;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.Tag;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import com.fspawner.config.SpawnerConfig;

public final class SpawnerItemBuilder
{
    private SpawnerItemBuilder() {
    }
    
    public static ItemStack build(final SpawnerConfig cfg) {
        final ItemStack stack = new ItemStack((ItemLike)Items.f_42007_);
        stack.m_41784_().m_128365_("fspawner", (Tag)cfg.save());
        stack.m_41784_().m_128365_("BlockEntityTag", (Tag)buildBlockEntityTag(cfg));
        final String name = (cfg.itemName == null || cfg.itemName.isEmpty()) ? "§d\u2726 Fantastic Spawner \u2726" : cfg.itemName;
        stack.m_41714_((Component)Component.m_237113_(name));
        EnchantmentHelper.m_44865_((Map)Map.of(Enchantments.f_44986_, 1), stack);
        stack.m_41784_().m_128405_("HideFlags", 1);
        return stack;
    }
    
    public static CompoundTag buildBlockEntityTag(final SpawnerConfig cfg) {
        final CompoundTag tag = new CompoundTag();
        final int maxNearby = cfg.bossMode ? 1 : Math.max(1, cfg.maxNearbyEntities);
        final int spawnCount = cfg.bossMode ? 1 : Math.max(1, cfg.spawnCount);
        final int minDelay = Math.max(0, Math.min(cfg.spawnDelayMin, cfg.spawnDelayMax));
        final int maxDelay = Math.max(cfg.spawnDelayMin, cfg.spawnDelayMax);
        tag.m_128376_("Delay", (short)minDelay);
        tag.m_128376_("MinSpawnDelay", (short)minDelay);
        tag.m_128376_("MaxSpawnDelay", (short)Math.max(1, maxDelay));
        tag.m_128376_("SpawnCount", (short)spawnCount);
        tag.m_128376_("MaxNearbyEntities", (short)maxNearby);
        tag.m_128376_("RequiredPlayerRange", (short)Math.max(0, cfg.activationRange));
        tag.m_128376_("SpawnRange", (short)Math.max(1, cfg.spawnRange));
        final ListTag potentials = new ListTag();
        if (cfg.entityMode == SpawnerConfig.EntityMode.POOL && cfg.entities.size() > 1) {
            for (final EntityEntry e : cfg.entities) {
                potentials.add((Object)potentialEntry(cfg, e.id, e.weight, true));
            }
        }
        else {
            potentials.add((Object)potentialEntry(cfg, cfg.primaryEntityId(), 1, true));
        }
        tag.m_128365_("SpawnPotentials", (Tag)potentials);
        final CompoundTag spawnData = new CompoundTag();
        spawnData.m_128365_("entity", (Tag)EntityNbtBuilder.build(cfg, cfg.primaryEntityId(), true));
        spawnData.m_128365_("custom_spawn_rules", (Tag)customSpawnRules());
        tag.m_128365_("SpawnData", (Tag)spawnData);
        final CompoundTag forgeData = tag.m_128441_("ForgeData") ? tag.m_128469_("ForgeData") : new CompoundTag();
        final CompoundTag marker = new CompoundTag();
        marker.m_128365_("cfg", (Tag)cfg.save());
        forgeData.m_128365_("fspawner", (Tag)marker);
        tag.m_128365_("ForgeData", (Tag)forgeData);
        return tag;
    }
    
    private static CompoundTag customSpawnRules() {
        return new CompoundTag();
    }
    
    private static CompoundTag potentialEntry(final SpawnerConfig cfg, final String entityId, final int weight, final boolean includeFullConfig) {
        final CompoundTag entry = new CompoundTag();
        entry.m_128405_("weight", Math.max(1, weight));
        final CompoundTag data = new CompoundTag();
        data.m_128365_("entity", (Tag)EntityNbtBuilder.build(cfg, entityId, includeFullConfig));
        data.m_128365_("custom_spawn_rules", (Tag)customSpawnRules());
        entry.m_128365_("data", (Tag)data);
        return entry;
    }
    
    public static boolean isFantasticSpawner(final ItemStack stack) {
        return stack != null && stack.m_150930_(Items.f_42007_) && stack.m_41782_() && stack.m_41783_().m_128441_("fspawner");
    }
    
    public static SpawnerConfig readConfig(final ItemStack stack) {
        if (!isFantasticSpawner(stack)) {
            return null;
        }
        return SpawnerConfig.load(stack.m_41783_().m_128469_("fspawner"));
    }
    
    public static ItemStack fromBlockEntityNbt(final CompoundTag beTag) {
        final CompoundTag cfgTag = extractEmbeddedConfig(beTag);
        if (cfgTag == null) {
            return null;
        }
        return build(SpawnerConfig.load(cfgTag));
    }
    
    public static boolean isFantasticSpawnerBlock(final CompoundTag beTag) {
        return extractEmbeddedConfig(beTag) != null;
    }
    
    private static CompoundTag extractEmbeddedConfig(final CompoundTag beTag) {
        if (beTag == null) {
            return null;
        }
        if (beTag.m_128441_("ForgeData")) {
            final CompoundTag marker = beTag.m_128469_("ForgeData").m_128469_("fspawner");
            if (marker.m_128441_("cfg")) {
                final CompoundTag cfg = marker.m_128469_("cfg");
                if (!cfg.m_128456_()) {
                    return cfg;
                }
            }
        }
        CompoundTag entity = null;
        if (beTag.m_128441_("SpawnData")) {
            entity = beTag.m_128469_("SpawnData").m_128469_("entity");
        }
        if ((entity == null || entity.m_128456_()) && beTag.m_128441_("SpawnPotentials")) {
            final ListTag list = beTag.m_128437_("SpawnPotentials", 10);
            if (!list.isEmpty()) {
                entity = list.m_128728_(0).m_128469_("data").m_128469_("entity");
            }
        }
        if (entity == null || entity.m_128456_()) {
            return null;
        }
        final CompoundTag forgeData = entity.m_128469_("ForgeData");
        final CompoundTag marker2 = forgeData.m_128469_("fspawner");
        if (marker2.m_128441_("cfg")) {
            return marker2.m_128469_("cfg");
        }
        return null;
    }
}
