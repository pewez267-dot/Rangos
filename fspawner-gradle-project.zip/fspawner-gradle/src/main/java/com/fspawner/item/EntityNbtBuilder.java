// 
// Decompiled by Procyon v0.6.0
// 

package com.fspawner.item;

import net.minecraft.ChatFormatting;
import java.util.Locale;
import net.minecraft.resources.ResourceLocation;
import com.fspawner.config.DropEntry;
import net.minecraft.network.chat.TextColor;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraft.world.effect.MobEffect;
import com.fspawner.config.EffectEntry;
import com.fspawner.config.EquipmentEntry;
import net.minecraft.world.item.ItemStack;
import net.minecraft.nbt.FloatTag;
import net.minecraft.world.entity.EquipmentSlot;
import java.util.Iterator;
import net.minecraft.nbt.Tag;
import java.util.Map;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.CompoundTag;
import com.fspawner.config.SpawnerConfig;

public final class EntityNbtBuilder
{
    public static final int PERMANENT_DURATION = Integer.MAX_VALUE;
    
    private EntityNbtBuilder() {
    }
    
    public static CompoundTag build(final SpawnerConfig cfg, final String entityId, final boolean includeFullConfig) {
        final CompoundTag tag = new CompoundTag();
        tag.m_128359_("id", (entityId == null) ? "minecraft:pig" : entityId);
        applyAttributes(cfg, tag);
        applyEquipment(cfg, tag);
        applyEffects(cfg, tag);
        applyAppearance(cfg, tag);
        applyMarker(cfg, tag, includeFullConfig);
        return tag;
    }
    
    private static void applyAttributes(final SpawnerConfig cfg, final CompoundTag tag) {
        if (cfg.attributes.isEmpty()) {
            return;
        }
        final ListTag list = new ListTag();
        for (final Map.Entry<String, Double> e : cfg.attributes.entrySet()) {
            final CompoundTag a = new CompoundTag();
            a.m_128359_("Name", (String)e.getKey());
            a.m_128347_("Base", (double)e.getValue());
            list.add((Object)a);
        }
        tag.m_128365_("Attributes", (Tag)list);
        final Double maxHealth = cfg.attributes.get("minecraft:generic.max_health");
        if (maxHealth != null) {
            tag.m_128350_("Health", maxHealth.floatValue());
        }
    }
    
    private static void applyEquipment(final SpawnerConfig cfg, final CompoundTag tag) {
        if (cfg.equipment.isEmpty()) {
            return;
        }
        final ItemStack mainHand = stack(cfg, EquipmentSlot.MAINHAND);
        final ItemStack offHand = stack(cfg, EquipmentSlot.OFFHAND);
        final ItemStack feet = stack(cfg, EquipmentSlot.FEET);
        final ItemStack legs = stack(cfg, EquipmentSlot.LEGS);
        final ItemStack chest = stack(cfg, EquipmentSlot.CHEST);
        final ItemStack head = stack(cfg, EquipmentSlot.HEAD);
        final ListTag handItems = new ListTag();
        handItems.add((Object)itemTag(mainHand));
        handItems.add((Object)itemTag(offHand));
        tag.m_128365_("HandItems", (Tag)handItems);
        final ListTag armorItems = new ListTag();
        armorItems.add((Object)itemTag(feet));
        armorItems.add((Object)itemTag(legs));
        armorItems.add((Object)itemTag(chest));
        armorItems.add((Object)itemTag(head));
        tag.m_128365_("ArmorItems", (Tag)armorItems);
        final ListTag handDrops = new ListTag();
        handDrops.add((Object)FloatTag.m_128566_(dropChance(cfg, EquipmentSlot.MAINHAND)));
        handDrops.add((Object)FloatTag.m_128566_(dropChance(cfg, EquipmentSlot.OFFHAND)));
        tag.m_128365_("HandDropChances", (Tag)handDrops);
        final ListTag armorDrops = new ListTag();
        armorDrops.add((Object)FloatTag.m_128566_(dropChance(cfg, EquipmentSlot.FEET)));
        armorDrops.add((Object)FloatTag.m_128566_(dropChance(cfg, EquipmentSlot.LEGS)));
        armorDrops.add((Object)FloatTag.m_128566_(dropChance(cfg, EquipmentSlot.CHEST)));
        armorDrops.add((Object)FloatTag.m_128566_(dropChance(cfg, EquipmentSlot.HEAD)));
        tag.m_128365_("ArmorDropChances", (Tag)armorDrops);
    }
    
    private static ItemStack stack(final SpawnerConfig cfg, final EquipmentSlot slot) {
        final EquipmentEntry e = cfg.equipmentFor(slot);
        return (e == null) ? ItemStack.f_41583_ : e.item;
    }
    
    private static float dropChance(final SpawnerConfig cfg, final EquipmentSlot slot) {
        final EquipmentEntry e = cfg.equipmentFor(slot);
        return (e == null) ? 0.0f : e.dropChance;
    }
    
    private static CompoundTag itemTag(final ItemStack stack) {
        final CompoundTag t = new CompoundTag();
        if (stack != null && !stack.m_41619_()) {
            stack.m_41739_(t);
        }
        return t;
    }
    
    private static void applyEffects(final SpawnerConfig cfg, final CompoundTag tag) {
        if (cfg.effects.isEmpty()) {
            return;
        }
        final ListTag list = new ListTag();
        for (final EffectEntry fx : cfg.effects) {
            final MobEffect effect = (MobEffect)ForgeRegistries.MOB_EFFECTS.getValue(safeRl(fx.id));
            if (effect == null) {
                continue;
            }
            final int duration = fx.permanent ? Integer.MAX_VALUE : Math.max(1, fx.duration);
            final MobEffectInstance instance = new MobEffectInstance(effect, duration, Math.max(0, fx.amplifier), fx.ambient, fx.particles, fx.particles);
            list.add((Object)instance.m_19555_(new CompoundTag()));
        }
        if (!list.isEmpty()) {
            tag.m_128365_("ActiveEffects", (Tag)list);
        }
    }
    
    private static void applyAppearance(final SpawnerConfig cfg, final CompoundTag tag) {
        if (cfg.mobName != null && !cfg.mobName.isEmpty()) {
            Style style = Style.f_131099_;
            final TextColor color = colorOf(cfg.nameColor);
            if (color != null) {
                style = style.m_131148_(color);
            }
            final Component name = (Component)Component.m_237113_(cfg.mobName).m_130948_(style);
            tag.m_128359_("CustomName", Component.Serializer.m_130703_(name));
            tag.m_128379_("CustomNameVisible", cfg.mobNameVisible);
        }
        if (cfg.glowing) {
            tag.m_128379_("Glowing", true);
        }
        if (cfg.bossMode) {
            tag.m_128379_("Glowing", true);
            tag.m_128379_("PersistenceRequired", true);
        }
    }
    
    private static void applyMarker(final SpawnerConfig cfg, final CompoundTag tag, final boolean includeFullConfig) {
        final CompoundTag forgeData = tag.m_128441_("ForgeData") ? tag.m_128469_("ForgeData") : new CompoundTag();
        final CompoundTag marker = new CompoundTag();
        if (includeFullConfig) {
            marker.m_128365_("cfg", (Tag)cfg.save());
        }
        if (cfg.infernal.isEnabled()) {
            marker.m_128365_("infernal", (Tag)cfg.infernal.save());
        }
        if (!cfg.drops.isEmpty()) {
            final ListTag dropList = new ListTag();
            for (final DropEntry d : cfg.drops) {
                dropList.add((Object)d.save());
            }
            marker.m_128365_("drops", (Tag)dropList);
        }
        marker.m_128379_("keepVanillaDrops", cfg.keepVanillaDrops);
        final CompoundTag appear = new CompoundTag();
        for (final EquipmentEntry e : cfg.equipment) {
            if (!e.item.m_41619_() && e.appearChance < 1.0f) {
                appear.m_128350_(e.slot.m_20751_(), e.appearChance);
            }
        }
        if (!appear.m_128456_()) {
            marker.m_128365_("appearChances", (Tag)appear);
        }
        forgeData.m_128365_("fspawner", (Tag)marker);
        tag.m_128365_("ForgeData", (Tag)forgeData);
    }
    
    private static ResourceLocation safeRl(final String id) {
        final ResourceLocation rl = ResourceLocation.m_135820_((id == null) ? "" : id.toLowerCase(Locale.ROOT));
        return (rl == null) ? new ResourceLocation("minecraft", "strength") : rl;
    }
    
    private static TextColor colorOf(final String name) {
        if (name == null || name.isEmpty()) {
            return null;
        }
        if (name.startsWith("#")) {
            final TextColor parsed = TextColor.m_131268_(name);
            return parsed;
        }
        final ChatFormatting fmt = ChatFormatting.m_126657_(name.toLowerCase(Locale.ROOT));
        if (fmt != null && fmt.m_126664_()) {
            return TextColor.m_131270_(fmt);
        }
        return null;
    }
}
