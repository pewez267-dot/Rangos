// 
// Decompiled by Procyon v0.6.0
// 

package com.fspawner.command;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.world.item.ItemStack;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.server.level.ServerPlayer;
import com.fspawner.network.FSNetwork;
import com.fspawner.network.OpenScreenPacket;
import com.fspawner.config.SpawnerConfig;
import com.fspawner.item.SpawnerItemBuilder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.commands.SharedSuggestionProvider;
import com.mojang.brigadier.suggestion.Suggestions;
import java.util.concurrent.CompletableFuture;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.Commands;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandSourceStack;
import com.mojang.brigadier.CommandDispatcher;

public final class FSpawnerCommand
{
    private FSpawnerCommand() {
    }
    
    public static void register(final CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)Commands.m_82127_("fspawner").requires(source -> source.m_6761_(4))).executes(FSpawnerCommand::openEditor)).then(Commands.m_82127_("create").executes(FSpawnerCommand::createNew))).then(Commands.m_82127_("pickup").executes(FSpawnerCommand::pickup))).then(Commands.m_82127_("save").then(Commands.m_82129_("name", (ArgumentType)StringArgumentType.word()).executes(FSpawnerCommand::savePreset)))).then(Commands.m_82127_("load").then(Commands.m_82129_("name", (ArgumentType)StringArgumentType.word()).suggests((c, b) -> suggestPresets((CommandContext<CommandSourceStack>)c, b)).executes(FSpawnerCommand::loadPreset)))).then(Commands.m_82127_("delete").then(Commands.m_82129_("name", (ArgumentType)StringArgumentType.word()).suggests((c, b) -> suggestPresets((CommandContext<CommandSourceStack>)c, b)).executes(FSpawnerCommand::deletePreset))));
    }
    
    private static CompletableFuture<Suggestions> suggestPresets(final CommandContext<CommandSourceStack> ctx, final SuggestionsBuilder builder) {
        try {
            final ServerLevel level = ((CommandSourceStack)ctx.getSource()).m_81372_();
            return SharedSuggestionProvider.m_82970_((Iterable)FSpawnerPresets.get(level).names(), builder);
        }
        catch (final Exception e) {
            return builder.buildFuture();
        }
    }
    
    private static int openEditor(final CommandContext<CommandSourceStack> ctx) {
        final ServerPlayer player = playerOrNull(ctx);
        if (player == null) {
            return 0;
        }
        SpawnerConfig cfg = SpawnerItemBuilder.readConfig(player.m_21205_());
        if (cfg == null) {
            cfg = SpawnerItemBuilder.readConfig(player.m_21206_());
        }
        if (cfg == null) {
            cfg = new SpawnerConfig();
        }
        FSNetwork.sendToClient(player, new OpenScreenPacket(cfg.save()));
        return 1;
    }
    
    private static int createNew(final CommandContext<CommandSourceStack> ctx) {
        final ServerPlayer player = playerOrNull(ctx);
        if (player == null) {
            return 0;
        }
        FSNetwork.sendToClient(player, new OpenScreenPacket(new SpawnerConfig().save()));
        return 1;
    }
    
    private static int pickup(final CommandContext<CommandSourceStack> ctx) {
        final ServerPlayer player = playerOrNull(ctx);
        if (player == null) {
            return 0;
        }
        try {
            final HitResult hit = player.m_19907_(6.0, 1.0f, false);
            if (hit.m_6662_() != HitResult.Type.BLOCK) {
                fail(player);
                return 0;
            }
            final BlockHitResult blockHit = (BlockHitResult)hit;
            final ServerLevel level = player.m_284548_();
            final BlockEntity be = level.m_7702_(blockHit.m_82425_());
            if (!(be instanceof SpawnerBlockEntity)) {
                fail(player);
                return 0;
            }
            final CompoundTag beTag = be.m_187482_();
            final ItemStack item = SpawnerItemBuilder.fromBlockEntityNbt(beTag);
            if (item == null) {
                fail(player);
                return 0;
            }
            level.m_7471_(blockHit.m_82425_(), false);
            if (!player.m_150109_().m_36054_(item)) {
                player.m_36176_(item, false);
            }
            player.m_213846_((Component)Component.m_237115_("fspawner.command.pickup.success"));
            return 1;
        }
        catch (final Exception e) {
            player.m_213846_((Component)Component.m_237113_("§cError en pickup: " + e.getMessage()));
            return 0;
        }
    }
    
    private static void fail(final ServerPlayer player) {
        player.m_213846_((Component)Component.m_237115_("fspawner.command.pickup.fail"));
    }
    
    private static int savePreset(final CommandContext<CommandSourceStack> ctx) {
        final ServerPlayer player = playerOrNull(ctx);
        if (player == null) {
            return 0;
        }
        final String name = StringArgumentType.getString((CommandContext)ctx, "name");
        final SpawnerConfig cfg = SpawnerItemBuilder.readConfig(player.m_21205_());
        if (cfg == null) {
            player.m_213846_((Component)Component.m_237113_("§cSost\u00e9n un item Fantastic Spawner en la mano para guardar su configuraci\u00f3n."));
            return 0;
        }
        try {
            FSpawnerPresets.get(player.m_284548_()).put(name, cfg.save());
            player.m_213846_((Component)Component.m_237110_("fspawner.command.saved", new Object[] { name }));
            return 1;
        }
        catch (final Exception e) {
            player.m_213846_((Component)Component.m_237113_("§cError al guardar: " + e.getMessage()));
            return 0;
        }
    }
    
    private static int loadPreset(final CommandContext<CommandSourceStack> ctx) {
        final ServerPlayer player = playerOrNull(ctx);
        if (player == null) {
            return 0;
        }
        final String name = StringArgumentType.getString((CommandContext)ctx, "name");
        try {
            final CompoundTag cfgTag = FSpawnerPresets.get(player.m_284548_()).get(name);
            if (cfgTag == null) {
                player.m_213846_((Component)Component.m_237110_("fspawner.command.not_found", new Object[] { name }));
                return 0;
            }
            final ItemStack item = SpawnerItemBuilder.build(SpawnerConfig.load(cfgTag));
            if (!player.m_150109_().m_36054_(item)) {
                player.m_36176_(item, false);
            }
            player.m_213846_((Component)Component.m_237110_("fspawner.command.loaded", new Object[] { name }));
            return 1;
        }
        catch (final Exception e) {
            player.m_213846_((Component)Component.m_237113_("§cError al cargar: " + e.getMessage()));
            return 0;
        }
    }
    
    private static int deletePreset(final CommandContext<CommandSourceStack> ctx) {
        final ServerPlayer player = playerOrNull(ctx);
        if (player == null) {
            return 0;
        }
        final String name = StringArgumentType.getString((CommandContext)ctx, "name");
        try {
            final boolean removed = FSpawnerPresets.get(player.m_284548_()).remove(name);
            player.m_213846_((Component)Component.m_237110_(removed ? "fspawner.command.deleted" : "fspawner.command.not_found", new Object[] { name }));
            return removed ? 1 : 0;
        }
        catch (final Exception e) {
            player.m_213846_((Component)Component.m_237113_("§cError al eliminar: " + e.getMessage()));
            return 0;
        }
    }
    
    private static ServerPlayer playerOrNull(final CommandContext<CommandSourceStack> ctx) {
        try {
            return ((CommandSourceStack)ctx.getSource()).m_81375_();
        }
        catch (final Exception e) {
            ((CommandSourceStack)ctx.getSource()).m_81352_((Component)Component.m_237113_("Este comando debe ejecutarlo un jugador."));
            return null;
        }
    }
}
