package com.fspawner.command;

import com.fspawner.config.SpawnerConfig;
import com.fspawner.item.SpawnerItemBuilder;
import com.fspawner.network.EditContext;
import com.fspawner.network.FSNetwork;
import com.fspawner.network.OpenScreenPacket;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

import java.util.concurrent.CompletableFuture;

public final class FSpawnerCommand {

    private FSpawnerCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
            Commands.literal("fspawner")
                .requires(s -> s.hasPermission(2))
                .executes(FSpawnerCommand::editAuto)
                .then(Commands.literal("edit").executes(FSpawnerCommand::editAuto))
                .then(Commands.literal("create").executes(FSpawnerCommand::createNew))
                .then(Commands.literal("pickup").executes(FSpawnerCommand::pickup))
                .then(Commands.literal("save")
                    .then(Commands.argument("name", StringArgumentType.word())
                        .executes(FSpawnerCommand::savePreset)))
                .then(Commands.literal("load")
                    .then(Commands.argument("name", StringArgumentType.word())
                        .suggests(FSpawnerCommand::suggestPresets)
                        .executes(FSpawnerCommand::loadPreset)))
                .then(Commands.literal("delete")
                    .then(Commands.argument("name", StringArgumentType.word())
                        .suggests(FSpawnerCommand::suggestPresets)
                        .executes(FSpawnerCommand::deletePreset)))
        );
        // Alias corto: /fsedit
        dispatcher.register(
            Commands.literal("fsedit").requires(s -> s.hasPermission(2)).executes(FSpawnerCommand::editAuto)
        );
    }

    private static CompletableFuture<Suggestions> suggestPresets(CommandContext<CommandSourceStack> ctx, SuggestionsBuilder builder) {
        try {
            ServerLevel level = ctx.getSource().getLevel();
            return SharedSuggestionProvider.suggest(FSpawnerPresets.get(level).names(), builder);
        } catch (Exception e) {
            return builder.buildFuture();
        }
    }

    /**
     * Detecta automáticamente el contexto:
     *   1. Si hay un Fantastic Spawner en la mano principal → editar y reemplazar al guardar.
     *   2. Si hay uno en la mano secundaria → editar y reemplazar al guardar.
     *   3. Si está mirando un Fantastic Spawner colocado a ≤6 bloques → editar el bloque.
     *   4. Caso contrario → abrir editor con configuración nueva.
     */
    private static int editAuto(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = playerOrNull(ctx);
        if (player == null) return 0;

        ItemStack mainHand = player.getMainHandItem();
        if (SpawnerItemBuilder.isFantasticSpawner(mainHand)) {
            SpawnerConfig cfg = SpawnerItemBuilder.readConfig(mainHand);
            if (cfg == null) cfg = new SpawnerConfig();
            int slot = player.getInventory().selected;
            FSNetwork.sendToClient(player, new OpenScreenPacket(cfg.save(), EditContext.mainHand(slot)));
            return 1;
        }

        ItemStack offHand = player.getOffhandItem();
        if (SpawnerItemBuilder.isFantasticSpawner(offHand)) {
            SpawnerConfig cfg = SpawnerItemBuilder.readConfig(offHand);
            if (cfg == null) cfg = new SpawnerConfig();
            FSNetwork.sendToClient(player, new OpenScreenPacket(cfg.save(), EditContext.offHand()));
            return 1;
        }

        // Bloque mirado
        HitResult hit = player.pick(6.0D, 1.0F, false);
        if (hit.getType() == HitResult.Type.BLOCK) {
            BlockHitResult bh = (BlockHitResult) hit;
            BlockEntity be = player.serverLevel().getBlockEntity(bh.getBlockPos());
            if (be instanceof SpawnerBlockEntity) {
                CompoundTag beTag = be.saveWithoutMetadata();
                CompoundTag cfgTag = SpawnerItemBuilder.extractConfigForEditing(beTag);
                if (cfgTag != null) {
                    FSNetwork.sendToClient(player, new OpenScreenPacket(cfgTag, EditContext.block(bh.getBlockPos())));
                    return 1;
                }
            }
        }

        FSNetwork.sendToClient(player, new OpenScreenPacket(new SpawnerConfig().save(), EditContext.newSession()));
        return 1;
    }

    private static int createNew(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = playerOrNull(ctx);
        if (player == null) return 0;
        FSNetwork.sendToClient(player, new OpenScreenPacket(new SpawnerConfig().save(), EditContext.newSession()));
        return 1;
    }

    private static int pickup(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = playerOrNull(ctx);
        if (player == null) return 0;
        try {
            HitResult hit = player.pick(6.0D, 1.0F, false);
            if (hit.getType() != HitResult.Type.BLOCK) { fail(player); return 0; }
            BlockHitResult bh = (BlockHitResult) hit;
            ServerLevel level = player.serverLevel();
            BlockEntity be = level.getBlockEntity(bh.getBlockPos());
            if (!(be instanceof SpawnerBlockEntity)) { fail(player); return 0; }
            CompoundTag beTag = be.saveWithoutMetadata();
            ItemStack item = SpawnerItemBuilder.fromBlockEntityNbt(beTag);
            if (item == null) { fail(player); return 0; }
            level.removeBlock(bh.getBlockPos(), false);
            if (!player.getInventory().add(item)) player.drop(item, false);
            player.sendSystemMessage(Component.translatable("fspawner.command.pickup.success"));
            return 1;
        } catch (Exception e) {
            player.sendSystemMessage(Component.literal("§cError en pickup: " + e.getMessage()));
            return 0;
        }
    }

    private static void fail(ServerPlayer player) {
        player.sendSystemMessage(Component.translatable("fspawner.command.pickup.fail"));
    }

    private static int savePreset(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = playerOrNull(ctx);
        if (player == null) return 0;
        String name = StringArgumentType.getString(ctx, "name");
        SpawnerConfig cfg = SpawnerItemBuilder.readConfig(player.getMainHandItem());
        if (cfg == null) cfg = SpawnerItemBuilder.readConfig(player.getOffhandItem());
        if (cfg == null) {
            player.sendSystemMessage(Component.literal("§cSostén un Fantastic Spawner para guardar su configuración."));
            return 0;
        }
        try {
            FSpawnerPresets.get(player.serverLevel()).put(name, cfg.save());
            player.sendSystemMessage(Component.translatable("fspawner.command.saved", new Object[]{ name }));
            return 1;
        } catch (Exception e) {
            player.sendSystemMessage(Component.literal("§cError al guardar: " + e.getMessage()));
            return 0;
        }
    }

    private static int loadPreset(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = playerOrNull(ctx);
        if (player == null) return 0;
        String name = StringArgumentType.getString(ctx, "name");
        try {
            CompoundTag cfgTag = FSpawnerPresets.get(player.serverLevel()).get(name);
            if (cfgTag == null) {
                player.sendSystemMessage(Component.translatable("fspawner.command.not_found", new Object[]{ name }));
                return 0;
            }
            ItemStack item = SpawnerItemBuilder.build(SpawnerConfig.load(cfgTag));
            if (!player.getInventory().add(item)) player.drop(item, false);
            player.sendSystemMessage(Component.translatable("fspawner.command.loaded", new Object[]{ name }));
            return 1;
        } catch (Exception e) {
            player.sendSystemMessage(Component.literal("§cError al cargar: " + e.getMessage()));
            return 0;
        }
    }

    private static int deletePreset(CommandContext<CommandSourceStack> ctx) {
        ServerPlayer player = playerOrNull(ctx);
        if (player == null) return 0;
        String name = StringArgumentType.getString(ctx, "name");
        try {
            boolean removed = FSpawnerPresets.get(player.serverLevel()).remove(name);
            player.sendSystemMessage(Component.translatable(removed ? "fspawner.command.deleted" : "fspawner.command.not_found",
                    new Object[]{ name }));
            return removed ? 1 : 0;
        } catch (Exception e) {
            player.sendSystemMessage(Component.literal("§cError al eliminar: " + e.getMessage()));
            return 0;
        }
    }

    private static ServerPlayer playerOrNull(CommandContext<CommandSourceStack> ctx) {
        try {
            return ctx.getSource().getPlayerOrException();
        } catch (Exception e) {
            ctx.getSource().sendFailure(Component.literal("Este comando debe ejecutarlo un jugador."));
            return null;
        }
    }
}
