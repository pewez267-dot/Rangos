// 
// Decompiled by Procyon v0.6.0
// 

package com.fspawner.config;

import net.minecraft.nbt.CompoundTag;

public class EffectEntry
{
    public String id;
    public int amplifier;
    public int duration;
    public boolean permanent;
    public boolean ambient;
    public boolean particles;
    
    public EffectEntry(final String id, final int amplifier, final int duration, final boolean permanent, final boolean ambient, final boolean particles) {
        this.id = id;
        this.amplifier = amplifier;
        this.duration = duration;
        this.permanent = permanent;
        this.ambient = ambient;
        this.particles = particles;
    }
    
    public EffectEntry(final String id) {
        this(id, 0, 600, false, false, true);
    }
    
    public CompoundTag save() {
        final CompoundTag tag = new CompoundTag();
        tag.m_128359_("id", (this.id == null) ? "minecraft:strength" : this.id);
        tag.m_128405_("amplifier", this.amplifier);
        tag.m_128405_("duration", this.duration);
        tag.m_128379_("permanent", this.permanent);
        tag.m_128379_("ambient", this.ambient);
        tag.m_128379_("particles", this.particles);
        return tag;
    }
    
    public static EffectEntry load(final CompoundTag tag) {
        return new EffectEntry(tag.m_128461_("id"), tag.m_128451_("amplifier"), tag.m_128441_("duration") ? tag.m_128451_("duration") : 600, tag.m_128471_("permanent"), tag.m_128471_("ambient"), !tag.m_128441_("particles") || tag.m_128471_("particles"));
    }
    
    public EffectEntry copy() {
        return new EffectEntry(this.id, this.amplifier, this.duration, this.permanent, this.ambient, this.particles);
    }
}
