// 
// Decompiled by Procyon v0.6.0
// 

package com.fspawner.config;

import net.minecraft.nbt.Tag;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;

public class DropEntry
{
    public ItemStack item;
    public int min;
    public int max;
    public float chance;
    
    public DropEntry(final ItemStack item, final int min, final int max, final float chance) {
        this.item = ((item == null) ? ItemStack.f_41583_ : item);
        this.min = min;
        this.max = max;
        this.chance = chance;
    }
    
    public CompoundTag save() {
        final CompoundTag tag = new CompoundTag();
        final CompoundTag itemTag = new CompoundTag();
        if (!this.item.m_41619_()) {
            this.item.m_41739_(itemTag);
        }
        tag.m_128365_("item", (Tag)itemTag);
        tag.m_128405_("min", this.min);
        tag.m_128405_("max", this.max);
        tag.m_128350_("chance", this.chance);
        return tag;
    }
    
    public static DropEntry load(final CompoundTag tag) {
        ItemStack stack = ItemStack.f_41583_;
        if (tag.m_128441_("item")) {
            final CompoundTag itemTag = tag.m_128469_("item");
            if (!itemTag.m_128456_()) {
                stack = ItemStack.m_41712_(itemTag);
            }
        }
        return new DropEntry(stack, tag.m_128451_("min"), tag.m_128451_("max"), tag.m_128441_("chance") ? tag.m_128457_("chance") : 1.0f);
    }
    
    public DropEntry copy() {
        return new DropEntry(this.item.m_41777_(), this.min, this.max, this.chance);
    }
}
