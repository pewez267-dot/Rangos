// 
// Decompiled by Procyon v0.6.0
// 

package com.fspawner.config;

import net.minecraft.nbt.Tag;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.EquipmentSlot;

public class EquipmentEntry
{
    public EquipmentSlot slot;
    public ItemStack item;
    public float dropChance;
    public float appearChance;
    
    public EquipmentEntry(final EquipmentSlot slot, final ItemStack item, final float dropChance, final float appearChance) {
        this.slot = slot;
        this.item = ((item == null) ? ItemStack.f_41583_ : item);
        this.dropChance = dropChance;
        this.appearChance = appearChance;
    }
    
    public EquipmentEntry(final EquipmentSlot slot) {
        this(slot, ItemStack.f_41583_, 0.085f, 1.0f);
    }
    
    public CompoundTag save() {
        final CompoundTag tag = new CompoundTag();
        tag.m_128359_("slot", this.slot.m_20751_());
        final CompoundTag itemTag = new CompoundTag();
        if (!this.item.m_41619_()) {
            this.item.m_41739_(itemTag);
        }
        tag.m_128365_("item", (Tag)itemTag);
        tag.m_128350_("dropChance", this.dropChance);
        tag.m_128350_("appearChance", this.appearChance);
        return tag;
    }
    
    public static EquipmentEntry load(final CompoundTag tag) {
        final EquipmentSlot slot = slotByName(tag.m_128461_("slot"));
        ItemStack stack = ItemStack.f_41583_;
        if (tag.m_128441_("item")) {
            final CompoundTag itemTag = tag.m_128469_("item");
            if (!itemTag.m_128456_()) {
                stack = ItemStack.m_41712_(itemTag);
            }
        }
        final float drop = tag.m_128441_("dropChance") ? tag.m_128457_("dropChance") : 0.085f;
        final float appear = tag.m_128441_("appearChance") ? tag.m_128457_("appearChance") : 1.0f;
        return new EquipmentEntry(slot, stack, drop, appear);
    }
    
    public static EquipmentSlot slotByName(final String name) {
        for (final EquipmentSlot s : EquipmentSlot.values()) {
            if (s.m_20751_().equals(name)) {
                return s;
            }
        }
        return EquipmentSlot.MAINHAND;
    }
    
    public EquipmentEntry copy() {
        return new EquipmentEntry(this.slot, this.item.m_41777_(), this.dropChance, this.appearChance);
    }
}
