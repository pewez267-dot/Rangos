// 
// Decompiled by Procyon v0.6.0
// 

package com.fspawner.config;

import net.minecraft.nbt.CompoundTag;

public class EntityEntry
{
    public String id;
    public int weight;
    
    public EntityEntry(final String id, final int weight) {
        this.id = id;
        this.weight = Math.max(1, weight);
    }
    
    public EntityEntry(final String id) {
        this(id, 1);
    }
    
    public CompoundTag save() {
        final CompoundTag tag = new CompoundTag();
        tag.m_128359_("id", (this.id == null) ? "minecraft:pig" : this.id);
        tag.m_128405_("weight", this.weight);
        return tag;
    }
    
    public static EntityEntry load(final CompoundTag tag) {
        return new EntityEntry(tag.m_128461_("id"), tag.m_128441_("weight") ? tag.m_128451_("weight") : 1);
    }
    
    public EntityEntry copy() {
        return new EntityEntry(this.id, this.weight);
    }
}
