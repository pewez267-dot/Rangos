package com.fspawner.config;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.world.entity.EquipmentSlot;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class SpawnerConfig {

    public enum EntityMode { FIXED, POOL }

    public enum DayCycle { ANY, DAY_ONLY, NIGHT_ONLY }

    public enum Weather { ANY, CLEAR, RAIN, THUNDER }

    // Entidades
    public EntityMode entityMode = EntityMode.FIXED;
    public final List<EntityEntry> entities = new ArrayList<>();

    // Aparición
    public int spawnDelayMin = 200;
    public int spawnDelayMax = 800;
    public int spawnCount = 4;
    public int spawnRange = 4;
    public int activationRange = 16;
    public int maxNearbyEntities = 6;
    public boolean waves = false;
    public boolean bossMode = false;
    public boolean continuous = true;

    // Reguladores extra (fspawner-only, los aplicamos via eventos)
    public DayCycle dayCycle = DayCycle.ANY;
    public Weather weather = Weather.ANY;
    public int minLight = 0;          // 0 = sin restricción inferior
    public int maxLight = 15;         // 15 = sin restricción superior
    public boolean requiresSky = false;       // mob solo aparece si ve cielo
    public boolean requiresNoSky = false;     // mob solo aparece bajo techo
    public boolean requiresPlayer = true;     // necesita jugador en activationRange (siempre vanilla)
    public int extraCooldown = 0;             // ticks añadidos extra entre oleadas

    // Atributos / equipo / efectos / infernal / drops / aspecto
    public final Map<String, Double> attributes = new LinkedHashMap<>();
    public final List<EquipmentEntry> equipment = new ArrayList<>();
    public final List<EffectEntry> effects = new ArrayList<>();
    public InfernalConfig infernal = new InfernalConfig();
    public final List<DropEntry> drops = new ArrayList<>();
    public boolean keepVanillaDrops = true;

    public String itemName = "§d\u2726 Fantastic Spawner \u2726";
    public String mobName = "";
    public boolean mobNameVisible = false;
    public boolean glowing = false;
    public String nameColor = "white";
    public boolean particles = false;

    public SpawnerConfig() {
        this.entities.add(new EntityEntry("minecraft:zombie"));
    }

    public String primaryEntityId() {
        return this.entities.isEmpty() ? "minecraft:pig" : this.entities.get(0).id;
    }

    public EquipmentEntry equipmentFor(EquipmentSlot slot) {
        for (EquipmentEntry e : this.equipment) {
            if (e.slot == slot) return e;
        }
        return null;
    }

    public SpawnerConfig copy() {
        return load(this.save());
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putString("entityMode", this.entityMode.name());
        ListTag entityList = new ListTag();
        for (EntityEntry e : this.entities) entityList.add(e.save());
        tag.put("entities", entityList);

        CompoundTag spawn = new CompoundTag();
        spawn.putInt("delayMin", this.spawnDelayMin);
        spawn.putInt("delayMax", this.spawnDelayMax);
        spawn.putInt("count", this.spawnCount);
        spawn.putInt("range", this.spawnRange);
        spawn.putInt("activationRange", this.activationRange);
        spawn.putInt("maxNearby", this.maxNearbyEntities);
        spawn.putBoolean("waves", this.waves);
        spawn.putBoolean("bossMode", this.bossMode);
        spawn.putBoolean("continuous", this.continuous);
        spawn.putString("dayCycle", this.dayCycle.name());
        spawn.putString("weather", this.weather.name());
        spawn.putInt("minLight", this.minLight);
        spawn.putInt("maxLight", this.maxLight);
        spawn.putBoolean("requiresSky", this.requiresSky);
        spawn.putBoolean("requiresNoSky", this.requiresNoSky);
        spawn.putBoolean("requiresPlayer", this.requiresPlayer);
        spawn.putInt("extraCooldown", this.extraCooldown);
        tag.put("spawn", spawn);

        CompoundTag attrs = new CompoundTag();
        for (Map.Entry<String, Double> e : this.attributes.entrySet()) {
            attrs.putDouble(e.getKey(), e.getValue());
        }
        tag.put("attributes", attrs);

        ListTag eqList = new ListTag();
        for (EquipmentEntry e : this.equipment) eqList.add(e.save());
        tag.put("equipment", eqList);

        ListTag fxList = new ListTag();
        for (EffectEntry e : this.effects) fxList.add(e.save());
        tag.put("effects", fxList);

        tag.put("infernal", this.infernal.save());

        ListTag dropList = new ListTag();
        for (DropEntry d : this.drops) dropList.add(d.save());
        tag.put("drops", dropList);
        tag.putBoolean("keepVanillaDrops", this.keepVanillaDrops);

        CompoundTag ap = new CompoundTag();
        ap.putString("itemName", this.itemName);
        ap.putString("mobName", this.mobName);
        ap.putBoolean("mobNameVisible", this.mobNameVisible);
        ap.putBoolean("glowing", this.glowing);
        ap.putString("nameColor", this.nameColor);
        ap.putBoolean("particles", this.particles);
        tag.put("appearance", ap);

        return tag;
    }

    public static SpawnerConfig load(CompoundTag tag) {
        SpawnerConfig cfg = new SpawnerConfig();
        cfg.entities.clear();
        cfg.attributes.clear();
        cfg.equipment.clear();
        cfg.effects.clear();
        cfg.drops.clear();

        try {
            cfg.entityMode = EntityMode.valueOf(tag.getString("entityMode"));
        } catch (Exception ignored) {
            cfg.entityMode = EntityMode.FIXED;
        }

        ListTag entityList = tag.getList("entities", 10);
        for (int i = 0; i < entityList.size(); i++) {
            cfg.entities.add(EntityEntry.load(entityList.getCompound(i)));
        }
        if (cfg.entities.isEmpty()) cfg.entities.add(new EntityEntry("minecraft:zombie"));

        if (tag.contains("spawn")) {
            CompoundTag spawn = tag.getCompound("spawn");
            cfg.spawnDelayMin = spawn.getInt("delayMin");
            cfg.spawnDelayMax = spawn.getInt("delayMax");
            cfg.spawnCount = spawn.getInt("count");
            cfg.spawnRange = spawn.getInt("range");
            cfg.activationRange = spawn.getInt("activationRange");
            cfg.maxNearbyEntities = spawn.getInt("maxNearby");
            cfg.waves = spawn.getBoolean("waves");
            cfg.bossMode = spawn.getBoolean("bossMode");
            cfg.continuous = spawn.getBoolean("continuous");
            try { cfg.dayCycle = DayCycle.valueOf(spawn.getString("dayCycle")); } catch (Exception ignored) {}
            try { cfg.weather = Weather.valueOf(spawn.getString("weather")); } catch (Exception ignored) {}
            cfg.minLight = spawn.contains("minLight") ? spawn.getInt("minLight") : 0;
            cfg.maxLight = spawn.contains("maxLight") ? spawn.getInt("maxLight") : 15;
            cfg.requiresSky = spawn.getBoolean("requiresSky");
            cfg.requiresNoSky = spawn.getBoolean("requiresNoSky");
            cfg.requiresPlayer = !spawn.contains("requiresPlayer") || spawn.getBoolean("requiresPlayer");
            cfg.extraCooldown = spawn.contains("extraCooldown") ? spawn.getInt("extraCooldown") : 0;
        }

        if (tag.contains("attributes")) {
            CompoundTag attrs = tag.getCompound("attributes");
            for (String key : attrs.getAllKeys()) cfg.attributes.put(key, attrs.getDouble(key));
        }

        ListTag eqList = tag.getList("equipment", 10);
        for (int i = 0; i < eqList.size(); i++) cfg.equipment.add(EquipmentEntry.load(eqList.getCompound(i)));

        ListTag fxList = tag.getList("effects", 10);
        for (int i = 0; i < fxList.size(); i++) cfg.effects.add(EffectEntry.load(fxList.getCompound(i)));

        if (tag.contains("infernal")) cfg.infernal = InfernalConfig.load(tag.getCompound("infernal"));

        ListTag dropList = tag.getList("drops", 10);
        for (int i = 0; i < dropList.size(); i++) cfg.drops.add(DropEntry.load(dropList.getCompound(i)));

        cfg.keepVanillaDrops = !tag.contains("keepVanillaDrops") || tag.getBoolean("keepVanillaDrops");

        if (tag.contains("appearance")) {
            CompoundTag ap = tag.getCompound("appearance");
            cfg.itemName = ap.getString("itemName");
            cfg.mobName = ap.getString("mobName");
            cfg.mobNameVisible = ap.getBoolean("mobNameVisible");
            cfg.glowing = ap.getBoolean("glowing");
            cfg.nameColor = ap.contains("nameColor") ? ap.getString("nameColor") : "white";
            cfg.particles = ap.getBoolean("particles");
        }
        if (cfg.itemName == null || cfg.itemName.isEmpty()) {
            cfg.itemName = "§d\u2726 Fantastic Spawner \u2726";
        }
        return cfg;
    }
}
