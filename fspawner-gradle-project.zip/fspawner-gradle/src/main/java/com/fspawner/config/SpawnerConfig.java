// 
// Decompiled by Procyon v0.6.0
// 

package com.fspawner.config;

import net.minecraft.world.entity.EquipmentSlot;
import java.util.Iterator;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.CompoundTag;
import java.util.LinkedHashMap;
import java.util.ArrayList;
import java.util.Map;
import java.util.List;

public class SpawnerConfig
{
    public EntityMode entityMode;
    public final List<EntityEntry> entities;
    public int spawnDelayMin;
    public int spawnDelayMax;
    public int spawnCount;
    public int spawnRange;
    public int activationRange;
    public int maxNearbyEntities;
    public boolean waves;
    public boolean bossMode;
    public boolean continuous;
    public final Map<String, Double> attributes;
    public final List<EquipmentEntry> equipment;
    public final List<EffectEntry> effects;
    public InfernalConfig infernal;
    public final List<DropEntry> drops;
    public boolean keepVanillaDrops;
    public String itemName;
    public String mobName;
    public boolean mobNameVisible;
    public boolean glowing;
    public String nameColor;
    public boolean particles;
    
    public SpawnerConfig() {
        this.entityMode = EntityMode.FIXED;
        this.entities = new ArrayList<EntityEntry>();
        this.spawnDelayMin = 200;
        this.spawnDelayMax = 800;
        this.spawnCount = 4;
        this.spawnRange = 4;
        this.activationRange = 16;
        this.maxNearbyEntities = 6;
        this.waves = false;
        this.bossMode = false;
        this.continuous = true;
        this.attributes = new LinkedHashMap<String, Double>();
        this.equipment = new ArrayList<EquipmentEntry>();
        this.effects = new ArrayList<EffectEntry>();
        this.infernal = new InfernalConfig();
        this.drops = new ArrayList<DropEntry>();
        this.keepVanillaDrops = true;
        this.itemName = "§d\u2726 Fantastic Spawner \u2726";
        this.mobName = "";
        this.mobNameVisible = false;
        this.glowing = false;
        this.nameColor = "white";
        this.particles = false;
        this.entities.add(new EntityEntry("minecraft:zombie"));
    }
    
    public String primaryEntityId() {
        return this.entities.isEmpty() ? "minecraft:pig" : this.entities.get(0).id;
    }
    
    public CompoundTag save() {
        final CompoundTag tag = new CompoundTag();
        tag.m_128359_("entityMode", this.entityMode.name());
        final ListTag entityList = new ListTag();
        for (final EntityEntry e : this.entities) {
            entityList.add((Object)e.save());
        }
        tag.m_128365_("entities", (Tag)entityList);
        final CompoundTag spawn = new CompoundTag();
        spawn.m_128405_("delayMin", this.spawnDelayMin);
        spawn.m_128405_("delayMax", this.spawnDelayMax);
        spawn.m_128405_("count", this.spawnCount);
        spawn.m_128405_("range", this.spawnRange);
        spawn.m_128405_("activationRange", this.activationRange);
        spawn.m_128405_("maxNearby", this.maxNearbyEntities);
        spawn.m_128379_("waves", this.waves);
        spawn.m_128379_("bossMode", this.bossMode);
        spawn.m_128379_("continuous", this.continuous);
        tag.m_128365_("spawn", (Tag)spawn);
        final CompoundTag attrs = new CompoundTag();
        for (final Map.Entry<String, Double> e2 : this.attributes.entrySet()) {
            attrs.m_128347_((String)e2.getKey(), (double)e2.getValue());
        }
        tag.m_128365_("attributes", (Tag)attrs);
        final ListTag eqList = new ListTag();
        for (final EquipmentEntry e3 : this.equipment) {
            eqList.add((Object)e3.save());
        }
        tag.m_128365_("equipment", (Tag)eqList);
        final ListTag fxList = new ListTag();
        for (final EffectEntry e4 : this.effects) {
            fxList.add((Object)e4.save());
        }
        tag.m_128365_("effects", (Tag)fxList);
        tag.m_128365_("infernal", (Tag)this.infernal.save());
        final ListTag dropList = new ListTag();
        for (final DropEntry d : this.drops) {
            dropList.add((Object)d.save());
        }
        tag.m_128365_("drops", (Tag)dropList);
        tag.m_128379_("keepVanillaDrops", this.keepVanillaDrops);
        final CompoundTag ap = new CompoundTag();
        ap.m_128359_("itemName", this.itemName);
        ap.m_128359_("mobName", this.mobName);
        ap.m_128379_("mobNameVisible", this.mobNameVisible);
        ap.m_128379_("glowing", this.glowing);
        ap.m_128359_("nameColor", this.nameColor);
        ap.m_128379_("particles", this.particles);
        tag.m_128365_("appearance", (Tag)ap);
        return tag;
    }
    
    public static SpawnerConfig load(final CompoundTag tag) {
        final SpawnerConfig cfg = new SpawnerConfig();
        cfg.entities.clear();
        cfg.attributes.clear();
        cfg.equipment.clear();
        cfg.effects.clear();
        cfg.drops.clear();
        try {
            cfg.entityMode = EntityMode.valueOf(tag.m_128461_("entityMode"));
        }
        catch (final IllegalArgumentException ignored) {
            cfg.entityMode = EntityMode.FIXED;
        }
        final ListTag entityList = tag.m_128437_("entities", 10);
        for (int i = 0; i < entityList.size(); ++i) {
            cfg.entities.add(EntityEntry.load(entityList.m_128728_(i)));
        }
        if (cfg.entities.isEmpty()) {
            cfg.entities.add(new EntityEntry("minecraft:zombie"));
        }
        if (tag.m_128441_("spawn")) {
            final CompoundTag spawn = tag.m_128469_("spawn");
            cfg.spawnDelayMin = spawn.m_128451_("delayMin");
            cfg.spawnDelayMax = spawn.m_128451_("delayMax");
            cfg.spawnCount = spawn.m_128451_("count");
            cfg.spawnRange = spawn.m_128451_("range");
            cfg.activationRange = spawn.m_128451_("activationRange");
            cfg.maxNearbyEntities = spawn.m_128451_("maxNearby");
            cfg.waves = spawn.m_128471_("waves");
            cfg.bossMode = spawn.m_128471_("bossMode");
            cfg.continuous = spawn.m_128471_("continuous");
        }
        if (tag.m_128441_("attributes")) {
            final CompoundTag attrs = tag.m_128469_("attributes");
            for (final String key : attrs.m_128431_()) {
                cfg.attributes.put(key, attrs.m_128459_(key));
            }
        }
        final ListTag eqList = tag.m_128437_("equipment", 10);
        for (int j = 0; j < eqList.size(); ++j) {
            cfg.equipment.add(EquipmentEntry.load(eqList.m_128728_(j)));
        }
        final ListTag fxList = tag.m_128437_("effects", 10);
        for (int k = 0; k < fxList.size(); ++k) {
            cfg.effects.add(EffectEntry.load(fxList.m_128728_(k)));
        }
        if (tag.m_128441_("infernal")) {
            cfg.infernal = InfernalConfig.load(tag.m_128469_("infernal"));
        }
        final ListTag dropList = tag.m_128437_("drops", 10);
        for (int l = 0; l < dropList.size(); ++l) {
            cfg.drops.add(DropEntry.load(dropList.m_128728_(l)));
        }
        cfg.keepVanillaDrops = (!tag.m_128441_("keepVanillaDrops") || tag.m_128471_("keepVanillaDrops"));
        if (tag.m_128441_("appearance")) {
            final CompoundTag ap = tag.m_128469_("appearance");
            cfg.itemName = ap.m_128461_("itemName");
            cfg.mobName = ap.m_128461_("mobName");
            cfg.mobNameVisible = ap.m_128471_("mobNameVisible");
            cfg.glowing = ap.m_128471_("glowing");
            cfg.nameColor = (ap.m_128441_("nameColor") ? ap.m_128461_("nameColor") : "white");
            cfg.particles = ap.m_128471_("particles");
        }
        if (cfg.itemName == null || cfg.itemName.isEmpty()) {
            cfg.itemName = "§d\u2726 Fantastic Spawner \u2726";
        }
        return cfg;
    }
    
    public EquipmentEntry equipmentFor(final EquipmentSlot slot) {
        for (final EquipmentEntry e : this.equipment) {
            if (e.slot == slot) {
                return e;
            }
        }
        return null;
    }
    
    public SpawnerConfig copy() {
        return load(this.save());
    }
    
    public enum EntityMode
    {
        FIXED, 
        POOL;
    }
}
