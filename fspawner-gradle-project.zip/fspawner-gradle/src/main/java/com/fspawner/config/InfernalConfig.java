// 
// Decompiled by Procyon v0.6.0
// 

package com.fspawner.config;

import java.util.Iterator;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.CompoundTag;
import java.util.Collections;
import java.util.Random;
import java.util.Collection;
import net.minecraft.util.RandomSource;
import java.util.ArrayList;
import java.util.List;

public class InfernalConfig
{
    public Mode mode;
    public List<String> mods;
    public List<String> pool;
    public int min;
    public int max;
    
    public InfernalConfig() {
        this.mode = Mode.DISABLED;
        this.mods = new ArrayList<String>();
        this.pool = new ArrayList<String>();
        this.min = 2;
        this.max = 5;
    }
    
    public boolean isEnabled() {
        return this.mode != Mode.DISABLED;
    }
    
    public String resolveModifierString(final RandomSource random) {
        switch (this.mode) {
            case ALWAYS:
            case CUSTOM: {
                return String.join(" ", this.mods);
            }
            case RANDOM: {
                if (this.pool.isEmpty()) {
                    return "";
                }
                final int lo = Math.max(0, Math.min(this.min, this.max));
                final int hi = Math.max(this.min, this.max);
                int count = lo + ((hi > lo) ? random.m_188503_(hi - lo + 1) : 0);
                count = Math.min(count, this.pool.size());
                final List<String> shuffled = new ArrayList<String>(this.pool);
                Collections.shuffle(shuffled, new Random(random.m_188505_()));
                return String.join(" ", shuffled.subList(0, count));
            }
            default: {
                return "";
            }
        }
    }
    
    public CompoundTag save() {
        final CompoundTag tag = new CompoundTag();
        tag.m_128359_("mode", this.mode.name());
        tag.m_128405_("min", this.min);
        tag.m_128405_("max", this.max);
        tag.m_128365_("mods", (Tag)toList(this.mods));
        tag.m_128365_("pool", (Tag)toList(this.pool));
        return tag;
    }
    
    public static InfernalConfig load(final CompoundTag tag) {
        final InfernalConfig cfg = new InfernalConfig();
        try {
            cfg.mode = Mode.valueOf(tag.m_128461_("mode"));
        }
        catch (final IllegalArgumentException ignored) {
            cfg.mode = Mode.DISABLED;
        }
        cfg.min = (tag.m_128441_("min") ? tag.m_128451_("min") : 2);
        cfg.max = (tag.m_128441_("max") ? tag.m_128451_("max") : 5);
        cfg.mods = fromList(tag.m_128437_("mods", 8));
        cfg.pool = fromList(tag.m_128437_("pool", 8));
        return cfg;
    }
    
    private static ListTag toList(final List<String> values) {
        final ListTag list = new ListTag();
        for (final String v : values) {
            list.add((Object)StringTag.m_129297_(v));
        }
        return list;
    }
    
    private static List<String> fromList(final ListTag list) {
        final List<String> out = new ArrayList<String>();
        for (int i = 0; i < list.size(); ++i) {
            out.add(list.m_128778_(i));
        }
        return out;
    }
    
    public InfernalConfig copy() {
        final InfernalConfig c = new InfernalConfig();
        c.mode = this.mode;
        c.min = this.min;
        c.max = this.max;
        c.mods = new ArrayList<String>(this.mods);
        c.pool = new ArrayList<String>(this.pool);
        return c;
    }
    
    public enum Mode
    {
        DISABLED, 
        ALWAYS, 
        RANDOM, 
        CUSTOM;
    }
}
