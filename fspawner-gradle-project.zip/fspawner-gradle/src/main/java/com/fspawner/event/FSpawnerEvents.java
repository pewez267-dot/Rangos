// 
// Decompiled by Procyon v0.6.0
// 

package com.fspawner.event;

import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.nbt.ListTag;
import com.fspawner.config.DropEntry;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraft.world.entity.EquipmentSlot;
import java.util.Iterator;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import com.fspawner.config.EquipmentEntry;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.CompoundTag;
import com.fspawner.integration.InfernalMobsIntegration;
import com.fspawner.config.InfernalConfig;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;

public final class FSpawnerEvents
{
    private FSpawnerEvents() {
    }
    
    @SubscribeEvent
    public static void onEntityJoin(final EntityJoinLevelEvent event) {
        final Level level = event.getLevel();
        if (level.m_5776_()) {
            return;
        }
        final Entity entity = event.getEntity();
        if (!(entity instanceof LivingEntity)) {
            return;
        }
        final LivingEntity living = (LivingEntity)entity;
        final CompoundTag forgeData = entity.getPersistentData();
        if (!forgeData.m_128441_("fspawner")) {
            return;
        }
        final CompoundTag marker = forgeData.m_128469_("fspawner");
        handleAppearChances(living, marker);
        if (marker.m_128441_("infernal")) {
            final InfernalConfig inf = InfernalConfig.load(marker.m_128469_("infernal"));
            if (inf.isEnabled()) {
                final String mods = inf.resolveModifierString(living.m_217043_());
                if (!mods.isBlank()) {
                    InfernalMobsIntegration.applyModifiers(living, mods);
                }
            }
        }
        final CompoundTag slim = new CompoundTag();
        boolean keepMarker = false;
        if (marker.m_128441_("drops")) {
            slim.m_128365_("drops", marker.m_128423_("drops"));
            keepMarker = true;
        }
        if (marker.m_128441_("keepVanillaDrops")) {
            slim.m_128379_("keepVanillaDrops", marker.m_128471_("keepVanillaDrops"));
        }
        if (keepMarker) {
            forgeData.m_128365_("fspawner", (Tag)slim);
        }
        else {
            forgeData.m_128473_("fspawner");
        }
    }
    
    private static void handleAppearChances(final LivingEntity living, final CompoundTag marker) {
        if (!marker.m_128441_("appearChances")) {
            return;
        }
        final CompoundTag appear = marker.m_128469_("appearChances");
        final RandomSource random = living.m_217043_();
        for (final String slotName : appear.m_128431_()) {
            final float chance = appear.m_128457_(slotName);
            if (random.m_188501_() > chance) {
                final EquipmentSlot slot = EquipmentEntry.slotByName(slotName);
                living.m_8061_(slot, ItemStack.f_41583_);
            }
        }
    }
    
    @SubscribeEvent
    public static void onLivingDrops(final LivingDropsEvent event) {
        final LivingEntity entity = event.getEntity();
        if (entity.m_9236_().m_5776_()) {
            return;
        }
        final CompoundTag forgeData = entity.getPersistentData();
        if (!forgeData.m_128441_("fspawner")) {
            return;
        }
        final CompoundTag marker = forgeData.m_128469_("fspawner");
        final boolean keepVanilla = !marker.m_128441_("keepVanillaDrops") || marker.m_128471_("keepVanillaDrops");
        if (!keepVanilla) {
            event.getDrops().clear();
        }
        if (!marker.m_128441_("drops")) {
            return;
        }
        final ListTag list = marker.m_128437_("drops", 10);
        final RandomSource random = entity.m_217043_();
        final Level level = entity.m_9236_();
        for (int i = 0; i < list.size(); ++i) {
            final DropEntry drop = DropEntry.load(list.m_128728_(i));
            if (!drop.item.m_41619_()) {
                if (random.m_188501_() <= drop.chance) {
                    final int min = Math.max(0, Math.min(drop.min, drop.max));
                    final int max = Math.max(drop.min, drop.max);
                    final int count = min + ((max > min) ? random.m_188503_(max - min + 1) : 0);
                    if (count > 0) {
                        spawnDrop(event, level, entity, drop.item, count);
                    }
                }
            }
        }
    }
    
    private static void spawnDrop(final LivingDropsEvent event, final Level level, final LivingEntity entity, final ItemStack template, final int count) {
        final int maxStack = template.m_41741_();
        int remaining = count;
        while (remaining > 0) {
            final int take = Math.min(remaining, maxStack);
            remaining -= take;
            final ItemStack stack = template.m_41777_();
            stack.m_41764_(take);
            final ItemEntity itemEntity = new ItemEntity(level, entity.m_20185_(), entity.m_20186_() + 0.5, entity.m_20189_(), stack);
            itemEntity.m_32060_();
            event.getDrops().add(itemEntity);
        }
    }
}
