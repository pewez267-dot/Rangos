package com.fspawner.event;

import com.fspawner.config.DropEntry;
import com.fspawner.config.EquipmentEntry;
import com.fspawner.config.InfernalConfig;
import com.fspawner.config.SpawnerConfig;
import com.fspawner.integration.InfernalMobsIntegration;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.MobSpawnEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public final class FSpawnerEvents {

    private FSpawnerEvents() {}

    /** Cancela un spawn de spawner si las reglas extra de FSpawner no se cumplen. */
    @SubscribeEvent
    public static void onCheckSpawn(MobSpawnEvent.FinalizeSpawn event) {
        if (event.getSpawnType() != MobSpawnType.SPAWNER) return;
        Entity entity = event.getEntity();
        if (entity == null) return;
        CompoundTag forgeData = entity.getPersistentData();
        if (!forgeData.contains("fspawner")) return;
        CompoundTag marker = forgeData.getCompound("fspawner");
        if (!marker.contains("cfg")) return;
        SpawnerConfig cfg = SpawnerConfig.load(marker.getCompound("cfg"));

        LevelAccessor level = event.getLevel();
        BlockPos pos = BlockPos.containing(event.getX(), event.getY(), event.getZ());

        if (!matchesDayCycle(level, cfg)
            || !matchesWeather(level, cfg)
            || !matchesSky(level, pos, cfg)
            || !matchesLight(level, pos, cfg)) {
            event.setSpawnCancelled(true);
        }
    }

    private static boolean matchesDayCycle(LevelAccessor level, SpawnerConfig cfg) {
        if (cfg.dayCycle == SpawnerConfig.DayCycle.ANY) return true;
        if (!(level instanceof Level lvl)) return true;
        long time = lvl.getDayTime() % 24000L;
        boolean isDay = time < 13000L || time > 23000L; // aprox. amanecer-anochecer
        return cfg.dayCycle == SpawnerConfig.DayCycle.DAY_ONLY ? isDay : !isDay;
    }

    private static boolean matchesWeather(LevelAccessor level, SpawnerConfig cfg) {
        if (cfg.weather == SpawnerConfig.Weather.ANY) return true;
        if (!(level instanceof Level lvl)) return true;
        boolean thunder = lvl.isThundering();
        boolean rain = lvl.isRaining();
        return switch (cfg.weather) {
            case CLEAR -> !rain && !thunder;
            case RAIN -> rain && !thunder;
            case THUNDER -> thunder;
            default -> true;
        };
    }

    private static boolean matchesSky(LevelAccessor level, BlockPos pos, SpawnerConfig cfg) {
        if (!cfg.requiresSky && !cfg.requiresNoSky) return true;
        boolean canSee = level.canSeeSky(pos);
        if (cfg.requiresSky && !canSee) return false;
        if (cfg.requiresNoSky && canSee) return false;
        return true;
    }

    private static boolean matchesLight(LevelAccessor level, BlockPos pos, SpawnerConfig cfg) {
        if (cfg.minLight <= 0 && cfg.maxLight >= 15) return true;
        int light = level.getBrightness(net.minecraft.world.level.LightLayer.BLOCK, pos);
        return light >= cfg.minLight && light <= cfg.maxLight;
    }

    @SubscribeEvent
    public static void onEntityJoin(EntityJoinLevelEvent event) {
        Level level = event.getLevel();
        if (level.isClientSide()) return;
        Entity entity = event.getEntity();
        if (!(entity instanceof LivingEntity living)) return;
        CompoundTag forgeData = entity.getPersistentData();
        if (!forgeData.contains("fspawner")) return;
        CompoundTag marker = forgeData.getCompound("fspawner");

        handleAppearChances(living, marker);

        if (marker.contains("infernal")) {
            InfernalConfig inf = InfernalConfig.load(marker.getCompound("infernal"));
            if (inf.isEnabled()) {
                String mods = inf.resolveModifierString(living.getRandom());
                if (!mods.isBlank()) {
                    InfernalMobsIntegration.applyModifiers(living, mods);
                }
            }
        }

        // Compactar marker: dejar sólo lo necesario para el evento de drops.
        CompoundTag slim = new CompoundTag();
        boolean keepMarker = false;
        if (marker.contains("drops")) {
            slim.put("drops", marker.get("drops"));
            keepMarker = true;
        }
        if (marker.contains("keepVanillaDrops")) {
            slim.putBoolean("keepVanillaDrops", marker.getBoolean("keepVanillaDrops"));
            keepMarker = true;
        }
        if (keepMarker) forgeData.put("fspawner", slim);
        else forgeData.remove("fspawner");
    }

    private static void handleAppearChances(LivingEntity living, CompoundTag marker) {
        if (!marker.contains("appearChances")) return;
        CompoundTag appear = marker.getCompound("appearChances");
        RandomSource random = living.getRandom();
        for (String slotName : appear.getAllKeys()) {
            float chance = appear.getFloat(slotName);
            if (random.nextFloat() > chance) {
                EquipmentSlot slot = EquipmentEntry.slotByName(slotName);
                living.setItemSlot(slot, ItemStack.EMPTY);
            }
        }
    }

    @SubscribeEvent
    public static void onLivingDrops(LivingDropsEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.level().isClientSide()) return;
        CompoundTag forgeData = entity.getPersistentData();
        if (!forgeData.contains("fspawner")) return;
        CompoundTag marker = forgeData.getCompound("fspawner");

        boolean keepVanilla = !marker.contains("keepVanillaDrops") || marker.getBoolean("keepVanillaDrops");
        if (!keepVanilla) event.getDrops().clear();

        if (!marker.contains("drops")) return;
        ListTag list = marker.getList("drops", 10);
        RandomSource random = entity.getRandom();
        Level level = entity.level();
        for (int i = 0; i < list.size(); i++) {
            DropEntry drop = DropEntry.load(list.getCompound(i));
            if (drop.item.isEmpty()) continue;
            if (random.nextFloat() > drop.chance) continue;
            int min = Math.max(0, Math.min(drop.min, drop.max));
            int max = Math.max(drop.min, drop.max);
            int count = min + (max > min ? random.nextInt(max - min + 1) : 0);
            if (count > 0) spawnDrop(event, level, entity, drop.item, count);
        }
    }

    private static void spawnDrop(LivingDropsEvent event, Level level, LivingEntity entity, ItemStack template, int count) {
        int maxStack = template.getMaxStackSize();
        int remaining = count;
        while (remaining > 0) {
            int take = Math.min(remaining, maxStack);
            remaining -= take;
            ItemStack stack = template.copy();
            stack.setCount(take);
            ItemEntity itemEntity = new ItemEntity(level, entity.getX(), entity.getY() + 0.5, entity.getZ(), stack);
            itemEntity.setDefaultPickUpDelay();
            event.getDrops().add(itemEntity);
        }
    }
}
