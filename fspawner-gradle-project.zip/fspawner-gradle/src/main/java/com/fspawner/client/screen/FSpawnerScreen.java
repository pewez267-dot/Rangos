// 
// Decompiled by Procyon v0.6.0
// 

package com.fspawner.client.screen;

import com.fspawner.network.FSNetwork;
import com.fspawner.network.SaveConfigPacket;
import net.minecraft.client.gui.GuiGraphics;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;
import com.fspawner.integration.InfernalMobsIntegration;
import com.fspawner.integration.InfernalModifiers;
import com.fspawner.config.InfernalConfig;
import net.minecraft.world.effect.MobEffect;
import com.fspawner.config.EquipmentEntry;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.ItemLike;
import java.util.Iterator;
import com.fspawner.util.FSAttributes;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.registries.ForgeRegistries;
import java.util.Collection;
import java.util.function.Consumer;
import java.util.Objects;
import net.minecraft.world.item.ItemStack;
import java.util.function.Function;
import com.fspawner.client.widget.ScrollSelector;
import net.minecraft.world.entity.EntityType;
import com.fspawner.util.RegistryLists;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.components.Button;
import java.util.ArrayList;
import net.minecraft.network.chat.Component;
import com.fspawner.config.EntityEntry;
import com.fspawner.config.DropEntry;
import com.fspawner.config.EffectEntry;
import net.minecraft.world.entity.EquipmentSlot;
import java.util.List;
import com.fspawner.config.SpawnerConfig;
import net.minecraft.client.gui.screens.Screen;

public class FSpawnerScreen extends Screen
{
    private static final String[] NAME_COLORS;
    private final SpawnerConfig config;
    private Tab activeTab;
    private final List<Label> labels;
    private final List<TooltipZone> tooltipZones;
    private int leftPos;
    private int topPos;
    private int panelWidth;
    private int panelHeight;
    private EquipmentSlot selectedSlot;
    private EffectEntry selectedEffect;
    private DropEntry selectedDrop;
    private EntityEntry selectedEntity;
    
    private static String colorEs(final String c) {
        return switch (c) {
            case "white" -> "Blanco";
            case "yellow" -> "Amarillo";
            case "gold" -> "Dorado";
            case "red" -> "Rojo";
            case "aqua" -> "Cian";
            case "green" -> "Verde";
            case "light_purple" -> "Rosa";
            case "blue" -> "Azul";
            case "dark_purple" -> "Morado";
            case "gray" -> "Gris";
            default -> c;
        };
    }
    
    public FSpawnerScreen(final SpawnerConfig config) {
        super((Component)Component.m_237115_("fspawner.title"));
        this.activeTab = Tab.ENTITIES;
        this.labels = new ArrayList<Label>();
        this.tooltipZones = new ArrayList<TooltipZone>();
        this.selectedSlot = EquipmentSlot.MAINHAND;
        this.config = ((config == null) ? new SpawnerConfig() : config);
    }
    
    protected void m_7856_() {
        this.panelWidth = Math.min(this.f_96543_ - 20, 460);
        this.panelHeight = Math.min(this.f_96544_ - 20, 272);
        this.leftPos = (this.f_96543_ - this.panelWidth) / 2;
        this.topPos = (this.f_96544_ - this.panelHeight) / 2;
        this.labels.clear();
        this.tooltipZones.clear();
        this.initHeader();
        this.initFooter();
        switch (this.activeTab) {
            case ENTITIES: {
                this.initEntities();
                break;
            }
            case SPAWN: {
                this.initSpawn();
                break;
            }
            case ATTRIBUTES: {
                this.initAttributes();
                break;
            }
            case EQUIPMENT: {
                this.initEquipment();
                break;
            }
            case EFFECTS: {
                this.initEffects();
                break;
            }
            case INFERNAL: {
                this.initInfernal();
                break;
            }
            case DROPS: {
                this.initDrops();
                break;
            }
            case APPEARANCE: {
                this.initAppearance();
                break;
            }
        }
    }
    
    private int bodyX() {
        return this.leftPos + 8;
    }
    
    private int bodyY() {
        return this.topPos + 58;
    }
    
    private int bodyW() {
        return this.panelWidth - 16;
    }
    
    private int bodyH() {
        return this.panelHeight - 58 - 28;
    }
    
    private void initHeader() {
        final Tab[] tabs = Tab.values();
        final int gap = 2;
        final int tabW = (this.panelWidth - 16 - gap * (tabs.length - 1)) / tabs.length;
        int x = this.leftPos + 8;
        final int y = this.topPos + 24;
        final Tab[] array = tabs;
        for (int length = array.length, i = 0; i < length; ++i) {
            final Tab tab = array[i];
            final boolean active = tab == this.activeTab;
            final String text = (active ? "§f" : "§7") + tab.label;
            final Button b = Button.m_253074_((Component)Component.m_237113_(text), btn -> {
                this.activeTab = tab;
                this.m_232761_();
            }).m_252987_(x, y, tabW, 18).m_253136_();
            this.m_142416_((GuiEventListener)b);
            x += tabW + gap;
        }
    }
    
    private void initFooter() {
        final int w = 150;
        final Button save = Button.m_253074_((Component)Component.m_237115_("fspawner.button.save"), b -> {
            FSNetwork.sendToServer(new SaveConfigPacket(this.config.save()));
            this.m_7379_();
        }).m_252987_(this.leftPos + this.panelWidth - w - 8, this.topPos + this.panelHeight - 24, w, 18).m_253136_();
        this.m_142416_((GuiEventListener)save);
        final Button close = Button.m_253074_((Component)Component.m_237113_("Cerrar"), b -> this.m_7379_()).m_252987_(this.leftPos + 8, this.topPos + this.panelHeight - 24, 80, 18).m_253136_();
        this.m_142416_((GuiEventListener)close);
    }
    
    private void initEntities() {
        final int colW = (this.bodyW() - 8) / 2;
        final int listX = this.bodyX();
        final int rightX = this.bodyX() + colW + 8;
        final int searchY = this.bodyY();
        final int listY = searchY + 20;
        final int listH = this.bodyH() - 22;
        this.m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237113_("Modo: " + ((this.config.entityMode == SpawnerConfig.EntityMode.FIXED) ? "Fijo" : "Pool")), b -> {
            this.config.entityMode = ((this.config.entityMode == SpawnerConfig.EntityMode.FIXED) ? SpawnerConfig.EntityMode.POOL : SpawnerConfig.EntityMode.FIXED);
            this.m_232761_();
        }).m_252987_(rightX, searchY, colW, 16).m_253136_());
        final EditBox search = new EditBox(this.f_96547_, listX, searchY, colW, 16, (Component)Component.m_237119_());
        search.m_257771_((Component)Component.m_237115_("fspawner.search"));
        this.m_142416_((GuiEventListener)search);
        final ScrollSelector<EntityType<?>> list = new ScrollSelector<EntityType<?>>(listX, listY, colW, listH, 12, RegistryLists::entityName, t -> RegistryLists.entityName((EntityType<?>)t) + " " + RegistryLists.entityId((EntityType<?>)t), (Function<EntityType<?>, ItemStack>)null);
        list.setItems(RegistryLists.entities());
        list.onSelect(t -> {
            final String id = RegistryLists.entityId((EntityType<?>)t);
            if (this.config.entityMode == SpawnerConfig.EntityMode.FIXED) {
                this.config.entities.clear();
                this.config.entities.add(new EntityEntry(id));
            }
            else if (this.config.entities.stream().noneMatch(e -> e.id.equals(id))) {
                this.config.entities.add(new EntityEntry(id));
            }
            this.m_232761_();
            return;
        });
        final EditBox editBox = search;
        final ScrollSelector<EntityType<?>> obj = list;
        Objects.requireNonNull(obj);
        editBox.m_94151_((Consumer)obj::setQuery);
        this.m_142416_((GuiEventListener)list);
        final ScrollSelector<EntityEntry> selected = new ScrollSelector<EntityEntry>(rightX, listY, colW, listH - 22, 12, e -> RegistryLists.entityName(this.typeOf(e.id)) + " (x" + e.weight, e -> e.id, (Function<EntityEntry, ItemStack>)null);
        selected.setItems(new ArrayList<EntityEntry>(this.config.entities));
        selected.onSelect(e -> this.selectedEntity = e);
        this.m_142416_((GuiEventListener)selected);
        this.m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237113_("Quitar"), b -> {
            if (this.selectedEntity != null) {
                this.config.entities.remove(this.selectedEntity);
                this.selectedEntity = null;
                this.m_232761_();
            }
        }).m_252987_(rightX, listY + listH - 18, colW, 16).m_253136_());
        this.labels.add(new Label("Selecciona entidades (cualquier mod):", listX, this.bodyY() - 10, 10526880));
    }
    
    private EntityType<?> typeOf(final String id) {
        final EntityType<?> t = (EntityType<?>)ForgeRegistries.ENTITY_TYPES.getValue(ResourceLocation.m_135820_(id));
        return (EntityType<?>)((t == null) ? EntityType.f_20510_ : t);
    }
    
    private void initSpawn() {
        final int x = this.bodyX();
        final int y = this.bodyY();
        final int fw = 60;
        final int colGap = 215;
        this.addSecondsField(x + colGap, y, fw, this.config.spawnDelayMin, v -> this.config.spawnDelayMin = v, "Tiempo m\u00ednimo (seg)", x, y, desc("Tiempo m\u00ednimo entre apariciones, en segundos.", "El spawner espera un tiempo aleatorio entre el m\u00ednimo y el m\u00e1ximo.", "Recomendado: 10 segundos."));
        this.addSecondsField(x + colGap, y + 20, fw, this.config.spawnDelayMax, v -> this.config.spawnDelayMax = v, "Tiempo m\u00e1ximo (seg)", x, y + 20, desc("Tiempo m\u00e1ximo entre apariciones, en segundos.", "Debe ser mayor o igual que el tiempo m\u00ednimo.", "Recomendado: 40 segundos."));
        this.addIntField(x + colGap, y + 40, fw, this.config.spawnCount, v -> this.config.spawnCount = v, "Cantidad por oleada", x, y + 40, desc("Cu\u00e1ntas entidades intenta generar cada vez.", "Recomendado: 4. Valores altos pueden causar lag."));
        this.addIntField(x + colGap, y + 60, fw, this.config.spawnRange, v -> this.config.spawnRange = v, "Radio de aparici\u00f3n (bloques)", x, y + 60, desc("Distancia en bloques alrededor del spawner donde aparecen.", "Recomendado: 4 bloques."));
        this.addIntField(x + colGap, y + 80, fw, this.config.activationRange, v -> this.config.activationRange = v, "Distancia de activaci\u00f3n (bloques)", x, y + 80, desc("El spawner solo funciona si hay un jugador a esta", "distancia o menos, en bloques.", "Recomendado: 16 bloques."));
        this.addIntField(x + colGap, y + 100, fw, this.config.maxNearbyEntities, v -> this.config.maxNearbyEntities = v, "M\u00e1ximo de entidades cercanas", x, y + 100, desc("L\u00edmite de entidades de este tipo cerca del spawner.", "Si ya hay esta cantidad, deja de generar hasta que bajen.", "Recomendado: 6."));
        final int ty = y + 124;
        this.addToggle(x, ty, 130, "Oleadas", this.config.waves, () -> {
            this.config.waves = !this.config.waves;
            this.m_232761_();
            return;
        }, desc("Activa generaci\u00f3n por oleadas (experimental)."));
        this.addToggle(x + 140, ty, 130, "Modo Jefe", this.config.bossMode, () -> {
            this.config.bossMode = !this.config.bossMode;
            this.m_232761_();
            return;
        }, desc("Genera una sola entidad fuerte, brillante y persistente.", "Ideal para jefes. Fuerza cantidad y cercan\u00eda a 1."));
        this.addToggle(x, ty + 20, 130, "Aparici\u00f3n continua", this.config.continuous, () -> {
            this.config.continuous = !this.config.continuous;
            this.m_232761_();
        }, desc("Si est\u00e1 activo, el spawner sigue generando sin parar."));
    }
    
    private void initAttributes() {
        final int x = this.bodyX();
        final int y = this.bodyY();
        int row = 0;
        for (FSAttributes.Attr attr : FSAttributes.ALL) {
            final int fy = y + row * 22;
            final Double current = this.config.attributes.get(attr.id);
            final String val = (current == null) ? "" : trim(current);
            final EditBox box = new EditBox(this.f_96547_, x + 180, fy, 70, 16, (Component)Component.m_237119_());
            box.m_94144_(val);
            box.m_94199_(16);
            box.m_257771_((Component)Component.m_237113_(trim(attr.defaultValue)));
            box.m_94151_(s -> {
                final String t = s.trim();
                if (t.isEmpty()) {
                    this.config.attributes.remove(attr.id);
                    return;
                }
                else {
                    try {
                        this.config.attributes.put(attr.id, Double.parseDouble(t));
                    }
                    catch (final NumberFormatException ex) {}
                    return;
                }
            });
            this.m_142416_((GuiEventListener)box);
            this.labels.add(new Label(attr.label, x, fy + 4, 14737632));
            this.addTooltip(x, fy + 2, 170, 14, desc("Atributo: " + attr.label, "Valor por defecto del mob: " + trim(attr.defaultValue), "Deja vac\u00edo para no modificarlo."));
            ++row;
        }
        this.labels.add(new Label("Deja vac\u00edo para usar el valor por defecto.", x, y + row * 22 + 4, 8421504));
    }
    
    private void initEquipment() {
        final int x = this.bodyX();
        final int y = this.bodyY();
        final int colW = (this.bodyW() - 8) / 2;
        final EquipmentSlot[] slots = { EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND, EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET };
        final String[] names = { "Mano", "2da Mano", "Casco", "Pechera", "Pantal\u00f3n", "Botas" };
        final int bw = colW / 3 - 2;
        for (int i = 0; i < slots.length; ++i) {
            final EquipmentSlot s = slots[i];
            final boolean active = s == this.selectedSlot;
            final int bx = x + i % 3 * (bw + 3);
            final int by = y + i / 3 * 18;
            this.m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237113_((active ? "§e" : "") + names[i]), b -> {
                this.selectedSlot = s;
                this.m_232761_();
            }).m_252987_(bx, by, bw, 16).m_253136_());
        }
        final EquipmentEntry entry = this.getOrCreateEquipment(this.selectedSlot);
        final int fy = y + 40;
        this.labels.add(new Label("Item: " + (entry.item.m_41619_() ? "§7(vac\u00edo)" : entry.item.m_41786_().getString()), x, fy + 4, 16777215));
        this.m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237113_("Limpiar slot"), b -> {
            entry.item = ItemStack.f_41583_;
            this.m_232761_();
        }).m_252987_(x + colW - 90, fy, 90, 16).m_253136_());
        this.addPercentField(x + 150, fy + 22, 60, entry.dropChance, v -> entry.dropChance = (float)v, "Prob. de Drop (%)", x, fy + 22 + 4);
        this.addPercentField(x + 150, fy + 44, 60, entry.appearChance, v -> entry.appearChance = (float)v, "Prob. de Aparici\u00f3n (%)", x, fy + 44 + 4);
        final int rightX = x + colW + 8;
        final EditBox search = new EditBox(this.f_96547_, rightX, y, colW, 16, (Component)Component.m_237119_());
        search.m_257771_((Component)Component.m_237115_("fspawner.search"));
        this.m_142416_((GuiEventListener)search);
        final ScrollSelector<Item> list = new ScrollSelector<Item>(rightX, y + 20, colW, this.bodyH() - 22, 18, RegistryLists::itemName, it -> RegistryLists.itemName(it) + " " + RegistryLists.itemId(it), it -> new ItemStack((ItemLike)it));
        list.setItems(RegistryLists.items());
        list.onSelect(it -> {
            final ItemStack stack = new ItemStack((ItemLike)it);
            entry.item = stack;
            this.m_232761_();
            return;
        });
        final EditBox editBox = search;
        final ScrollSelector<Item> obj = list;
        Objects.requireNonNull(obj);
        editBox.m_94151_((Consumer)obj::setQuery);
        this.m_142416_((GuiEventListener)list);
    }
    
    private EquipmentEntry getOrCreateEquipment(final EquipmentSlot slot) {
        EquipmentEntry e = this.config.equipmentFor(slot);
        if (e == null) {
            e = new EquipmentEntry(slot);
            e.item = ItemStack.f_41583_;
            this.config.equipment.add(e);
        }
        return e;
    }
    
    private void initEffects() {
        final int x = this.bodyX();
        final int y = this.bodyY();
        final int colW = (this.bodyW() - 8) / 2;
        final int rightX = x + colW + 8;
        final EditBox search = new EditBox(this.f_96547_, x, y, colW, 16, (Component)Component.m_237119_());
        search.m_257771_((Component)Component.m_237115_("fspawner.search"));
        this.m_142416_((GuiEventListener)search);
        final ScrollSelector<MobEffect> all = new ScrollSelector<MobEffect>(x, y + 20, colW, this.bodyH() - 22, 12, RegistryLists::effectName, e -> RegistryLists.effectName(e) + " " + RegistryLists.effectId(e), (Function<MobEffect, ItemStack>)null);
        all.setItems(RegistryLists.effects());
        EffectEntry fx = null;
        all.onSelect(e -> {
            final String id = RegistryLists.effectId(e);
            if (this.config.effects.stream().noneMatch(fx -> fx.id.equals(id))) {
                this.config.effects.add(new EffectEntry(id));
            }
            this.m_232761_();
            return;
        });
        final EditBox editBox = search;
        final ScrollSelector<MobEffect> obj = all;
        Objects.requireNonNull(obj);
        editBox.m_94151_((Consumer)obj::setQuery);
        this.m_142416_((GuiEventListener)all);
        final ScrollSelector<EffectEntry> current = new ScrollSelector<EffectEntry>(rightX, y, colW, this.bodyH() - 70, 12, fx -> this.effectLabel(fx), fx -> fx.id, (Function<EffectEntry, ItemStack>)null);
        current.setItems(new ArrayList<EffectEntry>(this.config.effects));
        current.onSelect(fx -> {
            this.selectedEffect = fx;
            this.m_232761_();
            return;
        });
        this.m_142416_((GuiEventListener)current);
        if (this.selectedEffect != null && this.config.effects.contains(this.selectedEffect)) {
            fx = this.selectedEffect;
            final int fy = y + this.bodyH() - 66;
            this.addIntField(rightX + 70, fy, 40, fx.amplifier + 1, v -> fx.amplifier = Math.max(0, v - 1), "Nivel", rightX, fy + 4);
            this.addIntField(rightX + 70, fy + 18, 60, fx.duration, v -> fx.duration = Math.max(1, v), "Duraci\u00f3n", rightX, fy + 18 + 4);
            this.addToggle(rightX + 140, fy, colW - 140, fx.permanent ? "Permanente" : "Temporal", fx.permanent, () -> {
                fx.permanent = !fx.permanent;
                this.m_232761_();
                return;
            });
            this.m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237113_("Quitar efecto"), b -> {
                this.config.effects.remove(fx);
                this.selectedEffect = null;
                this.m_232761_();
            }).m_252987_(rightX + 140, fy + 18, colW - 140, 16).m_253136_());
        }
    }
    
    private String effectLabel(final EffectEntry fx) {
        final MobEffect effect = (MobEffect)ForgeRegistries.MOB_EFFECTS.getValue(ResourceLocation.m_135820_(fx.id));
        final String name = (effect != null) ? effect.m_19482_().getString() : fx.id;
        return name + " " + (fx.amplifier + 1) + (fx.permanent ? " §b\u221e" : "");
    }
    
    private void initInfernal() {
        final int x = this.bodyX();
        final int y = this.bodyY();
        final int colW = (this.bodyW() - 8) / 2;
        final int rightX = x + colW + 8;
        this.m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237113_("Modo: " + this.infernalModeLabel(this.config.infernal.mode)), b -> {
            final InfernalConfig.Mode[] modes = InfernalConfig.Mode.values();
            this.config.infernal.mode = modes[(this.config.infernal.mode.ordinal() + 1) % modes.length];
            this.m_232761_();
        }).m_252987_(x, y, colW, 16).m_253136_());
        this.addIntField(x + 90, y + 22, 50, this.config.infernal.min, v -> this.config.infernal.min = Math.max(0, v), "M\u00ednimo", x, y + 22 + 4);
        this.addIntField(x + 90, y + 42, 50, this.config.infernal.max, v -> this.config.infernal.max = Math.max(0, v), "M\u00e1ximo", x, y + 42 + 4);
        final boolean usePool = this.config.infernal.mode == InfernalConfig.Mode.RANDOM;
        this.labels.add(new Label(usePool ? "Pool permitido (aleatorio):" : "Modificadores fijos:", rightX, y - 10, 10526880));
        final List<String> mods = new ArrayList<String>(InfernalModifiers.FRIENDLY.keySet());
        final ScrollSelector<String> list = new ScrollSelector<String>(rightX, y, colW, this.bodyH(), 12, InfernalModifiers::friendly, m -> InfernalModifiers.friendly(m) + " " + m, (Function<String, ItemStack>)null);
        list.withCheckbox(m -> this.targetModList().contains(m));
        list.setItems(mods);
        list.onSelect(m -> {
            final List<String> target = this.targetModList();
            if (target.contains(m)) {
                target.remove(m);
            }
            else {
                target.add(m);
            }
            return;
        });
        this.m_142416_((GuiEventListener)list);
        this.labels.add(new Label("Infernal Mobs " + (InfernalMobsIntegration.isLoaded() ? "§adetectado" : "§cno instalado"), x, y + 70, 16777215));
    }
    
    private List<String> targetModList() {
        return (this.config.infernal.mode == InfernalConfig.Mode.RANDOM) ? this.config.infernal.pool : this.config.infernal.mods;
    }
    
    private String infernalModeLabel(final InfernalConfig.Mode mode) {
        return switch (mode) {
            default -> throw new IncompatibleClassChangeError();
            case DISABLED -> "Desactivado";
            case ALWAYS -> "Siempre Infernal";
            case RANDOM -> "Aleatorio";
            case CUSTOM -> "Personalizado";
        };
    }
    
    private void initDrops() {
        final int x = this.bodyX();
        final int y = this.bodyY();
        final int colW = (this.bodyW() - 8) / 2;
        final int rightX = x + colW + 8;
        final EditBox search = new EditBox(this.f_96547_, x, y, colW, 16, (Component)Component.m_237119_());
        search.m_257771_((Component)Component.m_237115_("fspawner.search"));
        this.m_142416_((GuiEventListener)search);
        final ScrollSelector<Item> all = new ScrollSelector<Item>(x, y + 20, colW, this.bodyH() - 22, 18, RegistryLists::itemName, it -> RegistryLists.itemName(it) + " " + RegistryLists.itemId(it), it -> new ItemStack((ItemLike)it));
        all.setItems(RegistryLists.items());
        all.onSelect(it -> {
            final List<DropEntry> drops = this.config.drops;
            new DropEntry(new ItemStack((ItemLike)it), 1, 1, 1.0f);
            final DropEntry dropEntry;
            drops.add(dropEntry);
            this.m_232761_();
            return;
        });
        final EditBox editBox = search;
        final ScrollSelector<Item> obj = all;
        Objects.requireNonNull(obj);
        editBox.m_94151_((Consumer)obj::setQuery);
        this.m_142416_((GuiEventListener)all);
        DropEntry d = null;
        final ScrollSelector<DropEntry> current = new ScrollSelector<DropEntry>(rightX, y, colW, this.bodyH() - 92, 18, d -> this.dropLabel(d), d -> d.item.m_41786_().getString(), d -> d.item);
        current.setItems(new ArrayList<DropEntry>(this.config.drops));
        current.onSelect(d -> {
            this.selectedDrop = d;
            this.m_232761_();
            return;
        });
        this.m_142416_((GuiEventListener)current);
        this.addToggle(rightX, y + this.bodyH() - 18, colW, this.config.keepVanillaDrops ? "Mantener Drops Vanilla" : "Reemplazar Drops Vanilla", this.config.keepVanillaDrops, () -> {
            this.config.keepVanillaDrops = !this.config.keepVanillaDrops;
            this.m_232761_();
            return;
        });
        if (this.selectedDrop != null && this.config.drops.contains(this.selectedDrop)) {
            d = this.selectedDrop;
            final int fy = y + this.bodyH() - 90;
            this.addIntField(rightX + 48, fy, 36, d.min, v -> d.min = Math.max(0, v), "Cant. m\u00edn", rightX, fy + 4, desc("Cantidad m\u00ednima del objeto que suelta."));
            this.addIntField(rightX + 145, fy, 36, d.max, v -> d.max = Math.max(0, v), "Max", rightX + 110, fy + 4, desc("Cantidad m\u00e1xima del objeto que suelta."));
            this.addPercentField(rightX + 110, fy + 22, 45, d.chance, v -> d.chance = (float)v, "Probabilidad (%)", rightX, fy + 22 + 4, desc("Probabilidad de que suelte este objeto, en porcentaje.", "100 = siempre. 25 = una de cada cuatro veces."));
            this.m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237113_("Quitar"), b -> {
                this.config.drops.remove(d);
                this.selectedDrop = null;
                this.m_232761_();
            }).m_252987_(rightX, fy + 44, colW, 16).m_253136_());
        }
    }
    
    private String dropLabel(final DropEntry d) {
        final int pct = Math.round(d.chance * 100.0f);
        return d.item.m_41786_().getString() + " §7" + d.min + "-" + d.max + " (" + pct + "%)";
    }
    
    private void initAppearance() {
        final int x = this.bodyX();
        final int y = this.bodyY();
        final int fw = this.bodyW() - 170;
        final EditBox itemName = new EditBox(this.f_96547_, x + 160, y, Math.max(120, fw), 16, (Component)Component.m_237119_());
        itemName.m_94199_(128);
        itemName.m_94144_(this.config.itemName);
        itemName.m_94151_(s -> this.config.itemName = s);
        this.m_142416_((GuiEventListener)itemName);
        this.labels.add(new Label("Nombre del Item:", x, y + 4, 14737632));
        final EditBox mobName = new EditBox(this.f_96547_, x + 160, y + 22, Math.max(120, fw), 16, (Component)Component.m_237119_());
        mobName.m_94199_(128);
        mobName.m_94144_(this.config.mobName);
        mobName.m_94151_(s -> this.config.mobName = s);
        this.m_142416_((GuiEventListener)mobName);
        this.labels.add(new Label("Nombre Visible (mob):", x, y + 26, 14737632));
        this.m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237113_("Color: " + colorEs(this.config.nameColor)), b -> {
            int idx = 0;
            for (int i = 0; i < FSpawnerScreen.NAME_COLORS.length; ++i) {
                if (FSpawnerScreen.NAME_COLORS[i].equals(this.config.nameColor)) {
                    idx = i;
                    break;
                }
            }
            this.config.nameColor = FSpawnerScreen.NAME_COLORS[(idx + 1) % FSpawnerScreen.NAME_COLORS.length];
            this.m_232761_();
        }).m_252987_(x + 160, y + 44, 150, 16).m_253136_());
        this.labels.add(new Label("Color del Nombre:", x, y + 48, 14737632));
        this.addToggle(x, y + 70, 200, this.config.mobNameVisible ? "Nombre Siempre Visible" : "Nombre Oculto", this.config.mobNameVisible, () -> {
            this.config.mobNameVisible = !this.config.mobNameVisible;
            this.m_232761_();
            return;
        }, desc("Si est\u00e1 activo, el nombre del mob se ve siempre", "sobre su cabeza, aunque no lo apuntes."));
        this.addToggle(x, y + 92, 200, this.config.glowing ? "Brillo: Activado" : "Brillo: Desactivado", this.config.glowing, () -> {
            this.config.glowing = !this.config.glowing;
            this.m_232761_();
            return;
        }, desc("Hace que el mob brille y se vea a trav\u00e9s de paredes."));
        this.addToggle(x, y + 114, 200, this.config.particles ? "Part\u00edculas: Activado" : "Part\u00edculas: Desactivado", this.config.particles, () -> {
            this.config.particles = !this.config.particles;
            this.m_232761_();
        }, desc("Muestra part\u00edculas decorativas en el mob."));
    }
    
    private static List<Component> desc(final String... lines) {
        final List<Component> out = new ArrayList<Component>();
        for (final String s : lines) {
            out.add((Component)Component.m_237113_(s));
        }
        return out;
    }
    
    private void addTooltip(final int x, final int y, final int w, final int h, final List<Component> lines) {
        if (lines != null && !lines.isEmpty()) {
            this.tooltipZones.add(new TooltipZone(x, y, w, h, lines));
        }
    }
    
    private void addIntField(final int x, final int y, final int w, final int value, final IntConsumer setter, final String label, final int labelX, final int labelY) {
        this.addIntField(x, y, w, value, setter, label, labelX, labelY, null);
    }
    
    private void addIntField(final int x, final int y, final int w, final int value, final IntConsumer setter, final String label, final int labelX, final int labelY, final List<Component> tooltip) {
        final EditBox box = new EditBox(this.f_96547_, x, y, w, 16, (Component)Component.m_237119_());
        box.m_94199_(12);
        box.m_94144_(Integer.toString(value));
        box.m_94151_(s -> {
            try {
                setter.accept(Integer.parseInt(s.trim()));
            }
            catch (final NumberFormatException ex) {}
            return;
        });
        this.m_142416_((GuiEventListener)box);
        this.labels.add(new Label(label, labelX, labelY, 14737632));
        if (tooltip != null) {
            this.addTooltip(labelX, labelY - 2, x + w - labelX, 14, tooltip);
        }
    }
    
    private void addSecondsField(final int x, final int y, final int w, final int ticks, final IntConsumer setterTicks, final String label, final int labelX, final int labelY, final List<Component> tooltip) {
        final EditBox box = new EditBox(this.f_96547_, x, y, w, 16, (Component)Component.m_237119_());
        box.m_94199_(8);
        box.m_94144_(trim((double)Math.round(ticks / 20.0)));
        box.m_94151_(s -> {
            final String t = s.trim();
            if (t.isEmpty()) {
                return;
            }
            else {
                try {
                    final double seconds = Double.parseDouble(t);
                    setterTicks.accept((int)Math.round(Math.max(0.0, seconds) * 20.0));
                }
                catch (final NumberFormatException ex) {}
                return;
            }
        });
        this.m_142416_((GuiEventListener)box);
        this.labels.add(new Label(label, labelX, labelY, 14737632));
        if (tooltip != null) {
            this.addTooltip(labelX, labelY - 2, x + w - labelX, 14, tooltip);
        }
    }
    
    private void addPercentField(final int x, final int y, final int w, final float value01, final DoubleConsumer setter01, final String label, final int labelX, final int labelY) {
        this.addPercentField(x, y, w, value01, setter01, label, labelX, labelY, null);
    }
    
    private void addPercentField(final int x, final int y, final int w, final float value01, final DoubleConsumer setter01, final String label, final int labelX, final int labelY, final List<Component> tooltip) {
        final EditBox box = new EditBox(this.f_96547_, x, y, w, 16, (Component)Component.m_237119_());
        box.m_94199_(6);
        box.m_94144_(trim(Math.round(clamp01(value01) * 100.0f)));
        box.m_94151_(s -> {
            final String t = s.trim();
            if (t.isEmpty()) {
                return;
            }
            else {
                try {
                    final double pct = Double.parseDouble(t);
                    setter01.accept(clamp01(pct / 100.0));
                }
                catch (final NumberFormatException ex) {}
                return;
            }
        });
        this.m_142416_((GuiEventListener)box);
        this.labels.add(new Label(label, labelX, labelY, 14737632));
        if (tooltip != null) {
            this.addTooltip(labelX, labelY - 2, x + w - labelX, 14, tooltip);
        }
    }
    
    private void addToggle(final int x, final int y, final int w, final String text, final boolean state, final Runnable onToggle) {
        this.addToggle(x, y, w, text, state, onToggle, null);
    }
    
    private void addToggle(final int x, final int y, final int w, final String text, final boolean state, final Runnable onToggle, final List<Component> tooltip) {
        final String prefix = state ? "§a" : "§7";
        this.m_142416_((GuiEventListener)Button.m_253074_((Component)Component.m_237113_(prefix + text), b -> onToggle.run()).m_252987_(x, y, w, 16).m_253136_());
        if (tooltip != null) {
            this.addTooltip(x, y, w, 16, tooltip);
        }
    }
    
    private static float clamp01(final double v) {
        return (float)Math.max(0.0, Math.min(1.0, v));
    }
    
    private static String trim(final double value) {
        if (value == Math.floor(value) && !Double.isInfinite(value)) {
            return String.valueOf((long)value);
        }
        return String.valueOf(value);
    }
    
    public void m_88315_(final GuiGraphics g, final int mouseX, final int mouseY, final float partialTick) {
        this.m_280273_(g);
        g.m_280509_(this.leftPos, this.topPos, this.leftPos + this.panelWidth, this.topPos + this.panelHeight, -535291870);
        g.m_280509_(this.leftPos, this.topPos, this.leftPos + this.panelWidth, this.topPos + 20, -14408646);
        g.m_280509_(this.leftPos, this.topPos + this.panelHeight - 1, this.leftPos + this.panelWidth, this.topPos + this.panelHeight, -12961206);
        g.m_280509_(this.leftPos + 6, this.topPos + 45, this.leftPos + this.panelWidth - 6, this.topPos + 46, -12961206);
        g.m_280056_(this.f_96547_, "§d\u2726 §fFantastic Spawner §d\u2726", this.leftPos + 8, this.topPos + 6, 16777215, false);
        super.m_88315_(g, mouseX, mouseY, partialTick);
        for (final Label l : this.labels) {
            g.m_280056_(this.f_96547_, l.text(), l.x(), l.y(), l.color(), false);
        }
        for (final TooltipZone z : this.tooltipZones) {
            if (mouseX >= z.x() && mouseX < z.x() + z.w() && mouseY >= z.y() && mouseY < z.y() + z.h()) {
                g.m_280666_(this.f_96547_, (List)z.lines(), mouseX, mouseY);
                break;
            }
        }
    }
    
    public boolean m_7043_() {
        return false;
    }
    
    public boolean m_6913_() {
        return true;
    }
    
    static {
        NAME_COLORS = new String[] { "white", "yellow", "gold", "red", "aqua", "green", "light_purple", "blue", "dark_purple", "gray" };
    }
    
    private enum Tab
    {
        ENTITIES("Entidades"), 
        SPAWN("Spawn"), 
        ATTRIBUTES("Atributos"), 
        EQUIPMENT("Equipo"), 
        EFFECTS("Efectos"), 
        INFERNAL("Infernal"), 
        DROPS("Drops"), 
        APPEARANCE("Aspecto");
        
        final String label;
        
        private Tab(final String label) {
            this.label = label;
        }
    }
    
    record Label(String text, int x, int y, int color) {}
    
    record TooltipZone(int x, int y, int w, int h, List<Component> lines) {}
}
