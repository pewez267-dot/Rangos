package com.fspawner.client.screen;

import com.fspawner.client.widget.ScrollSelector;
import com.fspawner.config.DropEntry;
import com.fspawner.config.EffectEntry;
import com.fspawner.config.EntityEntry;
import com.fspawner.config.EquipmentEntry;
import com.fspawner.config.InfernalConfig;
import com.fspawner.config.SpawnerConfig;
import com.fspawner.integration.InfernalMobsIntegration;
import com.fspawner.integration.InfernalModifiers;
import com.fspawner.network.EditContext;
import com.fspawner.network.FSNetwork;
import com.fspawner.network.SaveConfigPacket;
import com.fspawner.util.FSAttributes;
import com.fspawner.util.RegistryLists;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;

public class FSpawnerScreen extends Screen {

    private enum Tab {
        ENTITIES("Entidades"),
        SPAWN("Aparición"),
        ATTRIBUTES("Atributos"),
        EQUIPMENT("Equipo"),
        EFFECTS("Efectos"),
        INFERNAL("Infernal"),
        DROPS("Drops"),
        APPEARANCE("Aspecto");
        final String label;
        Tab(String label) { this.label = label; }
    }

    private record Label(String text, int x, int y, int color) {}
    private record TooltipZone(int x, int y, int w, int h, List<Component> lines) {}

    private static final String[] NAME_COLORS = {
        "white", "yellow", "gold", "red", "aqua", "green",
        "light_purple", "blue", "dark_purple", "gray"
    };

    private final SpawnerConfig config;
    private final EditContext context;
    private Tab activeTab = Tab.ENTITIES;
    private final List<Label> labels = new ArrayList<>();
    private final List<TooltipZone> tooltipZones = new ArrayList<>();
    private int leftPos, topPos, panelWidth, panelHeight;
    private EquipmentSlot selectedSlot = EquipmentSlot.MAINHAND;
    private EffectEntry selectedEffect;
    private DropEntry selectedDrop;
    private EntityEntry selectedEntity;

    // Icono del item que se está editando en la pestaña Drops (cabecera "Editando:")
    private ItemStack editingIcon;
    private int editingIconX;
    private int editingIconY;

    public FSpawnerScreen(SpawnerConfig config) {
        this(config, EditContext.newSession());
    }

    public FSpawnerScreen(SpawnerConfig config, EditContext context) {
        super(Component.translatable("fspawner.title"));
        this.config = config == null ? new SpawnerConfig() : config;
        this.context = context == null ? EditContext.newSession() : context;
    }

    @Override
    protected void init() {
        this.panelWidth = Math.min(this.width - 20, 480);
        this.panelHeight = Math.min(this.height - 20, 320);
        this.leftPos = (this.width - this.panelWidth) / 2;
        this.topPos = (this.height - this.panelHeight) / 2;
        this.labels.clear();
        this.tooltipZones.clear();
        this.editingIcon = null;
        initHeader();
        initFooter();
        switch (this.activeTab) {
            case ENTITIES -> initEntities();
            case SPAWN -> initSpawn();
            case ATTRIBUTES -> initAttributes();
            case EQUIPMENT -> initEquipment();
            case EFFECTS -> initEffects();
            case INFERNAL -> initInfernal();
            case DROPS -> initDrops();
            case APPEARANCE -> initAppearance();
        }
    }

    private int bodyX() { return this.leftPos + 8; }
    private int bodyY() { return this.topPos + 58; }
    private int bodyW() { return this.panelWidth - 16; }
    private int bodyH() { return this.panelHeight - 58 - 28; }

    private void initHeader() {
        Tab[] tabs = Tab.values();
        int gap = 2;
        int tabW = (this.panelWidth - 16 - gap * (tabs.length - 1)) / tabs.length;
        int x = this.leftPos + 8;
        int y = this.topPos + 24;
        for (Tab tab : tabs) {
            boolean active = tab == this.activeTab;
            String text = (active ? "§f" : "§7") + tab.label;
            Button b = Button.builder(Component.literal(text), btn -> {
                this.activeTab = tab;
                this.rebuildWidgets();
            }).bounds(x, y, tabW, 18).build();
            this.addRenderableWidget(b);
            x += tabW + gap;
        }
    }

    private void initFooter() {
        int w = 150;
        String saveLabel = switch (this.context.source) {
            case BLOCK -> "Guardar en bloque";
            case MAIN_HAND, OFF_HAND -> "Actualizar item";
            default -> "Guardar y obtener";
        };
        Button save = Button.builder(Component.literal(saveLabel), b -> {
            FSNetwork.sendToServer(new SaveConfigPacket(this.config.save(), this.context));
            this.onClose();
        }).bounds(this.leftPos + this.panelWidth - w - 8, this.topPos + this.panelHeight - 24, w, 18).build();
        this.addRenderableWidget(save);

        Button close = Button.builder(Component.literal("Cerrar"), b -> this.onClose())
            .bounds(this.leftPos + 8, this.topPos + this.panelHeight - 24, 80, 18).build();
        this.addRenderableWidget(close);
    }

    private void initEntities() {
        int colW = (this.bodyW() - 8) / 2;
        int listX = this.bodyX();
        int rightX = this.bodyX() + colW + 8;
        int searchY = this.bodyY();
        int listY = searchY + 20;
        int listH = this.bodyH() - 22;

        this.addRenderableWidget(Button.builder(
            Component.literal("Modo: " + (this.config.entityMode == SpawnerConfig.EntityMode.FIXED ? "Fijo" : "Pool")),
            b -> {
                this.config.entityMode = this.config.entityMode == SpawnerConfig.EntityMode.FIXED
                    ? SpawnerConfig.EntityMode.POOL : SpawnerConfig.EntityMode.FIXED;
                this.rebuildWidgets();
            }).bounds(rightX, searchY, colW, 16).build());

        EditBox search = new EditBox(this.font, listX, searchY, colW, 16, Component.empty());
        search.setHint(Component.translatable("fspawner.search"));
        this.addRenderableWidget(search);

        ScrollSelector<EntityType<?>> list = new ScrollSelector<>(listX, listY, colW, listH, 12,
            RegistryLists::entityName,
            t -> RegistryLists.entityName(t) + " " + RegistryLists.entityId(t),
            null);
        list.setItems(RegistryLists.entities());
        list.onSelect(t -> {
            String id = RegistryLists.entityId(t);
            if (this.config.entityMode == SpawnerConfig.EntityMode.FIXED) {
                this.config.entities.clear();
                this.config.entities.add(new EntityEntry(id));
            } else if (this.config.entities.stream().noneMatch(e -> e.id.equals(id))) {
                this.config.entities.add(new EntityEntry(id));
            }
            this.rebuildWidgets();
        });
        search.setResponder(list::setQuery);
        this.addRenderableWidget(list);

        ScrollSelector<EntityEntry> selected = new ScrollSelector<>(rightX, listY, colW, listH - 22, 12,
            e -> RegistryLists.entityName(typeOf(e.id)) + " (x" + e.weight + ")",
            e -> e.id, null);
        selected.setItems(new ArrayList<>(this.config.entities));
        selected.onSelect(e -> this.selectedEntity = e);
        selected.setSelected(this.selectedEntity);
        this.addRenderableWidget(selected);

        this.addRenderableWidget(Button.builder(Component.literal("Quitar"), b -> {
            if (this.selectedEntity != null) {
                this.config.entities.remove(this.selectedEntity);
                this.selectedEntity = null;
                this.rebuildWidgets();
            }
        }).bounds(rightX, listY + listH - 18, colW, 16).build());

        this.labels.add(new Label("Selecciona entidades (cualquier mod):", listX, this.bodyY() - 10, 0xA0A0A0));
    }

    private EntityType<?> typeOf(String id) {
        EntityType<?> t = ForgeRegistries.ENTITY_TYPES.getValue(ResourceLocation.tryParse(id));
        return t == null ? EntityType.PIG : t;
    }

    private void initSpawn() {
        int x = this.bodyX();
        int y = this.bodyY();
        int rowH = 18;

        // ===== Columna izquierda: campos numéricos (7 filas × 18 = 126 px) =====
        int leftW = 200;
        int labelW = 130;   // label hasta x+130
        int fieldX = x + labelW;
        int fieldW = leftW - labelW - 10;

        addSecondsField(fieldX, y + 0 * rowH, fieldW, this.config.spawnDelayMin,
            v -> this.config.spawnDelayMin = v, "Tiempo mín (seg)", x, y + 0 * rowH + 4,
            desc("Tiempo mínimo entre apariciones, en segundos."));
        addSecondsField(fieldX, y + 1 * rowH, fieldW, this.config.spawnDelayMax,
            v -> this.config.spawnDelayMax = v, "Tiempo máx (seg)", x, y + 1 * rowH + 4,
            desc("Tiempo máximo entre apariciones, en segundos."));
        addIntField(fieldX, y + 2 * rowH, fieldW, this.config.spawnCount,
            v -> this.config.spawnCount = v, "Cantidad por oleada", x, y + 2 * rowH + 4,
            desc("Cuántas entidades intenta generar cada vez."));
        addIntField(fieldX, y + 3 * rowH, fieldW, this.config.spawnRange,
            v -> this.config.spawnRange = v, "Radio (bloques)", x, y + 3 * rowH + 4,
            desc("Distancia en bloques alrededor del spawner."));
        addIntField(fieldX, y + 4 * rowH, fieldW, this.config.activationRange,
            v -> this.config.activationRange = v, "Activación (bloques)", x, y + 4 * rowH + 4,
            desc("Distancia a la que un jugador activa el spawner."));
        addIntField(fieldX, y + 5 * rowH, fieldW, this.config.maxNearbyEntities,
            v -> this.config.maxNearbyEntities = v, "Máx. cercanas", x, y + 5 * rowH + 4,
            desc("Límite de entidades del mismo tipo cerca del spawner."));
        addSecondsField(fieldX, y + 6 * rowH, fieldW, this.config.extraCooldown,
            v -> this.config.extraCooldown = v, "Cooldown extra (seg)", x, y + 6 * rowH + 4,
            desc("Tiempo extra (segundos) sumado a los retardos."));

        // ===== Columna derecha: reguladores =====
        int rx = x + 210;
        int rw = this.bodyW() - 210;     // ancho total derecha
        int halfW = (rw - 6) / 2;        // dos botones por fila con gap 6
        int btnH = 16;
        int gap = 2;

        int ry = y;
        addCycle(rx, ry, rw, "Día/Noche: " + dayCycleLabel(this.config.dayCycle), () -> {
            SpawnerConfig.DayCycle[] vals = SpawnerConfig.DayCycle.values();
            this.config.dayCycle = vals[(this.config.dayCycle.ordinal() + 1) % vals.length];
            this.rebuildWidgets();
        }, desc("Cualquiera / Solo día / Solo noche."));
        ry += btnH + gap;

        addCycle(rx, ry, rw, "Clima: " + weatherLabel(this.config.weather), () -> {
            SpawnerConfig.Weather[] vals = SpawnerConfig.Weather.values();
            this.config.weather = vals[(this.config.weather.ordinal() + 1) % vals.length];
            this.rebuildWidgets();
        }, desc("Cualquiera / Despejado / Lluvia / Tormenta."));
        ry += btnH + gap;

        addToggle(rx, ry, halfW, "Oleadas", this.config.waves, () -> {
            this.config.waves = !this.config.waves; this.rebuildWidgets();
        });
        addToggle(rx + halfW + 6, ry, halfW, "Modo Jefe", this.config.bossMode, () -> {
            this.config.bossMode = !this.config.bossMode; this.rebuildWidgets();
        }, desc("Genera una sola entidad fuerte, brillante y persistente."));
        ry += btnH + gap;

        addToggle(rx, ry, halfW, "Continuo", this.config.continuous, () -> {
            this.config.continuous = !this.config.continuous; this.rebuildWidgets();
        });
        addToggle(rx + halfW + 6, ry, halfW,
            this.config.requiresPlayer ? "Req. jugador" : "Sin jugador",
            this.config.requiresPlayer, () -> {
                this.config.requiresPlayer = !this.config.requiresPlayer; this.rebuildWidgets();
            }, desc("Si está activo, sólo aparece con jugador en rango."));
        ry += btnH + gap;

        addToggle(rx, ry, halfW,
            this.config.requiresSky ? "Necesita cielo" : "Cielo libre",
            this.config.requiresSky, () -> {
                this.config.requiresSky = !this.config.requiresSky;
                if (this.config.requiresSky) this.config.requiresNoSky = false;
                this.rebuildWidgets();
            }, desc("Sólo aparece si la posición ve cielo (al aire libre)."));
        addToggle(rx + halfW + 6, ry, halfW,
            this.config.requiresNoSky ? "Bajo techo" : "Techo libre",
            this.config.requiresNoSky, () -> {
                this.config.requiresNoSky = !this.config.requiresNoSky;
                if (this.config.requiresNoSky) this.config.requiresSky = false;
                this.rebuildWidgets();
            }, desc("Sólo aparece bajo techo (sin acceso a cielo)."));
        ry += btnH + gap;

        // Luz min / max en una fila
        int luzLabelW = 80;
        addIntField(rx + luzLabelW, ry, halfW - luzLabelW - 4, this.config.minLight,
            v -> this.config.minLight = clamp(v, 0, 15), "Luz mín 0-15", rx, ry + 4);
        addIntField(rx + halfW + 6 + luzLabelW, ry, halfW - luzLabelW - 4, this.config.maxLight,
            v -> this.config.maxLight = clamp(v, 0, 15), "Luz máx 0-15", rx + halfW + 6, ry + 4);
    }

    private static int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }

    private static String dayCycleLabel(SpawnerConfig.DayCycle c) {
        return switch (c) {
            case ANY -> "Cualquiera";
            case DAY_ONLY -> "Solo día";
            case NIGHT_ONLY -> "Solo noche";
        };
    }

    private static String weatherLabel(SpawnerConfig.Weather w) {
        return switch (w) {
            case ANY -> "Cualquiera";
            case CLEAR -> "Despejado";
            case RAIN -> "Lluvia";
            case THUNDER -> "Tormenta";
        };
    }

    private void initAttributes() {
        int x = this.bodyX();
        int y = this.bodyY();
        int row = 0;
        for (FSAttributes.Attr attr : FSAttributes.ALL) {
            int fy = y + row * 22;
            Double current = this.config.attributes.get(attr.id);
            String val = current == null ? "" : trim(current);
            EditBox box = new EditBox(this.font, x + 180, fy, 70, 16, Component.empty());
            box.setValue(val);
            box.setMaxLength(16);
            box.setHint(Component.literal(trim(attr.defaultValue)));
            box.setResponder(s -> {
                String t = s.trim();
                if (t.isEmpty()) {
                    this.config.attributes.remove(attr.id);
                } else {
                    try { this.config.attributes.put(attr.id, Double.parseDouble(t)); }
                    catch (NumberFormatException ignored) {}
                }
            });
            this.addRenderableWidget(box);
            this.labels.add(new Label(attr.label, x, fy + 4, 0xE0E0E0));
            addTooltip(x, fy + 2, 170, 14, desc("Valor por defecto del mob: " + trim(attr.defaultValue), "Vacío = no modificarlo."));
            row++;
        }
        this.labels.add(new Label("Deja vacío para usar el valor por defecto.", x, y + row * 22 + 4, 0x808080));
    }

    private void initEquipment() {
        int x = this.bodyX();
        int y = this.bodyY();
        int colW = (this.bodyW() - 8) / 2;
        EquipmentSlot[] slots = { EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND, EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET };
        String[] names = { "Mano", "2da Mano", "Casco", "Pechera", "Pantalón", "Botas" };
        int bw = colW / 3 - 2;
        for (int i = 0; i < slots.length; i++) {
            EquipmentSlot s = slots[i];
            boolean active = s == this.selectedSlot;
            int bx = x + (i % 3) * (bw + 3);
            int by = y + (i / 3) * 18;
            this.addRenderableWidget(Button.builder(Component.literal((active ? "§e" : "") + names[i]),
                b -> { this.selectedSlot = s; this.rebuildWidgets(); })
                .bounds(bx, by, bw, 16).build());
        }
        EquipmentEntry entry = getOrCreateEquipment(this.selectedSlot);
        int fy = y + 40;
        this.labels.add(new Label("Item: " + (entry.item.isEmpty() ? "§7(vacío)" : entry.item.getHoverName().getString()), x, fy + 4, 0xFFFFFF));
        this.addRenderableWidget(Button.builder(Component.literal("Limpiar slot"), b -> {
            entry.item = ItemStack.EMPTY; this.rebuildWidgets();
        }).bounds(x + colW - 90, fy, 90, 16).build());

        addPercentField(x + 150, fy + 22, 60, entry.dropChance,
            v -> entry.dropChance = (float) v, "Prob. de Drop (%)", x, fy + 22 + 4);
        addPercentField(x + 150, fy + 44, 60, entry.appearChance,
            v -> entry.appearChance = (float) v, "Prob. de Aparición (%)", x, fy + 44 + 4);

        int rightX = x + colW + 8;
        EditBox search = new EditBox(this.font, rightX, y, colW, 16, Component.empty());
        search.setHint(Component.translatable("fspawner.search"));
        this.addRenderableWidget(search);
        ScrollSelector<Item> list = new ScrollSelector<>(rightX, y + 20, colW, this.bodyH() - 22, 18,
            RegistryLists::itemName,
            it -> RegistryLists.itemName(it) + " " + RegistryLists.itemId(it),
            it -> new ItemStack(it));
        list.setItems(RegistryLists.items());
        list.onSelect(it -> { entry.item = new ItemStack(it); this.rebuildWidgets(); });
        search.setResponder(list::setQuery);
        this.addRenderableWidget(list);
    }

    private EquipmentEntry getOrCreateEquipment(EquipmentSlot slot) {
        EquipmentEntry e = this.config.equipmentFor(slot);
        if (e == null) {
            e = new EquipmentEntry(slot);
            e.item = ItemStack.EMPTY;
            this.config.equipment.add(e);
        }
        return e;
    }

    private void initEffects() {
        int x = this.bodyX();
        int y = this.bodyY();
        int colW = (this.bodyW() - 8) / 2;
        int rightX = x + colW + 8;
        EditBox search = new EditBox(this.font, x, y, colW, 16, Component.empty());
        search.setHint(Component.translatable("fspawner.search"));
        this.addRenderableWidget(search);

        ScrollSelector<MobEffect> all = new ScrollSelector<>(x, y + 20, colW, this.bodyH() - 22, 12,
            RegistryLists::effectName,
            e -> RegistryLists.effectName(e) + " " + RegistryLists.effectId(e),
            null);
        all.setItems(RegistryLists.effects());
        all.onSelect(e -> {
            String id = RegistryLists.effectId(e);
            if (this.config.effects.stream().noneMatch(fxx -> fxx.id.equals(id))) {
                this.config.effects.add(new EffectEntry(id));
            }
            this.rebuildWidgets();
        });
        search.setResponder(all::setQuery);
        this.addRenderableWidget(all);

        ScrollSelector<EffectEntry> current = new ScrollSelector<>(rightX, y, colW, this.bodyH() - 70, 12,
            this::effectLabel, fxe -> fxe.id, null);
        current.setItems(new ArrayList<>(this.config.effects));
        current.onSelect(fxe -> { this.selectedEffect = fxe; this.rebuildWidgets(); });
        current.setSelected(this.selectedEffect);
        this.addRenderableWidget(current);

        if (this.selectedEffect != null && this.config.effects.contains(this.selectedEffect)) {
            EffectEntry fx = this.selectedEffect;
            int fy = y + this.bodyH() - 66;
            addIntField(rightX + 70, fy,      40, fx.amplifier + 1,
                v -> fx.amplifier = Math.max(0, v - 1), "Nivel", rightX, fy + 4);
            addIntField(rightX + 70, fy + 18, 60, fx.duration,
                v -> fx.duration = Math.max(1, v), "Duración", rightX, fy + 18 + 4);
            addToggle(rightX + 140, fy, colW - 140,
                fx.permanent ? "Permanente" : "Temporal", fx.permanent, () -> {
                fx.permanent = !fx.permanent; this.rebuildWidgets();
            });
            this.addRenderableWidget(Button.builder(Component.literal("Quitar efecto"), b -> {
                this.config.effects.remove(fx);
                this.selectedEffect = null;
                this.rebuildWidgets();
            }).bounds(rightX + 140, fy + 18, colW - 140, 16).build());
        }
    }

    private String effectLabel(EffectEntry fx) {
        MobEffect effect = ForgeRegistries.MOB_EFFECTS.getValue(ResourceLocation.tryParse(fx.id));
        String name = effect != null ? effect.getDisplayName().getString() : fx.id;
        return name + " " + (fx.amplifier + 1) + (fx.permanent ? " §b∞" : "");
    }

    private void initInfernal() {
        int x = this.bodyX();
        int y = this.bodyY();
        int colW = (this.bodyW() - 8) / 2;
        int rightX = x + colW + 8;
        this.addRenderableWidget(Button.builder(Component.literal("Modo: " + infernalModeLabel(this.config.infernal.mode)), b -> {
            InfernalConfig.Mode[] modes = InfernalConfig.Mode.values();
            this.config.infernal.mode = modes[(this.config.infernal.mode.ordinal() + 1) % modes.length];
            this.rebuildWidgets();
        }).bounds(x, y, colW, 16).build());

        addIntField(x + 90, y + 22, 50, this.config.infernal.min,
            v -> this.config.infernal.min = Math.max(0, v), "Mínimo", x, y + 22 + 4);
        addIntField(x + 90, y + 42, 50, this.config.infernal.max,
            v -> this.config.infernal.max = Math.max(0, v), "Máximo", x, y + 42 + 4);

        boolean usePool = this.config.infernal.mode == InfernalConfig.Mode.RANDOM;
        this.labels.add(new Label(usePool ? "Pool permitido (aleatorio):" : "Modificadores fijos:",
            rightX, y - 10, 0xA0A0A0));
        List<String> mods = new ArrayList<>(InfernalModifiers.FRIENDLY.keySet());
        ScrollSelector<String> list = new ScrollSelector<>(rightX, y, colW, this.bodyH(), 12,
            InfernalModifiers::friendly, m -> InfernalModifiers.friendly(m) + " " + m, null);
        list.withCheckbox(m -> targetModList().contains(m));
        list.setItems(mods);
        list.onSelect(m -> {
            List<String> target = targetModList();
            if (target.contains(m)) target.remove(m); else target.add(m);
        });
        this.addRenderableWidget(list);

        this.labels.add(new Label("Infernal Mobs " + (InfernalMobsIntegration.isLoaded() ? "§adetectado" : "§cno instalado"),
            x, y + 70, 0xFFFFFF));
    }

    private List<String> targetModList() {
        return this.config.infernal.mode == InfernalConfig.Mode.RANDOM
            ? this.config.infernal.pool : this.config.infernal.mods;
    }

    private static String infernalModeLabel(InfernalConfig.Mode mode) {
        return switch (mode) {
            case DISABLED -> "Desactivado";
            case ALWAYS -> "Siempre Infernal";
            case RANDOM -> "Aleatorio";
            case CUSTOM -> "Personalizado";
        };
    }

    private void initDrops() {
        int x = this.bodyX();
        int y = this.bodyY();
        int colW = (this.bodyW() - 8) / 2;
        int rightX = x + colW + 8;
        EditBox search = new EditBox(this.font, x, y, colW, 16, Component.empty());
        search.setHint(Component.translatable("fspawner.search"));
        this.addRenderableWidget(search);

        ScrollSelector<Item> all = new ScrollSelector<>(x, y + 20, colW, this.bodyH() - 22, 18,
            RegistryLists::itemName,
            it -> RegistryLists.itemName(it) + " " + RegistryLists.itemId(it),
            it -> new ItemStack(it));
        all.setItems(RegistryLists.items());
        all.onSelect(it -> {
            DropEntry de = new DropEntry(new ItemStack(it), 1, 1, 1.0f);
            this.config.drops.add(de);
            this.rebuildWidgets();
        });
        search.setResponder(all::setQuery);
        this.addRenderableWidget(all);

        ScrollSelector<DropEntry> current = new ScrollSelector<>(rightX, y, colW, this.bodyH() - 92, 18,
            this::dropLabel, d -> d.item.getHoverName().getString(), d -> d.item);
        current.setItems(new ArrayList<>(this.config.drops));
        current.onSelect(d -> { this.selectedDrop = d; this.rebuildWidgets(); });
        current.setSelected(this.selectedDrop);   // mantener resaltado tras reconstruir
        this.addRenderableWidget(current);

        addToggle(rightX, y + this.bodyH() - 18, colW,
            this.config.keepVanillaDrops ? "Mantener Drops Vanilla" : "Reemplazar Drops Vanilla",
            this.config.keepVanillaDrops,
            () -> { this.config.keepVanillaDrops = !this.config.keepVanillaDrops; this.rebuildWidgets(); });

        if (this.selectedDrop != null && this.config.drops.contains(this.selectedDrop)) {
            DropEntry d = this.selectedDrop;
            int fy = y + this.bodyH() - 90;

            // Cabecera: qué item estás editando (icono + nombre resaltado)
            String editName = d.item.getHoverName().getString();
            String trimmedName = this.font.plainSubstrByWidth("Editando: " + editName, colW - 24);
            this.editingIcon = d.item;
            this.editingIconX = rightX;
            this.editingIconY = fy - 20;
            this.labels.add(new Label("§eEditando:§r " + trimmedName, rightX + 20, fy - 16, 0xFFFF55));

            addIntField(rightX + 48,  fy, 36, d.min, v -> d.min = Math.max(0, v),
                "Cant. mín", rightX, fy + 4);
            addIntField(rightX + 145, fy, 36, d.max, v -> d.max = Math.max(0, v),
                "Max", rightX + 110, fy + 4);
            addPercentField(rightX + 110, fy + 22, 45, d.chance,
                v -> d.chance = (float) v, "Probabilidad (%)", rightX, fy + 22 + 4);
            this.addRenderableWidget(Button.builder(Component.literal("Quitar"), b -> {
                this.config.drops.remove(d);
                this.selectedDrop = null;
                this.rebuildWidgets();
            }).bounds(rightX, fy + 44, colW, 16).build());
        } else {
            this.editingIcon = null;
            this.labels.add(new Label("§7Selecciona un item de la lista para editarlo.",
                rightX, y + this.bodyH() - 86, 0x909090));
        }
    }

    private String dropLabel(DropEntry d) {
        int pct = Math.round(d.chance * 100.0f);
        return d.item.getHoverName().getString() + " §7" + d.min + "-" + d.max + " (" + pct + "%)";
    }

    private void initAppearance() {
        int x = this.bodyX();
        int y = this.bodyY();
        int fw = this.bodyW() - 170;

        EditBox itemName = new EditBox(this.font, x + 160, y, Math.max(120, fw), 16, Component.empty());
        itemName.setMaxLength(128);
        itemName.setValue(this.config.itemName);
        itemName.setResponder(s -> this.config.itemName = s);
        this.addRenderableWidget(itemName);
        this.labels.add(new Label("Nombre del Item:", x, y + 4, 0xE0E0E0));

        EditBox mobName = new EditBox(this.font, x + 160, y + 22, Math.max(120, fw), 16, Component.empty());
        mobName.setMaxLength(128);
        mobName.setValue(this.config.mobName);
        mobName.setResponder(s -> this.config.mobName = s);
        this.addRenderableWidget(mobName);
        this.labels.add(new Label("Nombre Visible (mob):", x, y + 26, 0xE0E0E0));

        this.addRenderableWidget(Button.builder(Component.literal("Color: " + colorEs(this.config.nameColor)), b -> {
            int idx = 0;
            for (int i = 0; i < NAME_COLORS.length; i++) {
                if (NAME_COLORS[i].equals(this.config.nameColor)) { idx = i; break; }
            }
            this.config.nameColor = NAME_COLORS[(idx + 1) % NAME_COLORS.length];
            this.rebuildWidgets();
        }).bounds(x + 160, y + 44, 150, 16).build());
        this.labels.add(new Label("Color del Nombre:", x, y + 48, 0xE0E0E0));

        addToggle(x, y + 70, 200,
            this.config.mobNameVisible ? "Nombre Siempre Visible" : "Nombre Oculto",
            this.config.mobNameVisible, () -> {
                this.config.mobNameVisible = !this.config.mobNameVisible; this.rebuildWidgets();
            });
        addToggle(x, y + 92, 200, this.config.glowing ? "Brillo: Activado" : "Brillo: Desactivado",
            this.config.glowing, () -> {
                this.config.glowing = !this.config.glowing; this.rebuildWidgets();
            });
        addToggle(x, y + 114, 200, this.config.particles ? "Partículas: Activado" : "Partículas: Desactivado",
            this.config.particles, () -> {
                this.config.particles = !this.config.particles; this.rebuildWidgets();
            });
    }

    private static String colorEs(String c) {
        return switch (c) {
            case "white" -> "Blanco";
            case "yellow" -> "Amarillo";
            case "gold" -> "Dorado";
            case "red" -> "Rojo";
            case "aqua" -> "Cian";
            case "green" -> "Verde";
            case "light_purple" -> "Rosa";
            case "blue" -> "Azul";
            case "dark_purple" -> "Morado";
            case "gray" -> "Gris";
            default -> c;
        };
    }

    // ====== Helpers de UI ======
    private static List<Component> desc(String... lines) {
        List<Component> out = new ArrayList<>();
        for (String s : lines) out.add(Component.literal(s));
        return out;
    }

    private void addTooltip(int x, int y, int w, int h, List<Component> lines) {
        if (lines != null && !lines.isEmpty()) this.tooltipZones.add(new TooltipZone(x, y, w, h, lines));
    }

    private void addIntField(int x, int y, int w, int value, IntConsumer setter, String label, int labelX, int labelY) {
        addIntField(x, y, w, value, setter, label, labelX, labelY, null);
    }

    private void addIntField(int x, int y, int w, int value, IntConsumer setter, String label, int labelX, int labelY, List<Component> tooltip) {
        EditBox box = new EditBox(this.font, x, y, w, 16, Component.empty());
        box.setMaxLength(12);
        box.setValue(Integer.toString(value));
        box.setResponder(s -> {
            try { setter.accept(Integer.parseInt(s.trim())); }
            catch (NumberFormatException ignored) {}
        });
        this.addRenderableWidget(box);
        this.labels.add(new Label(label, labelX, labelY, 0xE0E0E0));
        if (tooltip != null) addTooltip(labelX, labelY - 2, x + w - labelX, 14, tooltip);
    }

    private void addSecondsField(int x, int y, int w, int ticks, IntConsumer setterTicks, String label, int labelX, int labelY, List<Component> tooltip) {
        EditBox box = new EditBox(this.font, x, y, w, 16, Component.empty());
        box.setMaxLength(8);
        box.setValue(trim((double) Math.round(ticks / 20.0)));
        box.setResponder(s -> {
            String t = s.trim();
            if (t.isEmpty()) return;
            try {
                double seconds = Double.parseDouble(t);
                setterTicks.accept((int) Math.round(Math.max(0.0, seconds) * 20.0));
            } catch (NumberFormatException ignored) {}
        });
        this.addRenderableWidget(box);
        this.labels.add(new Label(label, labelX, labelY, 0xE0E0E0));
        if (tooltip != null) addTooltip(labelX, labelY - 2, x + w - labelX, 14, tooltip);
    }

    private void addPercentField(int x, int y, int w, float value01, DoubleConsumer setter01, String label, int labelX, int labelY) {
        addPercentField(x, y, w, value01, setter01, label, labelX, labelY, null);
    }

    private void addPercentField(int x, int y, int w, float value01, DoubleConsumer setter01, String label, int labelX, int labelY, List<Component> tooltip) {
        EditBox box = new EditBox(this.font, x, y, w, 16, Component.empty());
        box.setMaxLength(6);
        box.setValue(trim(Math.round(clamp01(value01) * 100.0f)));
        box.setResponder(s -> {
            String t = s.trim();
            if (t.isEmpty()) return;
            try { setter01.accept(clamp01(Double.parseDouble(t) / 100.0)); }
            catch (NumberFormatException ignored) {}
        });
        this.addRenderableWidget(box);
        this.labels.add(new Label(label, labelX, labelY, 0xE0E0E0));
        if (tooltip != null) addTooltip(labelX, labelY - 2, x + w - labelX, 14, tooltip);
    }

    private void addToggle(int x, int y, int w, String text, boolean state, Runnable onToggle) {
        addToggle(x, y, w, text, state, onToggle, null);
    }

    private void addToggle(int x, int y, int w, String text, boolean state, Runnable onToggle, List<Component> tooltip) {
        String prefix = state ? "§a" : "§7";
        this.addRenderableWidget(Button.builder(Component.literal(prefix + text), b -> onToggle.run())
            .bounds(x, y, w, 16).build());
        if (tooltip != null) addTooltip(x, y, w, 16, tooltip);
    }

    private void addCycle(int x, int y, int w, String text, Runnable onClick, List<Component> tooltip) {
        this.addRenderableWidget(Button.builder(Component.literal("§e" + text), b -> onClick.run())
            .bounds(x, y, w, 16).build());
        if (tooltip != null) addTooltip(x, y, w, 16, tooltip);
    }

    private static float clamp01(double v) { return (float) Math.max(0.0, Math.min(1.0, v)); }

    private static String trim(double value) {
        if (value == Math.floor(value) && !Double.isInfinite(value)) return String.valueOf((long) value);
        return String.valueOf(value);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        g.fill(this.leftPos, this.topPos, this.leftPos + this.panelWidth, this.topPos + this.panelHeight, -535291870);
        g.fill(this.leftPos, this.topPos, this.leftPos + this.panelWidth, this.topPos + 20, -14408646);
        g.fill(this.leftPos, this.topPos + this.panelHeight - 1, this.leftPos + this.panelWidth, this.topPos + this.panelHeight, -12961206);
        g.fill(this.leftPos + 6, this.topPos + 45, this.leftPos + this.panelWidth - 6, this.topPos + 46, -12961206);
        g.drawString(this.font, "§d✦ §fFantastic Spawner §d✦", this.leftPos + 8, this.topPos + 6, 0xFFFFFF, false);

        super.render(g, mouseX, mouseY, partialTick);

        for (Label l : this.labels) {
            g.drawString(this.font, l.text(), l.x(), l.y(), l.color(), false);
        }
        // Icono del item en edición (pestaña Drops)
        if (this.editingIcon != null && !this.editingIcon.isEmpty()) {
            g.renderItem(this.editingIcon, this.editingIconX, this.editingIconY);
        }
        for (TooltipZone z : this.tooltipZones) {
            if (mouseX >= z.x() && mouseX < z.x() + z.w() && mouseY >= z.y() && mouseY < z.y() + z.h()) {
                g.renderComponentTooltip(this.font, z.lines(), mouseX, mouseY);
                break;
            }
        }
    }

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    public boolean shouldCloseOnEsc() { return true; }
}
