package com.fspawner.client.widget;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * Lista vertical con búsqueda, scroll por rueda y por barra (click + arrastre)
 * y navegación por teclado (flechas, PageUp/Down, Home/End).
 */
public class ScrollSelector<T> extends AbstractWidget {

    private static final int SCROLLBAR_WIDTH = 6;

    private final List<T> all = new ArrayList<>();
    private final List<T> filtered = new ArrayList<>();
    private final Function<T, String> displayName;
    private final Function<T, String> filterText;
    private final Function<T, ItemStack> icon;
    private Consumer<T> onSelect = t -> {};
    private Function<T, Boolean> checked;

    private final int rowHeight;
    private int scroll = 0;
    private int selectedIndex = -1;
    private String query = "";

    // Estado de drag de la barra
    private boolean draggingThumb = false;
    private int dragOffsetY = 0;

    public ScrollSelector(int x, int y, int width, int height, int rowHeight,
                          Function<T, String> displayName,
                          Function<T, String> filterText,
                          Function<T, ItemStack> icon) {
        super(x, y, width, height, Component.empty());
        this.rowHeight = rowHeight;
        this.displayName = displayName;
        this.filterText = filterText;
        this.icon = icon;
    }

    public ScrollSelector<T> onSelect(Consumer<T> cb) {
        this.onSelect = cb;
        return this;
    }

    public ScrollSelector<T> withCheckbox(Function<T, Boolean> checkedState) {
        this.checked = checkedState;
        return this;
    }

    public void setItems(List<T> items) {
        this.all.clear();
        this.all.addAll(items);
        applyFilter();
    }

    public void setQuery(String q) {
        this.query = q == null ? "" : q.toLowerCase(Locale.ROOT).trim();
        applyFilter();
    }

    public T getSelected() {
        return (selectedIndex >= 0 && selectedIndex < filtered.size()) ? filtered.get(selectedIndex) : null;
    }

    /** Marca como seleccionado el item indicado (si está en la lista filtrada) y lo deja visible. */
    public void setSelected(T item) {
        this.selectedIndex = item == null ? -1 : this.filtered.indexOf(item);
        if (this.selectedIndex >= 0) ensureVisible();
    }

    private void applyFilter() {
        filtered.clear();
        if (query.isEmpty()) {
            filtered.addAll(all);
        } else {
            for (T t : all) {
                String text = filterText.apply(t).toLowerCase(Locale.ROOT);
                if (text.contains(query)) filtered.add(t);
            }
        }
        scroll = 0;
        selectedIndex = -1;
    }

    private int visibleRows() {
        return Math.max(1, this.height / this.rowHeight);
    }

    private int maxScroll() {
        return Math.max(0, this.filtered.size() - visibleRows());
    }

    private int contentRight() {
        return this.getX() + this.width - SCROLLBAR_WIDTH;
    }

    private boolean overScrollbar(double mouseX, double mouseY) {
        return mouseX >= contentRight()
            && mouseX < this.getX() + this.width
            && mouseY >= this.getY()
            && mouseY < this.getY() + this.height;
    }

    private int thumbHeight() {
        if (filtered.isEmpty()) return this.height;
        return Math.max(12, this.height * visibleRows() / Math.max(1, filtered.size()));
    }

    private int thumbY() {
        int max = maxScroll();
        if (max <= 0) return this.getY();
        return this.getY() + (this.height - thumbHeight()) * scroll / max;
    }

    @Override
    protected void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        // Fondo
        g.fill(this.getX(), this.getY(),
                this.getX() + this.width, this.getY() + this.height, -1072689128);
        g.fill(this.getX(), this.getY(),
                this.getX() + this.width, this.getY() + 1, -12961206);
        g.fill(this.getX(), this.getY() + this.height - 1,
                this.getX() + this.width, this.getY() + this.height, -12961206);

        Font font = Minecraft.getInstance().font;
        int rows = visibleRows();
        for (int i = 0; i < rows; i++) {
            int index = scroll + i;
            if (index < 0 || index >= filtered.size()) break;
            T entry = filtered.get(index);
            int rowY = this.getY() + i * rowHeight;
            boolean hovered = mouseX >= this.getX()
                    && mouseX < contentRight()
                    && mouseY >= rowY && mouseY < rowY + rowHeight;
            if (index == selectedIndex) {
                g.fill(this.getX(), rowY, contentRight(), rowY + rowHeight, -13800225);
            } else if (hovered) {
                g.fill(this.getX(), rowY, contentRight(), rowY + rowHeight, 1090519039);
            }
            int textX = this.getX() + 3;
            if (icon != null) {
                ItemStack stack = icon.apply(entry);
                if (stack != null && !stack.isEmpty()) {
                    g.renderItem(stack, this.getX() + 1, rowY + (rowHeight - 16) / 2);
                }
                textX = this.getX() + 20;
            }
            if (checked != null) {
                boolean on = Boolean.TRUE.equals(checked.apply(entry));
                g.drawString(font, on ? "§a[x]" : "§7[ ]", textX, rowY + (rowHeight - 8) / 2, 0xFFFFFF, false);
                textX += 22;
            }
            String name = displayName.apply(entry);
            String trimmed = font.plainSubstrByWidth(name, this.width - (textX - this.getX()) - 8);
            g.drawString(font, trimmed, textX, rowY + (rowHeight - 8) / 2, 0xE0E0E0, false);
        }
        // Barra
        int barX = contentRight();
        g.fill(barX, this.getY(), barX + SCROLLBAR_WIDTH, this.getY() + this.height, 0x60000000);
        if (maxScroll() > 0) {
            int ty = thumbY();
            int th = thumbHeight();
            int color = draggingThumb ? 0xFFD0D0D0 : 0xFF808080;
            g.fill(barX + 1, ty, barX + SCROLLBAR_WIDTH - 1, ty + th, color);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!isMouseOver(mouseX, mouseY) || button != 0) return false;
        // Click sobre la scrollbar
        if (overScrollbar(mouseX, mouseY) && maxScroll() > 0) {
            int ty = thumbY();
            int th = thumbHeight();
            if (mouseY >= ty && mouseY < ty + th) {
                draggingThumb = true;
                dragOffsetY = (int) (mouseY - ty);
            } else if (mouseY < ty) {
                scroll = Math.max(0, scroll - visibleRows());
            } else {
                scroll = Math.min(maxScroll(), scroll + visibleRows());
            }
            return true;
        }
        // Click sobre una fila
        int row = (int) ((mouseY - this.getY()) / rowHeight);
        int index = scroll + row;
        if (index >= 0 && index < filtered.size() && mouseX < contentRight()) {
            this.selectedIndex = index;
            this.onSelect.accept(filtered.get(index));
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (draggingThumb && maxScroll() > 0) {
            int trackTop = this.getY();
            int trackHeight = this.height - thumbHeight();
            if (trackHeight > 0) {
                int newThumbY = (int) Math.max(trackTop, Math.min(trackTop + trackHeight, mouseY - dragOffsetY));
                this.scroll = (newThumbY - trackTop) * maxScroll() / trackHeight;
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0 && draggingThumb) {
            draggingThumb = false;
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (!isMouseOver(mouseX, mouseY)) return false;
        scroll = Math.max(0, Math.min(maxScroll(), scroll - (int) Math.signum(delta)));
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!isFocused()) return false; // sólo si está enfocado
        switch (keyCode) {
            case GLFW.GLFW_KEY_DOWN: {
                if (filtered.isEmpty()) return true;
                selectedIndex = Math.min(filtered.size() - 1, Math.max(0, selectedIndex) + 1);
                ensureVisible();
                onSelect.accept(filtered.get(selectedIndex));
                return true;
            }
            case GLFW.GLFW_KEY_UP: {
                if (filtered.isEmpty()) return true;
                selectedIndex = Math.max(0, (selectedIndex < 0 ? 0 : selectedIndex - 1));
                ensureVisible();
                onSelect.accept(filtered.get(selectedIndex));
                return true;
            }
            case GLFW.GLFW_KEY_PAGE_DOWN: {
                scroll = Math.min(maxScroll(), scroll + visibleRows());
                return true;
            }
            case GLFW.GLFW_KEY_PAGE_UP: {
                scroll = Math.max(0, scroll - visibleRows());
                return true;
            }
            case GLFW.GLFW_KEY_HOME: {
                scroll = 0;
                return true;
            }
            case GLFW.GLFW_KEY_END: {
                scroll = maxScroll();
                return true;
            }
        }
        return false;
    }

    private void ensureVisible() {
        if (selectedIndex < scroll) scroll = selectedIndex;
        else if (selectedIndex >= scroll + visibleRows()) scroll = selectedIndex - visibleRows() + 1;
        scroll = Math.max(0, Math.min(maxScroll(), scroll));
    }

    @Override
    public boolean isMouseOver(double mouseX, double mouseY) {
        return mouseX >= this.getX() && mouseX < this.getX() + this.width
            && mouseY >= this.getY() && mouseY < this.getY() + this.height;
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput out) {}
}
