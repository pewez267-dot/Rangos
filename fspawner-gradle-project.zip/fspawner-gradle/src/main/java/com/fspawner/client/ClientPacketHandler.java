// 
// Decompiled by Procyon v0.6.0
// 

package com.fspawner.client;

import net.minecraft.client.gui.screens.Screen;
import com.fspawner.client.screen.FSpawnerScreen;
import net.minecraft.client.Minecraft;
import com.fspawner.config.SpawnerConfig;
import net.minecraft.nbt.CompoundTag;

public final class ClientPacketHandler
{
    private ClientPacketHandler() {
    }
    
    public static void openScreen(final CompoundTag configNbt) {
        final SpawnerConfig cfg = (configNbt == null) ? new SpawnerConfig() : SpawnerConfig.load(configNbt);
        Minecraft.m_91087_().m_91152_((Screen)new FSpawnerScreen(cfg));
    }
}
