package com.fspawner.client;

import com.fspawner.client.screen.FSpawnerScreen;
import com.fspawner.config.SpawnerConfig;
import com.fspawner.network.EditContext;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;

public final class ClientPacketHandler {

    private ClientPacketHandler() {}

    public static void openScreen(CompoundTag configNbt, EditContext context) {
        SpawnerConfig cfg = configNbt == null ? new SpawnerConfig() : SpawnerConfig.load(configNbt);
        Minecraft.getInstance().setScreen(new FSpawnerScreen(cfg, context == null ? EditContext.newSession() : context));
    }
}
