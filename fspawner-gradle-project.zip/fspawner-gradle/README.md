# FSpawner — Fantastic Spawner para Forge 1.20.1

**Autor:** Pewez
**Versión:** 2.0.0
**Minecraft:** 1.20.1
**Forge:** 47.x

Sistema avanzado de spawners que extiende el spawner vanilla con GUI completa,
edición en sitio mediante comandos, reguladores extendidos de aparición,
integración con Infernal Mobs y soporte universal para entidades e items de
cualquier mod.

## Novedades 2.0.0

- **Comando `/fspawner edit`** (alias `/fsedit`):
  - Si tienes un Fantastic Spawner en la mano abre el editor y al guardar
    **reemplaza el item en su slot original** (no genera duplicados).
  - Si miras un Fantastic Spawner colocado a ≤ 6 bloques, abre el editor del
    **bloque ya puesto** y guarda los cambios directamente en su NBT (sin
    romperlo ni reemplazar).
  - Si no aplica nada de lo anterior, abre un editor con configuración nueva.
- **Reguladores nuevos en la pestaña Aparición:**
  - Día / Noche / Cualquiera.
  - Clima: Cualquiera / Despejado / Lluvia / Tormenta.
  - Luz mínima y máxima (0–15) en el bloque del spawn.
  - Requiere ver cielo / Requiere estar bajo techo.
  - Requiere o no jugador en rango.
  - Cooldown extra en segundos sumado a los retardos.
- **Listas (scroll selector):**
  - Scroll con rueda del ratón.
  - **Click y arrastre** del thumb de la barra.
  - **Click en el carril** para paginar.
  - Flechas, PageUp/PageDown y Home/End por teclado.
- **Edición de spawners no-FSpawner:** si miras un spawner vanilla, el editor
  reconstruye una configuración mínima (entidad y delays) para que puedas
  promocionarlo a Fantastic Spawner sin romperlo.
- **Bug fix:** el bug del decompilador en `initDrops` (variable `dropEntry`
  sin asignar) que impedía compilar el proyecto Gradle desde fuente.
- Permisos del comando bajados a OP nivel 2 (antes 4) para que admins puedan
  usarlo sin tocar `level=4`. La verificación de servidor sigue siendo OP 2.

## Comandos

```
/fspawner            → Igual que /fspawner edit (auto-detecta contexto)
/fspawner edit       → Abre el editor para item en mano / bloque mirado / nuevo
/fspawner create     → Abre un editor para una config nueva
/fspawner pickup     → Recoge el bloque que estés mirando como item
/fspawner save  <n>  → Guarda como preset la config del item en mano
/fspawner load  <n>  → Da un Fantastic Spawner construido desde un preset
/fspawner delete<n>  → Elimina un preset
/fsedit              → Alias corto de /fspawner edit
```

## Estructura del Proyecto

```
fspawner-gradle/
├── build.gradle
├── settings.gradle
├── gradle.properties
├── gradlew / gradlew.bat
├── gradle/wrapper/
└── src/main/
    ├── java/com/fspawner/
    │   ├── FSpawner.java
    │   ├── client/
    │   │   ├── ClientEvents.java
    │   │   ├── ClientPacketHandler.java
    │   │   ├── ClientSetup.java
    │   │   ├── TooltipBuilder.java
    │   │   ├── screen/FSpawnerScreen.java
    │   │   └── widget/ScrollSelector.java
    │   ├── command/
    │   │   ├── FSpawnerCommand.java
    │   │   └── FSpawnerPresets.java
    │   ├── config/
    │   │   ├── DropEntry.java
    │   │   ├── EffectEntry.java
    │   │   ├── EntityEntry.java
    │   │   ├── EquipmentEntry.java
    │   │   ├── FSKeys.java
    │   │   ├── InfernalConfig.java
    │   │   └── SpawnerConfig.java        ← extendida con reguladores nuevos
    │   ├── event/FSpawnerEvents.java     ← FinalizeSpawn handler
    │   ├── integration/
    │   │   ├── InfernalMobsIntegration.java
    │   │   └── InfernalModifiers.java
    │   ├── item/
    │   │   ├── EntityNbtBuilder.java
    │   │   └── SpawnerItemBuilder.java
    │   ├── network/
    │   │   ├── EditContext.java          ← NUEVO: contexto de edición
    │   │   ├── FSNetwork.java
    │   │   ├── OpenScreenPacket.java
    │   │   └── SaveConfigPacket.java
    │   └── util/
    │       ├── FSAttributes.java
    │       └── RegistryLists.java
    └── resources/
        ├── pack.mcmeta
        ├── META-INF/mods.toml
        └── assets/fspawner/lang/
            ├── en_us.json
            └── es_es.json
```

## Compilar

```bash
# Linux/Mac
./gradlew build

# Windows
gradlew.bat build
```

El JAR resultante está en `build/libs/fspawner-2.0.0.jar`.

### Setup IDE
```bash
./gradlew genEclipseRuns    # Eclipse
./gradlew genIntellijRuns   # IntelliJ IDEA
```

## Mappings

Este proyecto usa `mappings channel: 'official'` (Mojang). Si prefieres
Parchment para tener nombres de parámetros, cambia en `build.gradle`:
```groovy
mappings channel: 'parchment', version: '2023.09.03-1.20.1'
```
y añade en `settings.gradle`:
```groovy
maven { url = 'https://maven.parchmentmc.org' }
```

## Compatibilidad

- Forge 1.20.1, 47.x.
- Java 17.
- **Infernal Mobs**: integración opcional (reflection). El mod funciona con o
  sin él.
- **Spawners vanilla**: no se modifican; sólo los marcados con la NBT de
  Fantastic Spawner aplican las nuevas reglas.

## Licencia

Todos los derechos reservados — © Pewez.
Prohibida la copia, descompilación, redistribución o uso del código sin
autorización expresa del autor.
