# FSpawner — Fantastic Spawner for Forge 1.20.1

**Autor:** Pewez  
**Versión:** 1.0.0  
**Minecraft:** 1.20.1  
**Forge:** 47.x

Sistema avanzado de spawners que extiende el spawner vanilla con GUI completa, integración con Infernal Mobs y soporte universal para entidades e items de cualquier mod.

## Estructura del Proyecto

```
fspawner-gradle/
├── build.gradle
├── settings.gradle
├── gradle.properties
├── gradlew / gradlew.bat
├── gradle/wrapper/
│   ├── gradle-wrapper.jar
│   └── gradle-wrapper.properties
└── src/main/
    ├── java/com/fspawner/
    │   ├── FSpawner.java                    ← @Mod principal
    │   ├── client/
    │   │   ├── ClientEvents.java
    │   │   ├── ClientPacketHandler.java
    │   │   ├── ClientSetup.java
    │   │   ├── TooltipBuilder.java
    │   │   ├── screen/FSpawnerScreen.java
    │   │   └── widget/ScrollSelector.java
    │   ├── command/
    │   │   ├── FSpawnerCommand.java
    │   │   └── FSpawnerPresets.java
    │   ├── config/
    │   │   ├── DropEntry.java
    │   │   ├── EffectEntry.java
    │   │   ├── EntityEntry.java
    │   │   ├── EquipmentEntry.java
    │   │   ├── FSKeys.java
    │   │   ├── InfernalConfig.java
    │   │   └── SpawnerConfig.java
    │   ├── event/FSpawnerEvents.java
    │   ├── integration/
    │   │   ├── InfernalMobsIntegration.java
    │   │   └── InfernalModifiers.java
    │   ├── item/
    │   │   ├── EntityNbtBuilder.java
    │   │   └── SpawnerItemBuilder.java
    │   ├── network/
    │   │   ├── FSNetwork.java
    │   │   ├── OpenScreenPacket.java
    │   │   └── SaveConfigPacket.java
    │   └── util/
    │       ├── FSAttributes.java
    │       └── RegistryLists.java
    └── resources/
        ├── pack.mcmeta
        ├── META-INF/mods.toml
        └── assets/fspawner/lang/
            ├── en_us.json
            └── es_es.json
```

## Dependencias opcionales

- **Infernal Mobs** — integración opcional, el mod funciona sin ella.
  Si quieres compilar con ella, añade a `build.gradle`:
  ```groovy
  // (necesitas el jar de infernalmobs en tu repositorio local)
  compileOnly files('libs/infernalmobs-<version>.jar')
  ```

## Compilar

```bash
# Linux/Mac
./gradlew build

# Windows
gradlew.bat build
```

El JAR resultante estará en `build/libs/fspawner-1.0.0.jar`.

### Setup IDE
```bash
./gradlew genEclipseRuns    # Eclipse
./gradlew genIntellijRuns   # IntelliJ IDEA
```

## Nota

Los nombres de métodos SRG (`m_xxxxx_`, `f_xxxxx_`) son los mappings obfuscados.
Para nombres legibles usa Parchment: cambia en `build.gradle`:
```groovy
mappings channel: 'parchment', version: '2023.09.03-1.20.1'
```
y añade en `settings.gradle`:
```groovy
maven { url = 'https://maven.parchmentmc.org' }
```
