package com.llamalad7.mixinextras.injector.wrapoperation;

/* JADX INFO: loaded from: Henny Essentials-forge-1.21.1-1.0.4-H3-all.jar:META-INF/jarjar/mixinextras-forge-0.4.1.jar:META-INF/jars/MixinExtras-0.4.1.jar:com/llamalad7/mixinextras/injector/wrapoperation/Operation.class */
@FunctionalInterface
public interface Operation<R> {
    R call(Object... objArr);
}
