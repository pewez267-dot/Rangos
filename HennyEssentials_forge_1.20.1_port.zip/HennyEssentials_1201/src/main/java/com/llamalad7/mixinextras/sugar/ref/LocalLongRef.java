package com.llamalad7.mixinextras.sugar.ref;

/* JADX INFO: loaded from: Henny Essentials-forge-1.21.1-1.0.4-H3-all.jar:META-INF/jarjar/mixinextras-forge-0.4.1.jar:META-INF/jars/MixinExtras-0.4.1.jar:com/llamalad7/mixinextras/sugar/ref/LocalLongRef.class */
public interface LocalLongRef {
    long get();

    void set(long j);
}
