package com.llamalad7.mixinextras.utils;

/* JADX INFO: loaded from: Henny Essentials-forge-1.21.1-1.0.4-H3-all.jar:META-INF/jarjar/mixinextras-forge-0.4.1.jar:META-INF/jars/MixinExtras-0.4.1.jar:com/llamalad7/mixinextras/utils/Decorations.class */
public class Decorations {
    public static final String PERSISTENT = "mixinextras_persistent_";
    public static final String POPPED_OPERATION = "mixinextras_operationIsImmediatelyPopped";
    public static final String LOCAL_REF_MAP = "mixinextras_localRefMap";
    public static final String NEW_IS_DUPED = "mixinextras_newIsDuped";
    public static final String NEW_ARG_TYPES = "mixinextras_newArgTypes";
    public static final String WRAPPED = "mixinextras_wrappedOperation";
    public static final String CANCELLABLE_CI_INDEX = "mixinextras_cancellableCiIndex";
}
