package com.llamalad7.mixinextras.versions;

import java.util.Arrays;
import java.util.List;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.AnnotationNode;
import org.spongepowered.asm.mixin.injection.modify.LocalVariableDiscriminator;
import org.spongepowered.asm.mixin.injection.struct.InjectionInfo;
import org.spongepowered.asm.mixin.injection.struct.Target;
import org.spongepowered.asm.mixin.refmap.IMixinContext;

/* JADX INFO: loaded from: Henny Essentials-forge-1.21.1-1.0.4-H3-all.jar:META-INF/jarjar/mixinextras-forge-0.4.1.jar:META-INF/jars/MixinExtras-0.4.1.jar:com/llamalad7/mixinextras/versions/MixinVersion.class */
public abstract class MixinVersion {
    private static final List<String> VERSIONS = Arrays.asList("0.8.7", "0.8.4", "0.8.3", "0.8");
    private static final MixinVersion INSTANCE;

    public abstract RuntimeException makeInvalidInjectionException(InjectionInfo injectionInfo, String str);

    public abstract IMixinContext getMixin(InjectionInfo injectionInfo);

    public abstract LocalVariableDiscriminator.Context makeLvtContext(InjectionInfo injectionInfo, Type type, boolean z, Target target, AbstractInsnNode abstractInsnNode);

    public abstract void preInject(InjectionInfo injectionInfo);

    public abstract AnnotationNode getAnnotation(InjectionInfo injectionInfo);

    public abstract int getOrder(InjectionInfo injectionInfo);

    /* JADX WARN: Code restructure failed: missing block: B:12:0x00a1, code lost:
    
        com.llamalad7.mixinextras.versions.MixinVersion.INSTANCE = r6;
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x00a5, code lost:
    
        return;
     */
    static {
        /*
            r0 = 4
            java.lang.String[] r0 = new java.lang.String[r0]
            r1 = r0
            r2 = 0
            java.lang.String r3 = "0.8.7"
            r1[r2] = r3
            r1 = r0
            r2 = 1
            java.lang.String r3 = "0.8.4"
            r1[r2] = r3
            r1 = r0
            r2 = 2
            java.lang.String r3 = "0.8.3"
            r1[r2] = r3
            r1 = r0
            r2 = 3
            java.lang.String r3 = "0.8"
            r1[r2] = r3
            java.util.List r0 = java.util.Arrays.asList(r0)
            com.llamalad7.mixinextras.versions.MixinVersion.VERSIONS = r0
            org.spongepowered.asm.mixin.MixinEnvironment r0 = org.spongepowered.asm.mixin.MixinEnvironment.getCurrentEnvironment()
            java.lang.String r0 = r0.getVersion()
            org.spongepowered.asm.util.VersionNumber r0 = org.spongepowered.asm.util.VersionNumber.parse(r0)
            r5 = r0
            r0 = 0
            r6 = r0
            java.util.List<java.lang.String> r0 = com.llamalad7.mixinextras.versions.MixinVersion.VERSIONS
            java.util.Iterator r0 = r0.iterator()
            r7 = r0
        L33:
            r0 = r7
            boolean r0 = r0.hasNext()
            if (r0 == 0) goto La1
            r0 = r7
            java.lang.Object r0 = r0.next()
            java.lang.String r0 = (java.lang.String) r0
            r8 = r0
            r0 = r8
            org.spongepowered.asm.util.VersionNumber r0 = org.spongepowered.asm.util.VersionNumber.parse(r0)
            r1 = r5
            int r0 = r0.compareTo(r1)
            if (r0 <= 0) goto L54
            goto L33
        L54:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch: java.lang.Throwable -> L95
            r1 = r0
            r1.<init>()     // Catch: java.lang.Throwable -> L95
            java.lang.Class<com.llamalad7.mixinextras.versions.MixinVersion> r1 = com.llamalad7.mixinextras.versions.MixinVersion.class
            java.lang.Package r1 = r1.getPackage()     // Catch: java.lang.Throwable -> L95
            java.lang.String r1 = r1.getName()     // Catch: java.lang.Throwable -> L95
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch: java.lang.Throwable -> L95
            java.lang.String r1 = ".MixinVersionImpl_v"
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch: java.lang.Throwable -> L95
            r1 = r8
            r2 = 46
            r3 = 95
            java.lang.String r1 = r1.replace(r2, r3)     // Catch: java.lang.Throwable -> L95
            java.lang.StringBuilder r0 = r0.append(r1)     // Catch: java.lang.Throwable -> L95
            java.lang.String r0 = r0.toString()     // Catch: java.lang.Throwable -> L95
            java.lang.Class r0 = java.lang.Class.forName(r0)     // Catch: java.lang.Throwable -> L95
            r9 = r0
            r0 = r9
            r1 = 0
            java.lang.Class[] r1 = new java.lang.Class[r1]     // Catch: java.lang.Throwable -> L95
            java.lang.reflect.Constructor r0 = r0.getConstructor(r1)     // Catch: java.lang.Throwable -> L95
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch: java.lang.Throwable -> L95
            java.lang.Object r0 = r0.newInstance(r1)     // Catch: java.lang.Throwable -> L95
            com.llamalad7.mixinextras.versions.MixinVersion r0 = (com.llamalad7.mixinextras.versions.MixinVersion) r0     // Catch: java.lang.Throwable -> L95
            r6 = r0
            goto La1
        L95:
            r9 = move-exception
            java.lang.RuntimeException r0 = new java.lang.RuntimeException
            r1 = r0
            r2 = r9
            r1.<init>(r2)
            throw r0
        La1:
            r0 = r6
            com.llamalad7.mixinextras.versions.MixinVersion.INSTANCE = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.llamalad7.mixinextras.versions.MixinVersion.m38clinit():void");
    }

    public static MixinVersion getInstance() {
        return INSTANCE;
    }
}
