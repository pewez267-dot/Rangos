package com.llamalad7.mixinextras.sugar.impl;

import org.spongepowered.asm.mixin.throwables.MixinException;

/* JADX INFO: loaded from: Henny Essentials-forge-1.21.1-1.0.4-H3-all.jar:META-INF/jarjar/mixinextras-forge-0.4.1.jar:META-INF/jars/MixinExtras-0.4.1.jar:com/llamalad7/mixinextras/sugar/impl/SugarApplicationException.class */
public class SugarApplicationException extends MixinException {
    public SugarApplicationException(String message) {
        super(message);
    }

    public SugarApplicationException(String message, Throwable cause) {
        super(message, cause);
    }
}
