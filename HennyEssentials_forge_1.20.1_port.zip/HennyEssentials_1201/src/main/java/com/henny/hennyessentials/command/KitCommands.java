package com.henny.hennyessentials.command;

import com.henny.hennyessentials.CommonClass;
import com.henny.hennyessentials.Constants;
import com.henny.hennyessentials.config.ConfigManager;
import com.henny.hennyessentials.data.KitData;
import com.henny.hennyessentials.data.PlayerData;
import com.henny.hennyessentials.data.objects.HEPlayer;
import com.henny.hennyessentials.data.objects.Kit;
import com.henny.hennyessentials.menu.KitCreationMenu;
import com.henny.hennyessentials.menu.KitEditMenu;
import com.henny.hennyessentials.menu.KitsMenu;
import com.henny.hennyessentials.permission.Permissions;
import com.henny.hennyessentials.util.TextUtils;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.GameProfileCache;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.jetbrains.annotations.Nullable;

public class KitCommands {
    public static List<LiteralArgumentBuilder<CommandSourceStack>> buildKitCommands() {
        ArrayList<LiteralArgumentBuilder<CommandSourceStack>> returnList = new ArrayList<>();
        LiteralArgumentBuilder<CommandSourceStack> kitCommand = Commands.literal("kit");
        kitCommand.then(Commands.argument("kitName", StringArgumentType.word()).suggests(KitCommands::suggestKitOptions).executes(KitCommands::executeGiveKit));
        kitCommand.then(Commands.literal("setCategory").then(Commands.argument("kitName", StringArgumentType.word()).suggests(KitCommands::suggestKitOptions).then(Commands.argument("kitCategory", StringArgumentType.word()).executes(KitCommands::executeSetKitCategory).requires(src -> {
            return ModCommands.getRequirements(src, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.KIT_SETCATEGORY_PERMISSION));
        }))));
        LiteralArgumentBuilder<CommandSourceStack> setDisplayIcon = Commands.literal("setDisplayIcon");
        setDisplayIcon.then(Commands.literal("kit").then(Commands.argument("kitName", StringArgumentType.word()).executes(KitCommands::executeSetKitDisplayIcon).requires(src2 -> {
            return ModCommands.getRequirements(src2, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.KIT_SETDISPLAYICON_PERMISSION));
        })));
        setDisplayIcon.then(Commands.literal("category").then(Commands.argument("categoryName", StringArgumentType.word()).suggests(KitCommands::suggestCategoryOptions).executes(KitCommands::executeSetCategoryDisplayIcon).requires(src3 -> {
            return ModCommands.getRequirements(src3, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.KIT_SETDISPLAYICON_PERMISSION));
        })));
        kitCommand.then(setDisplayIcon);
        LiteralArgumentBuilder<CommandSourceStack> createKitCommand = Commands.literal("createkit").then(Commands.argument("kitName", StringArgumentType.word()).then(Commands.argument("cooldownSeconds", IntegerArgumentType.integer()).executes(KitCommands::executeStartCreateKit).requires(src4 -> {
            return ModCommands.getRequirements(src4, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.KIT_CREATE_PERMISSION));
        })));
        createKitCommand.requires(src5 -> {
            return ModCommands.getRequirements(src5, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.KIT_CREATE_PERMISSION));
        });
        LiteralArgumentBuilder<CommandSourceStack> deleteKitCommand = Commands.literal("deletekit").then(Commands.argument("kitName", StringArgumentType.word()).executes(KitCommands::executeDeleteKit).requires(src6 -> {
            return ModCommands.getRequirements(src6, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.KIT_DELETE_PERMISSION));
        }));
        deleteKitCommand.requires(src7 -> {
            return ModCommands.getRequirements(src7, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.KIT_DELETE_PERMISSION));
        });
        LiteralArgumentBuilder<CommandSourceStack> editKitCommand = Commands.literal("editkit").then(Commands.argument("kitName", StringArgumentType.word()).executes(KitCommands::executeStartEditKit).requires(src8 -> {
            return ModCommands.getRequirements(src8, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.KIT_EDIT_PERMISSION));
        }));
        editKitCommand.requires(src9 -> {
            return ModCommands.getRequirements(src9, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.KIT_EDIT_PERMISSION));
        });
        LiteralArgumentBuilder<CommandSourceStack> listKitsCommand = Commands.literal("kits");
        listKitsCommand.executes(KitCommands::executeListKits).requires(src10 -> {
            return ModCommands.getPlayerRequirements(src10, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.KIT_LIST_PERMISSION));
        });
        listKitsCommand.then(Commands.argument("category", StringArgumentType.word()).suggests(KitCommands::suggestCategoryOptions).executes(KitCommands::executeListKits).requires(src11 -> {
            return ModCommands.getPlayerRequirements(src11, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.KIT_LIST_PERMISSION));
        }));
        returnList.add(createKitCommand);
        returnList.add(deleteKitCommand);
        returnList.add(editKitCommand);
        returnList.add(kitCommand);
        returnList.add(listKitsCommand);
        return returnList;
    }

    private static int executeSetKitDisplayIcon(CommandContext<CommandSourceStack> context) {
        String kitName = StringArgumentType.getString(context, "kitName");
        ItemStack item = ((CommandSourceStack) context.getSource()).getPlayer().getMainHandItem();
        if (item != null && !item.isEmpty() && KitData.getKitData(CommonClass.minecraftServer).kits.containsKey(kitName)) {
            KitData.getKitData(((CommandSourceStack) context.getSource()).getServer()).setKitDisplayItem(kitName, item);
            ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Set display icon for kit: " + kitName + " to: " + String.valueOf(BuiltInRegistries.ITEM.getKey(item.getItem()))));
            return 1;
        }
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Error setting display item."));
        return 1;
    }

    private static int executeSetCategoryDisplayIcon(CommandContext<CommandSourceStack> context) {
        String categoryName = StringArgumentType.getString(context, "categoryName");
        ItemStack item = ((CommandSourceStack) context.getSource()).getPlayer().getMainHandItem();
        if (item != null && !item.isEmpty()) {
            KitData.getKitData(((CommandSourceStack) context.getSource()).getServer()).setCategoryDisplayItem(categoryName, item);
            ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Set display icon for kit category: " + categoryName + " to: " + String.valueOf(BuiltInRegistries.ITEM.getKey(item.getItem()))));
            return 1;
        }
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Error setting display item."));
        return 1;
    }

    private static int executeSetKitCategory(CommandContext<CommandSourceStack> context) {
        String kitName = StringArgumentType.getString(context, "kitName");
        String category = StringArgumentType.getString(context, "kitCategory");
        KitData kitData = KitData.getKitData(CommonClass.minecraftServer);
        if (!kitData.kits.containsKey(kitName)) {
            ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Couldn't find kit with that name."));
            return 1;
        }
        kitData.kits.get(kitName).category = category;
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Changed kit category to: " + category));
        return 1;
    }

    private static int executeGiveKit(CommandContext<CommandSourceStack> context) {
        String kitName = StringArgumentType.getString(context, "kitName");
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        ServerPlayer player = ((CommandSourceStack) context.getSource()).getPlayer();
        KitData kitData = KitData.getKitData(player.server);
        if (!kitData.kits.containsKey(kitName)) {
            player.sendSystemMessage(TextUtils.formatMessage("Could not find kit with the name: '" + kitName + "'"));
            return 1;
        }
        if (ConfigManager.CONFIG.permissionConfigs.permissionsEnabled && !Permissions.permissionCheck(player.getUUID(), "kit." + kitName, ((CommandSourceStack) context.getSource()).getServer())) {
            player.sendSystemMessage(TextUtils.formatMessage("You do not have the required permission: 'kit." + kitName + "' to redeem this kit."));
            return 1;
        }
        PlayerData allData = PlayerData.getUserData(player.server);
        HEPlayer playerData = allData.HEPlayerData.getOrDefault(player.getUUID(), new HEPlayer());
        boolean canBypassCooldown = ConfigManager.CONFIG.permissionConfigs.permissionsEnabled && Permissions.permissionCheck(player.getUUID(), "kit." + kitName + ".nocooldown", player.server);
        if (playerData != null && !canBypassCooldown) {
            Long cooldown = playerData.kitCooldowns.getOrDefault(kitName, 0L);
            long timeLeft = cooldown.longValue() - System.currentTimeMillis();
            if (timeLeft > 0) {
                player.sendSystemMessage(TextUtils.formatAndHighlight("You need to wait: " + TextUtils.readableDuration(timeLeft) + " before redeeming this kit again."));
                return 1;
            }
        }
        Kit kit = kitData.kits.get(kitName);
        long emptySlots = player.getInventory().items.stream().filter(item -> {
            return item.isEmpty();
        }).count();
        if (kit.items.size() <= emptySlots) {
            kit.items.forEach(itemStack -> {
                player.getInventory().add(itemStack.copy());
            });
            allData.updateKitCooldown(player.getUUID(), kitName, kit.cooldownSeconds);
            if (ConfigManager.CONFIG.commandConfigs.kitConfigs.claimingKitsPlaysSound) {
                player.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.AMBIENT, 0.5f, 1.0f);
                return 1;
            }
            return 1;
        }
        player.sendSystemMessage(TextUtils.formatMessage("You do not have enough free space in your inventory to redeem this kit."));
        return 1;
    }

    public static void giveKitToPlayer(ServerPlayer player, String kitName) {
        KitData kitData = KitData.getKitData(player.server);
        if (!kitData.kits.containsKey(kitName)) {
            player.sendSystemMessage(TextUtils.formatMessage("Could not find kit with the name: '" + kitName + "'"));
            return;
        }
        if (ConfigManager.CONFIG.permissionConfigs.permissionsEnabled && !Permissions.permissionCheck(player.getUUID(), "kit." + kitName, CommonClass.minecraftServer)) {
            player.sendSystemMessage(TextUtils.formatMessage("You do not have the required permission: 'kit." + kitName + "' to redeem this kit."));
            return;
        }
        PlayerData allData = PlayerData.getUserData(player.server);
        HEPlayer playerData = allData.HEPlayerData.getOrDefault(player.getUUID(), new HEPlayer());
        boolean canBypassCooldown = ConfigManager.CONFIG.permissionConfigs.permissionsEnabled && Permissions.permissionCheck(player.getUUID(), "kit." + kitName + ".nocooldown", player.server);
        if (playerData != null && !canBypassCooldown) {
            Long cooldown = playerData.kitCooldowns.getOrDefault(kitName, 0L);
            long timeLeft = cooldown.longValue() - System.currentTimeMillis();
            if (timeLeft > 0) {
                player.sendSystemMessage(TextUtils.formatAndHighlight("You need to wait: " + TextUtils.readableDuration(timeLeft) + " before redeeming this kit again."));
                return;
            }
        }
        Kit kit = KitData.getKitData(CommonClass.minecraftServer).kits.get(kitName);
        long emptySlots = player.getInventory().items.stream().filter(item -> {
            return item.isEmpty();
        }).count();
        if (kit.items.size() <= emptySlots) {
            kit.items.forEach(itemStack -> {
                player.getInventory().add(itemStack.copy());
            });
            allData.updateKitCooldown(player.getUUID(), kitName, kit.cooldownSeconds);
            if (ConfigManager.CONFIG.commandConfigs.kitConfigs.claimingKitsPlaysSound) {
                player.playNotifySound(SoundEvents.PLAYER_LEVELUP, SoundSource.AMBIENT, 0.5f, 1.0f);
                return;
            }
            return;
        }
        player.sendSystemMessage(TextUtils.formatMessage("You do not have enough free space in your inventory to redeem this kit."));
    }

    private static int executeStartCreateKit(CommandContext<CommandSourceStack> context) {
        String kitName = StringArgumentType.getString(context, "kitName");
        int cooldown = IntegerArgumentType.getInteger(context, "cooldownSeconds");
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        ServerPlayer player = ((CommandSourceStack) context.getSource()).getPlayer();
        player.openMenu(new SimpleMenuProvider((id, inv, p) -> {
            return new KitCreationMenu(id, inv, new SimpleContainer(27), kitName, cooldown);
        }, Component.literal("Creating kit: " + kitName)));
        return 1;
    }

    private static int executeStartEditKit(CommandContext<CommandSourceStack> context) {
        String kitName = StringArgumentType.getString(context, "kitName");
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        ServerPlayer player = ((CommandSourceStack) context.getSource()).getPlayer();
        KitData kitData = KitData.getKitData(((CommandSourceStack) context.getSource()).getServer());
        if (kitData.kits.containsKey(kitName)) {
            Kit kit = kitData.kits.get(kitName);
            player.openMenu(new SimpleMenuProvider((id, inv, p) -> {
                return new KitEditMenu(id, inv, new SimpleContainer(27), kitName, new ArrayList<ItemStack>() { // from class: com.henny.hennyessentials.command.KitCommands.1
                    {
                        addAll(kit.items);
                    }
                });
            }, Component.literal("Editing kit: " + kitName)));
            return 1;
        }
        player.sendSystemMessage(TextUtils.formatMessage("Can't find kit with name: " + kitName));
        return 1;
    }

    private static int executeDeleteKit(CommandContext<CommandSourceStack> context) {
        String kitName = StringArgumentType.getString(context, "kitName");
        KitData kitData = KitData.getKitData(((CommandSourceStack) context.getSource()).getServer());
        if (kitData.kits.containsKey(kitName)) {
            kitData.removeKit(kitName);
            ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Kit: " + kitName + " was removed."));
            return 1;
        }
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Could not find kit with name: " + kitName));
        return 1;
    }

    private static int executeListKits(CommandContext<CommandSourceStack> context) {
        if (ConfigManager.CONFIG.commandConfigs.kitConfigs.shouldUseInventoryMenuForKits) {
            openKitsMenu(((CommandSourceStack) context.getSource()).getPlayer());
            return 1;
        }
        ArrayList<Component> kitComponentList = new ArrayList<>();
        MutableComponent title = Component.literal("~ KIT LIST ~").withStyle(ChatFormatting.GREEN);
        for (Map.Entry<String, Kit> entry : KitData.getKitData(((CommandSourceStack) context.getSource()).getServer()).kits.entrySet()) {
            Kit kit = entry.getValue();
            Style style = Style.EMPTY.withColor(ChatFormatting.GOLD).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal("Click here to redeem kit: " + kit.name))).withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/" + ModCommands.BASE_COMMAND_ALIAS + " kit " + kit.name));
            MutableComponent comp = Component.literal("~ " + kit.name).withStyle(style);
            if (ConfigManager.CONFIG.permissionConfigs.permissionsEnabled) {
                if (((CommandSourceStack) context.getSource()).isPlayer() && Permissions.permissionCheck(((CommandSourceStack) context.getSource()).getPlayer().getUUID(), "kit." + kit.name, ((CommandSourceStack) context.getSource()).getServer())) {
                    kitComponentList.add(comp);
                }
            } else {
                kitComponentList.add(comp);
            }
        }
        ((CommandSourceStack) context.getSource()).sendSystemMessage(title);
        for (Component component : kitComponentList) {
            ((CommandSourceStack) context.getSource()).sendSystemMessage(component);
        }
        return 1;
    }

    public static ItemStack createCustomPlayerHead(String textureUrl, String displayName) {
        ItemStack head = new ItemStack(Items.PLAYER_HEAD);
        // 1.20.1: skull profiles use SkullOwner NBT instead of DataComponents.PROFILE
        byte[] textureBytes = textureUrl.getBytes();
        UUID uuid = UUID.nameUUIDFromBytes(textureBytes);
        String skinTextureNBT = String.format("{\"textures\":{\"SKIN\":{\"url\":\"http://textures.minecraft.net/texture/%s\"}}}", textureUrl);
        String encodedURL = Base64.getEncoder().encodeToString(skinTextureNBT.getBytes());
        CompoundTag skullOwner = new CompoundTag();
        // UUID as int array (MC 1.16+ format)
        skullOwner.putIntArray("Id", new int[]{
            (int)(uuid.getMostSignificantBits() >> 32),
            (int)(uuid.getMostSignificantBits()),
            (int)(uuid.getLeastSignificantBits() >> 32),
            (int)(uuid.getLeastSignificantBits())
        });
        skullOwner.putString("Name", "name");
        CompoundTag properties = new CompoundTag();
        ListTag texturesList = new ListTag();
        CompoundTag textureEntry = new CompoundTag();
        textureEntry.putString("Value", encodedURL);
        texturesList.add(textureEntry);
        properties.put("textures", texturesList);
        skullOwner.put("Properties", properties);
        CompoundTag itemNBT = head.getOrCreateTag();
        itemNBT.put("SkullOwner", skullOwner);
        head.setTag(itemNBT);
        // 1.20.1: use setHoverName instead of DataComponents.CUSTOM_NAME
        if (!displayName.isBlank()) {
            head.setHoverName(Component.literal(displayName));
        }
        return head;
    }

    public static void openKitsMenu(ServerPlayer player) {
        new SimpleContainer(90);
        createCustomPlayerHead("45ca82b79198c452e105e9b6eb4da58c6fabd0a30307ea5eb183a9044b567786", "Warp 1");
        createCustomPlayerHead("a7d5eb0aea5d61ba3ff4996416a90096a9d77609ebcd3b308f906ae888a45f6d", "Warp 2");
        createCustomPlayerHead("af334488f13e6a6a4894f33445332641b3e5e112fe0b17ceada6cd514765325b", "Warp 3");
        player.openMenu(new MenuProvider() { // from class: com.henny.hennyessentials.command.KitCommands.2
            @Nullable
            public AbstractContainerMenu createMenu(int i, Inventory inventory, Player player2) {
                return new KitsMenu(i, inventory, KitData.getKitData(CommonClass.minecraftServer));
            }

            public Component getDisplayName() {
                return Component.literal("Kits Menu");
            }
        });
    }

    private static CompletableFuture<Suggestions> suggestKitOptions(CommandContext<CommandSourceStack> context, SuggestionsBuilder builder) {
        if (CommonClass.minecraftServer != null) {
            KitData data = KitData.getKitData(CommonClass.minecraftServer);
            for (String kitName : data.kits.keySet()) {
                if (ConfigManager.CONFIG.permissionConfigs.permissionsEnabled) {
                    if (((CommandSourceStack) context.getSource()).isPlayer() && Permissions.permissionCheck(((CommandSourceStack) context.getSource()).getPlayer().getUUID(), "kit." + kitName, CommonClass.minecraftServer)) {
                        builder.suggest(kitName);
                    }
                } else {
                    builder.suggest(kitName);
                }
            }
        }
        return builder.buildFuture();
    }

    private static CompletableFuture<Suggestions> suggestCategoryOptions(CommandContext<CommandSourceStack> context, SuggestionsBuilder builder) {
        if (CommonClass.minecraftServer != null) {
            KitData data = KitData.getKitData(CommonClass.minecraftServer);
            HashSet<String> categories = new HashSet<>();
            for (Map.Entry<String, Kit> kit : data.kits.entrySet()) {
                categories.add(kit.getValue().category);
            }
            Objects.requireNonNull(builder);
            categories.forEach(builder::suggest);
        }
        return builder.buildFuture();
    }
}
