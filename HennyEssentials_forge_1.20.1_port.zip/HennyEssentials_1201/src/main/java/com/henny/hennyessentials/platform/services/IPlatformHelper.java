package com.henny.hennyessentials.platform.services;

public interface IPlatformHelper {
    String getPlatformName();

    boolean isModLoaded(String str);

    boolean isDevelopmentEnvironment();

    default String getEnvironmentName() {
        return isDevelopmentEnvironment() ? "development" : "production";
    }
}
