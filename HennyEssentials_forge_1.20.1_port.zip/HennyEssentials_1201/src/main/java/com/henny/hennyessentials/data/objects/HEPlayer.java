package com.henny.hennyessentials.data.objects;

import java.util.HashMap;
import java.util.Map;

public class HEPlayer {
    public Map<String, Long> kitCooldowns;
    public Map<String, Long> warpCooldowns;
    public Map<String, Long> commandCooldowns;
    public Map<String, String> playerInfo;
    public Map<String, Home> homeList;

    public HEPlayer() {
        this.kitCooldowns = new HashMap();
        this.warpCooldowns = new HashMap();
        this.commandCooldowns = new HashMap();
        this.playerInfo = new HashMap();
        this.homeList = new HashMap();
    }

    public HEPlayer(Map<String, Long> kitCooldowns, Map<String, Long> warpCooldowns, Map<String, Long> commandCooldowns, Map<String, String> playerInfo, Map<String, Home> homeList) {
        this.kitCooldowns = kitCooldowns;
        this.warpCooldowns = warpCooldowns;
        this.commandCooldowns = commandCooldowns;
        this.playerInfo = playerInfo;
        this.homeList = homeList;
    }

    public void updateKitCooldown(String kitName, int kitCooldownSeconds) {
        this.kitCooldowns.put(kitName, Long.valueOf(System.currentTimeMillis() + (((long) kitCooldownSeconds) * 1000)));
    }

    public void updatePlayerInfo(String key, String value) {
        this.playerInfo.put(key, value);
    }
}
