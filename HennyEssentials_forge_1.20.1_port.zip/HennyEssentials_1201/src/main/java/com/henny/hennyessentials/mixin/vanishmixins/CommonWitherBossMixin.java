package com.henny.hennyessentials.mixin.vanishmixins;

import com.henny.hennyessentials.CommonClass;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({WitherBoss.class})
public class CommonWitherBossMixin {
    @Inject(method = {"performRangedAttack"}, at = {@At("HEAD")}, cancellable = true)
    private void cancelAttackOnVanished(int head, LivingEntity target, CallbackInfo ci) {
        if (target instanceof ServerPlayer) {
            ServerPlayer player = (ServerPlayer) target;
            if (CommonClass.playersInVanish.getOrDefault(player.getUUID(), false).booleanValue()) {
                ci.cancel();
            }
        }
    }

    @Inject(method = {"setAlternativeTarget"}, at = {@At("HEAD")}, cancellable = true)
    private void cancelTargetSet(int head, int entityId, CallbackInfo ci) {
        Level level = ((WitherBoss) this).level();
        ServerPlayer entity = level.getEntity(entityId);
        if (entity instanceof ServerPlayer) {
            ServerPlayer player = entity;
            if (CommonClass.playersInVanish.getOrDefault(player.getUUID(), false).booleanValue()) {
                ci.cancel();
            }
        }
    }
}
