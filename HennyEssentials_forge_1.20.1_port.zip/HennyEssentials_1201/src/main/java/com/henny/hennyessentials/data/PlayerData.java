package com.henny.hennyessentials.data;

import com.henny.hennyessentials.CommonClass;
import com.henny.hennyessentials.data.objects.Ban;
import com.henny.hennyessentials.data.objects.HEPlayer;
import com.henny.hennyessentials.data.objects.Home;
import com.henny.hennyessentials.data.objects.Mute;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.datafix.DataFixTypes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.saveddata.SavedData;
import org.jetbrains.annotations.Nullable;

public class PlayerData extends SavedData {
    public Map<UUID, HEPlayer> HEPlayerData;
    public Map<UUID, Ban> bannedPlayers;
    public Map<UUID, Mute> mutedPlayers;

    public PlayerData() {
        this.bannedPlayers = new HashMap();
        this.mutedPlayers = new HashMap();
        this.HEPlayerData = new HashMap();
        this.bannedPlayers = new HashMap();
        this.mutedPlayers = new HashMap();
    }

    public PlayerData(Map<UUID, HEPlayer> HEPlayerData, Map<UUID, Ban> banMap, Map<UUID, Mute> muteMap) {
        this.bannedPlayers = new HashMap();
        this.mutedPlayers = new HashMap();
        this.HEPlayerData = HEPlayerData;
        this.bannedPlayers = banMap;
        this.mutedPlayers = muteMap;
    }

    public static SavedData.Factory<PlayerData> factory() {
        return new SavedData.Factory<>(PlayerData::new, PlayerData::load, DataFixTypes.LEVEL);
    }

    public CompoundTag save(CompoundTag compoundTag, HolderLookup.Provider provider) {
        CompoundTag parentPlayerData = new CompoundTag();
        CompoundTag parentBanData = new CompoundTag();
        CompoundTag parentMuteData = new CompoundTag();
        for (Map.Entry<UUID, HEPlayer> entry : this.HEPlayerData.entrySet()) {
            CompoundTag individualPlayerTag = new CompoundTag();
            UUID uuid = entry.getKey();
            HEPlayer playerData = entry.getValue();
            CompoundTag kitCooldownList = new CompoundTag();
            CompoundTag warpCooldownList = new CompoundTag();
            CompoundTag commandCooldownList = new CompoundTag();
            CompoundTag playerInfoMap = new CompoundTag();
            CompoundTag playerHomes = new CompoundTag();
            for (Map.Entry<String, Long> entry2 : playerData.kitCooldowns.entrySet()) {
                kitCooldownList.putLong(entry2.getKey(), entry2.getValue().longValue());
            }
            for (Map.Entry<String, Home> homeEntry : playerData.homeList.entrySet()) {
                CompoundTag homeTag = new CompoundTag();
                Home home = homeEntry.getValue();
                homeTag.put("blockPos", NbtUtils.writeBlockPos(home.pos.pos()));
                homeTag.putString("name", home.name);
                homeTag.putString("dimension", home.pos.dimension().location().toString());
                playerHomes.put(home.name, homeTag);
            }
            for (Map.Entry<String, String> pInfoEntry : playerData.playerInfo.entrySet()) {
                playerInfoMap.putString(pInfoEntry.getKey(), pInfoEntry.getValue());
            }
            individualPlayerTag.put("kitCooldowns", kitCooldownList);
            individualPlayerTag.put("warpCooldowns", warpCooldownList);
            individualPlayerTag.put("commandCooldowns", commandCooldownList);
            individualPlayerTag.put("playerInfoMap", playerInfoMap);
            individualPlayerTag.put("playerHomes", playerHomes);
            parentPlayerData.put(uuid.toString(), individualPlayerTag);
        }
        compoundTag.put("playerData", parentPlayerData);
        for (Map.Entry<UUID, Ban> entry3 : this.bannedPlayers.entrySet()) {
            CompoundTag banInfo = new CompoundTag();
            banInfo.putUUID("uuid", entry3.getKey());
            banInfo.putString("reason", entry3.getValue().banReason);
            banInfo.putLong("expiry", entry3.getValue().banExpiry);
            parentBanData.put(entry3.getKey().toString(), banInfo);
        }
        compoundTag.put("banData", parentBanData);
        for (Map.Entry<UUID, Mute> entry4 : this.mutedPlayers.entrySet()) {
            CompoundTag muteInfo = new CompoundTag();
            muteInfo.putUUID("uuid", entry4.getKey());
            muteInfo.putString("reason", entry4.getValue().muteReason);
            muteInfo.putLong("expiry", entry4.getValue().muteExpiry);
            parentMuteData.put(entry4.getKey().toString(), muteInfo);
        }
        compoundTag.put("muteData", parentMuteData);
        return compoundTag;
    }

    private static PlayerData load(CompoundTag compoundTag, HolderLookup.Provider provider) {
        Map<UUID, HEPlayer> tempPlayerData = new HashMap<>();
        Map<UUID, Ban> tempBanMap = new HashMap<>();
        Map<UUID, Mute> tempMuteMap = new HashMap<>();
        CompoundTag parentPlayerData = compoundTag.getCompound("playerData");
        CompoundTag parentBanData = compoundTag.getCompound("banData");
        CompoundTag parentMuteData = compoundTag.getCompound("muteData");
        for (String uuid : parentPlayerData.getAllKeys()) {
            CompoundTag specificPlayerData = parentPlayerData.get(uuid);
            CompoundTag kitCooldowns = specificPlayerData.getCompound("kitCooldowns");
            CompoundTag playerHomesTag = specificPlayerData.getCompound("playerHomes");
            specificPlayerData.getCompound("warpCooldowns");
            specificPlayerData.getCompound("commandCooldowns");
            CompoundTag playerInfo = specificPlayerData.getCompound("playerInfoMap");
            HashMap<String, Long> kitCooldownsMap = new HashMap<>();
            HashMap<String, Long> warpCooldownsMap = new HashMap<>();
            HashMap<String, Long> commandCooldownsMap = new HashMap<>();
            HashMap<String, String> playerInfoMap = new HashMap<>();
            HashMap<String, Home> playerHomes = new HashMap<>();
            for (String entry : kitCooldowns.getAllKeys()) {
                kitCooldownsMap.put(entry, Long.valueOf(kitCooldowns.getLong(entry)));
            }
            for (String pInfo : playerInfo.getAllKeys()) {
                playerInfoMap.put(pInfo, playerInfo.getString(pInfo));
            }
            for (String home : playerHomesTag.getAllKeys()) {
                CompoundTag specificHomeTag = playerHomesTag.getCompound(home);
                Optional<BlockPos> pos = NbtUtils.readBlockPos(specificHomeTag, "blockPos");
                String name = specificHomeTag.getString("name");
                ResourceKey<Level> dim = ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(specificHomeTag.getString("dimension")));
                GlobalPos gPos = GlobalPos.of(dim, pos.get());
                playerHomes.put(name, new Home(name, gPos));
            }
            tempPlayerData.put(UUID.fromString(uuid), new HEPlayer(kitCooldownsMap, warpCooldownsMap, commandCooldownsMap, playerInfoMap, playerHomes));
        }
        for (String uuid2 : parentBanData.getAllKeys()) {
            CompoundTag specificPlayerBanData = parentBanData.getCompound(uuid2);
            tempBanMap.put(UUID.fromString(uuid2), new Ban(UUID.fromString(uuid2), specificPlayerBanData.getLong("expiry"), specificPlayerBanData.getString("reason")));
        }
        for (String uuid3 : parentMuteData.getAllKeys()) {
            CompoundTag specificPlayerMuteData = parentMuteData.getCompound(uuid3);
            tempMuteMap.put(UUID.fromString(uuid3), new Mute(UUID.fromString(uuid3), specificPlayerMuteData.getLong("expiry"), specificPlayerMuteData.getString("reason")));
        }
        return new PlayerData(tempPlayerData, tempBanMap, tempMuteMap);
    }

    public static PlayerData getUserData(MinecraftServer minecraftServer) {
        return (PlayerData) minecraftServer.overworld().getDataStorage().computeIfAbsent(factory(), "hennyessentials-userdata");
    }

    public static PlayerData getUserData() {
        return (PlayerData) CommonClass.minecraftServer.overworld().getDataStorage().computeIfAbsent(factory(), "hennyessentials-userdata");
    }

    public static HEPlayer getSpecificUserData(MinecraftServer minecraftServer, UUID playerUUID) {
        return getUserData(minecraftServer).HEPlayerData.getOrDefault(playerUUID, new HEPlayer());
    }

    public void updatePlayerInfo(UUID playerUUID, String key, String value) {
        Map<UUID, HEPlayer> alldata = getUserData(CommonClass.minecraftServer).HEPlayerData;
        if (!alldata.containsKey(playerUUID)) {
            alldata.put(playerUUID, new HEPlayer());
        }
        HEPlayer pData = alldata.get(playerUUID);
        pData.playerInfo.put(key, value);
        setDirty();
    }

    public String getPlayerInfoValue(UUID playerUUID, String key) {
        Map<UUID, HEPlayer> alldata = getUserData(CommonClass.minecraftServer).HEPlayerData;
        if (!alldata.containsKey(playerUUID)) {
            alldata.put(playerUUID, new HEPlayer());
        }
        HEPlayer pData = alldata.get(playerUUID);
        if (pData.playerInfo.containsKey(key)) {
            return pData.playerInfo.get(key);
        }
        return "";
    }

    @Nullable
    public Home getPlayerHome(UUID playerUUID, String homeName) {
        return getUserData().HEPlayerData.getOrDefault(playerUUID, new HEPlayer()).homeList.getOrDefault(homeName.toLowerCase(), null);
    }

    public int countPlayerHomes(UUID playerUUID) {
        return getUserData().HEPlayerData.getOrDefault(playerUUID, new HEPlayer()).homeList.size();
    }

    public Collection<Home> listPlayerHomes(UUID playerUUID) {
        return getUserData().HEPlayerData.getOrDefault(playerUUID, new HEPlayer()).homeList.values();
    }

    public boolean addPlayerHome(UUID playerUUID, Home home) {
        Map<UUID, HEPlayer> alldata = getUserData(CommonClass.minecraftServer).HEPlayerData;
        home.name = home.name.toLowerCase();
        if (!alldata.containsKey(playerUUID)) {
            alldata.put(playerUUID, new HEPlayer());
        }
        HEPlayer pData = alldata.get(playerUUID);
        if (pData.homeList.containsKey(home.name)) {
            return false;
        }
        pData.homeList.put(home.name, home);
        return true;
    }

    public boolean removePlayerHome(UUID playerUUID, String homeName) {
        Map<UUID, HEPlayer> alldata = getUserData(CommonClass.minecraftServer).HEPlayerData;
        if (!alldata.containsKey(playerUUID)) {
            alldata.put(playerUUID, new HEPlayer());
        }
        HEPlayer pData = alldata.get(playerUUID);
        if (!pData.homeList.containsKey(homeName)) {
            return false;
        }
        pData.homeList.remove(homeName);
        return true;
    }

    public void updateKitCooldown(UUID playerUUID, String kitName, int kitCooldownSeconds) {
        Map<UUID, HEPlayer> allData = getUserData(CommonClass.minecraftServer).HEPlayerData;
        if (!allData.containsKey(playerUUID)) {
            allData.put(playerUUID, new HEPlayer());
        }
        HEPlayer pData = allData.get(playerUUID);
        pData.updateKitCooldown(kitName, kitCooldownSeconds);
        setDirty();
    }

    public void updateMuteList(Mute mute) {
        this.mutedPlayers.put(mute.mutedPlayerUUID, mute);
        setDirty();
    }

    public void updateBanList(Ban ban) {
        this.bannedPlayers.put(ban.bannedPlayerUUID, ban);
        setDirty();
    }

    public void unmutePlayer(UUID uuid) {
        this.mutedPlayers.remove(uuid);
        setDirty();
    }

    public void unbanPlayer(UUID uuid) {
        this.bannedPlayers.remove(uuid);
        setDirty();
    }

    public void purgeExpiredBansMutes() {
        this.bannedPlayers.entrySet().removeIf(entry -> {
            return ((Ban) entry.getValue()).banExpiry != 0 && ((Ban) entry.getValue()).banExpiry < System.currentTimeMillis();
        });
        this.mutedPlayers.entrySet().removeIf(entry2 -> {
            return ((Mute) entry2.getValue()).muteExpiry != 0 && ((Mute) entry2.getValue()).muteExpiry < System.currentTimeMillis();
        });
        setDirty();
    }
}
