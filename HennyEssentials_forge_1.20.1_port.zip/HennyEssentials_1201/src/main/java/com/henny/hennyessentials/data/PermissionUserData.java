package com.henny.hennyessentials.data;

import com.henny.hennyessentials.CommonClass;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.datafix.DataFixTypes;
import net.minecraft.world.level.saveddata.SavedData;

public class PermissionUserData extends SavedData {
    public Map<UUID, List<String>> userPermissions;
    public Map<UUID, Component> userPrefixes;
    public Map<UUID, Component> userSuffixes;

    public PermissionUserData(Map<UUID, List<String>> userPermissions, Map<UUID, Component> userPrefixes, Map<UUID, Component> userSuffixes) {
        this.userPermissions = userPermissions;
        this.userPrefixes = userPrefixes;
        this.userSuffixes = userSuffixes;
    }

    public PermissionUserData() {
        this.userPermissions = new HashMap();
        this.userPrefixes = new HashMap();
        this.userSuffixes = new HashMap();
    }

    public static SavedData.Factory<PermissionUserData> factory() {
        return new SavedData.Factory<>(PermissionUserData::new, PermissionUserData::load, DataFixTypes.LEVEL);
    }

    private static PermissionUserData load(CompoundTag compoundTag, HolderLookup.Provider provider) {
        Map<UUID, List<String>> allUserPermsTempList = new HashMap<>();
        Map<UUID, Component> allUserPrefixesList = new HashMap<>();
        Map<UUID, Component> allUserSuffixesList = new HashMap<>();
        CompoundTag userPermsTag = compoundTag.getCompound("userPerms");
        CompoundTag userPrefixesTag = compoundTag.getCompound("userPrefixes");
        CompoundTag userSuffixesTag = compoundTag.getCompound("userSuffixes");
        for (String uuid : userPermsTag.getAllKeys()) {
            ArrayList<String> specificGroupPermsTempList = new ArrayList<>();
            ListTag specificGroupPermsNBTList = userPermsTag.get(uuid);
            specificGroupPermsNBTList.forEach(tag -> {
                specificGroupPermsTempList.add(tag.getAsString());
            });
            allUserPermsTempList.put(UUID.fromString(uuid), specificGroupPermsTempList);
        }
        for (String userUUID : userPrefixesTag.getAllKeys()) {
            String prefix = userPrefixesTag.getString(userUUID);
            allUserPrefixesList.put(UUID.fromString(userUUID), Component.Serializer.fromJsonLenient(prefix, provider));
        }
        for (String userUUID2 : userSuffixesTag.getAllKeys()) {
            String suffix = userSuffixesTag.getString(userUUID2);
            allUserSuffixesList.put(UUID.fromString(userUUID2), Component.Serializer.fromJsonLenient(suffix, provider));
        }
        return new PermissionUserData(allUserPermsTempList, allUserPrefixesList, allUserSuffixesList);
    }

    public CompoundTag save(CompoundTag compoundTag, HolderLookup.Provider provider) {
        CompoundTag userPerms = new CompoundTag();
        CompoundTag userPrefxs = new CompoundTag();
        CompoundTag userSuffxs = new CompoundTag();
        for (Map.Entry<UUID, List<String>> entry : this.userPermissions.entrySet()) {
            ListTag individualUserPerms = new ListTag();
            for (String individualPermNode : entry.getValue()) {
                individualUserPerms.add(StringTag.valueOf(individualPermNode));
            }
            userPerms.put(String.valueOf(entry.getKey()), individualUserPerms);
        }
        for (Map.Entry<UUID, Component> entry2 : this.userPrefixes.entrySet()) {
            Component prefix = entry2.getValue();
            String prefixString = Component.Serializer.toJson(prefix, provider);
            userPrefxs.put(String.valueOf(entry2.getKey()), StringTag.valueOf(prefixString));
        }
        for (Map.Entry<UUID, Component> entry3 : this.userSuffixes.entrySet()) {
            Component suffix = entry3.getValue();
            String suffixString = Component.Serializer.toJson(suffix, provider);
            userSuffxs.put(String.valueOf(entry3.getKey()), StringTag.valueOf(suffixString));
        }
        compoundTag.put("userPerms", userPerms);
        compoundTag.put("userPrefixes", userPrefxs);
        compoundTag.put("userSuffixes", userSuffxs);
        return compoundTag;
    }

    public static List<String> getPermissionsForUser(UUID uuid) {
        return getPermissionUserData(CommonClass.minecraftServer).userPermissions.get(uuid);
    }

    public void addUserPermission(UUID user, String permission) {
        String permission2 = permission.toLowerCase();
        if (!this.userPermissions.containsKey(user)) {
            this.userPermissions.put(user, new ArrayList());
        }
        List<String> userPermList = this.userPermissions.get(user);
        if (!userPermList.contains(permission2)) {
            userPermList.add(permission2);
        }
        this.userPermissions.put(user, userPermList);
        setDirty();
    }

    public void removeUserPermission(UUID user, String permission) {
        if (!this.userPermissions.containsKey(user)) {
            this.userPermissions.put(user, new ArrayList());
        }
        List<String> userPermList = this.userPermissions.get(user);
        userPermList.removeIf(next -> {
            return Objects.equals(next, permission);
        });
        this.userPermissions.put(user, userPermList);
        setDirty();
    }

    public static boolean permissionCheckUser(UUID uuid, String permission, MinecraftServer minecraftServer) {
        PermissionUserData perms = getPermissionUserData(minecraftServer);
        if (!perms.userPermissions.containsKey(uuid)) {
            return false;
        }
        List<String> userPerms = perms.userPermissions.get(uuid);
        if (userPerms.contains(permission)) {
            return true;
        }
        String[] parts = permission.split("\\.");
        if (parts.length >= 2) {
            String commandWildcard = parts[0] + "." + parts[1] + ".*";
            if (userPerms.contains(commandWildcard)) {
                return true;
            }
        }
        if (userPerms.contains(parts[0] + ".*")) {
            return true;
        }
        return false;
    }

    public static String getUserHighestGroup(UUID uuid, MinecraftServer minecraftServer) {
        PermissionUserData perms = getPermissionUserData(minecraftServer);
        if (!perms.userPermissions.containsKey(uuid)) {
            return "";
        }
        List<String> userGroups = perms.userPermissions.get(uuid).stream().filter(s -> {
            return s.startsWith("group.");
        }).toList();
        return PermissionGroupData.findHighestWeightedGroup(userGroups, minecraftServer).orElse("");
    }

    public static MutableComponent getChatPrefix(UUID uuid, MinecraftServer minecraftServer) {
        List<String> userGroups = getAllUserGroupMemberships(uuid);
        Map<Integer, Component> prefixes = new HashMap<>();
        for (String userGroup : userGroups) {
            PermissionGroupData.getGroupPrefix(userGroup, minecraftServer).ifPresent(component -> {
                prefixes.put(Integer.valueOf(PermissionGroupData.getGroupWeight(userGroup, minecraftServer)), component);
            });
        }
        int userPrefixWeight = 0;
        for (String perm : getPermissionUserData(minecraftServer).userPermissions.getOrDefault(uuid, List.of(""))) {
            if (perm.startsWith("weight.")) {
                userPrefixWeight = Integer.valueOf(perm.replace("weight.", "")).intValue();
            }
        }
        prefixes.put(Integer.valueOf(userPrefixWeight), getPermissionUserData(minecraftServer).userPrefixes.getOrDefault(uuid, Component.literal("")));
        Optional map = prefixes.entrySet().stream().filter(entry -> {
            return !((Component) entry.getValue()).getString().isBlank();
        }).max(Map.Entry.comparingByKey()).map((v0) -> {
            return v0.getValue();
        });
        MutableComponent prefixComp = Component.literal("");
        Objects.requireNonNull(prefixComp);
        map.ifPresent(prefixComp::append);
        return prefixComp;
    }

    public static MutableComponent getChatSuffix(UUID uuid, MinecraftServer minecraftServer) {
        List<String> userGroups = getAllUserGroupMemberships(uuid);
        Map<Integer, Component> suffixes = new HashMap<>();
        for (String userGroup : userGroups) {
            PermissionGroupData.getGroupSuffix(userGroup, minecraftServer).ifPresent(component -> {
                suffixes.put(Integer.valueOf(PermissionGroupData.getGroupWeight(userGroup, minecraftServer)), component);
            });
        }
        int userSuffixWeight = 0;
        for (String perm : getPermissionUserData(minecraftServer).userPermissions.getOrDefault(uuid, List.of(""))) {
            if (perm.startsWith("weight.")) {
                userSuffixWeight = Integer.valueOf(perm.replace("weight.", "")).intValue();
            }
        }
        suffixes.put(Integer.valueOf(userSuffixWeight), getPermissionUserData(minecraftServer).userSuffixes.getOrDefault(uuid, Component.literal("")));
        Optional map = suffixes.entrySet().stream().filter(entry -> {
            return !((Component) entry.getValue()).getString().isBlank();
        }).max(Map.Entry.comparingByKey()).map((v0) -> {
            return v0.getValue();
        });
        MutableComponent suffixComp = Component.literal("");
        Objects.requireNonNull(suffixComp);
        map.ifPresent(suffixComp::append);
        return suffixComp;
    }

    public static List<String> getAllUserGroupMemberships(UUID uuid) {
        PermissionUserData perms = getPermissionUserData(CommonClass.minecraftServer);
        if (!perms.userPermissions.containsKey(uuid)) {
            return List.of();
        }
        return perms.userPermissions.get(uuid).stream().filter(s -> {
            return s.startsWith("group.");
        }).map(s2 -> {
            return s2.replace("group.", "");
        }).toList();
    }

    public void addUserPrefix(UUID userUUID, Component prefix) {
        this.userPrefixes.put(userUUID, prefix);
        setDirty();
    }

    public void removeUserPrefix(UUID userUUID) {
        this.userPrefixes.remove(userUUID);
        setDirty();
    }

    public void addUserSuffix(UUID userUUID, Component prefix) {
        this.userSuffixes.put(userUUID, prefix);
        setDirty();
    }

    public void removeUserSuffix(UUID userUUID) {
        this.userSuffixes.remove(userUUID);
        setDirty();
    }

    public static PermissionUserData getPermissionUserData(MinecraftServer minecraftServer) {
        return (PermissionUserData) minecraftServer.overworld().getDataStorage().computeIfAbsent(factory(), "hennyessentials-permissions-user");
    }
}
