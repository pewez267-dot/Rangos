package com.henny.hennyessentials.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.henny.hennyessentials.Constants;
import com.henny.hennyessentials.config.objects.AnnouncementsConfig;
import com.henny.hennyessentials.config.objects.BannedItemsConfig;
import com.henny.hennyessentials.config.objects.CommandTokensConfig;
import com.henny.hennyessentials.config.objects.ConditionsConfig;
import com.henny.hennyessentials.config.objects.MainConfig;
import com.henny.hennyessentials.config.objects.PagesConfig;
import com.henny.hennyessentials.data.objects.Announcement;
import com.henny.hennyessentials.data.objects.CommandToken;
import com.henny.hennyessentials.data.objects.Condition;
import com.henny.hennyessentials.data.objects.ConfigPage;
import com.henny.hennyessentials.task.TaskManager;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ConfigManager {
    private static File cfgFile;
    public static String configDir;
    public static MainConfig CONFIG = new MainConfig();
    public static CommandTokensConfig commandTokensConfig = new CommandTokensConfig();
    public static AnnouncementsConfig announcementsConfig = new AnnouncementsConfig();
    public static BannedItemsConfig bannedItemsConfig = new BannedItemsConfig();
    public static ConditionsConfig conditionsConfig = new ConditionsConfig();
    public static PagesConfig pagesConfig = new PagesConfig();
    public static Map<String, BannedItemsConfig.BannedItem> BANNED_ITEMS_MAP = new HashMap();
    public static List<Condition> conditions = new ArrayList();
    public static Map<String, ConfigPage> PAGES = new HashMap();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().excludeFieldsWithoutExposeAnnotation().disableHtmlEscaping().create();
    public static Map<String, CommandToken> TOKENS = new HashMap();

    public static void reloadPagesConfig() {
        File configFile = new File(configDir, "Pages.json");
        if (!configFile.exists()) {
            try {
                configFile.createNewFile();
                pagesConfig = new PagesConfig();
                savePagesConfig();
            } catch (IOException e) {
                Constants.LOG.info(e.getLocalizedMessage());
            }
        }
        try {
            pagesConfig = (PagesConfig) GSON.fromJson(new FileReader(configFile), PagesConfig.class);
            for (ConfigPage page : pagesConfig.pages) {
                PAGES.put(page.pageID, page);
            }
            savePagesConfig();
        } catch (IOException e2) {
            Constants.LOG.error("Failed to load config: {}", e2.getLocalizedMessage());
        }
    }

    public static void savePagesConfig() throws IOException {
        FileWriter w = new FileWriter(new File(configDir, "Pages.json"));
        try {
            w.write(GSON.toJson(pagesConfig));
            w.close();
        } catch (Throwable th) {
            try {
                w.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    public static void reloadConditionsConfig() {
        File configFile = new File(configDir, "Conditions.json");
        if (!configFile.exists()) {
            try {
                configFile.createNewFile();
                conditionsConfig = new ConditionsConfig();
                saveConditionsConfig();
            } catch (IOException e) {
                Constants.LOG.info(e.getLocalizedMessage());
            }
        }
        try {
            conditionsConfig = (ConditionsConfig) GSON.fromJson(new FileReader(configFile), ConditionsConfig.class);
            conditions.clear();
            conditions.addAll(conditionsConfig.conditions);
            saveConditionsConfig();
        } catch (IOException e2) {
            Constants.LOG.error("Failed to load config: {}", e2.getLocalizedMessage());
        }
    }

    public static void saveConditionsConfig() throws IOException {
        FileWriter w = new FileWriter(new File(configDir, "Conditions.json"));
        try {
            w.write(GSON.toJson(conditionsConfig));
            w.close();
        } catch (Throwable th) {
            try {
                w.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    public static void reloadHEConfig(boolean restartTasks) {
        cfgFile = new File(configDir, "HennyEssentials.json");
        try {
            JsonObject defaultJson = GSON.toJsonTree(new MainConfig()).getAsJsonObject();
            if (cfgFile.exists()) {
                JsonObject userJson = JsonParser.parseReader(new FileReader(cfgFile)).getAsJsonObject();
                mergeJsonObjects(defaultJson, userJson);
            }
            CONFIG = (MainConfig) GSON.fromJson(defaultJson, MainConfig.class);
            handleConfigUpdates();
            save();
            if (restartTasks) {
                TaskManager.startHETasks();
            }
        } catch (IOException e) {
            Constants.LOG.error("Failed to load config: {}", e.getLocalizedMessage());
        }
    }

    public static void reloadCommandTokens() {
        File cmdTokensCfgFile = new File(configDir, "CommandTokens.json");
        if (cmdTokensCfgFile.exists()) {
            try {
                commandTokensConfig = (CommandTokensConfig) GSON.fromJson(new FileReader(cmdTokensCfgFile), CommandTokensConfig.class);
                for (CommandToken token : commandTokensConfig.tokens) {
                    if (token.permission == null) {
                        token.permission = "";
                    }
                    if (!token.shouldWriteToAuditLog) {
                        token.shouldWriteToAuditLog = false;
                    }
                    TOKENS.put(token.alias, token);
                }
                try {
                    saveCommandTokensConfig();
                } catch (IOException e) {
                    Constants.LOG.info("Saving command tokens error: {}", e.getLocalizedMessage());
                }
            } catch (FileNotFoundException e2) {
                throw new RuntimeException(e2);
            }
        }
    }

    public static void reloadAnnouncements() {
        File announcementsCfgFile = new File(configDir, "Announcements.json");
        if (announcementsCfgFile.exists()) {
            try {
                announcementsConfig = (AnnouncementsConfig) GSON.fromJson(new FileReader(announcementsCfgFile), AnnouncementsConfig.class);
                for (Announcement announcement : announcementsConfig.announcements) {
                    if (announcement.dimensions == null) {
                        announcement.dimensions = new ArrayList();
                    }
                }
                TaskManager.startAnnouncementTasks();
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private static void mergeJsonObjects(JsonObject base, JsonObject override) {
        for (String key : override.keySet()) {
            JsonElement overrideElement = override.get(key);
            if (base.has(key)) {
                JsonElement baseElement = base.get(key);
                if (baseElement.isJsonObject() && overrideElement.isJsonObject()) {
                    mergeJsonObjects(baseElement.getAsJsonObject(), overrideElement.getAsJsonObject());
                } else {
                    base.add(key, overrideElement);
                }
            } else {
                base.add(key, overrideElement);
            }
        }
    }

    public static void load(String configDirPath) {
        configDir = configDirPath;
        File dir = new File(configDirPath);
        if (!dir.exists()) {
            dir.mkdirs();
        }
        cfgFile = new File(configDirPath, "HennyEssentials.json");
        try {
            JsonObject defaultJson = GSON.toJsonTree(new MainConfig()).getAsJsonObject();
            if (cfgFile.exists()) {
                JsonObject userJson = JsonParser.parseReader(new FileReader(cfgFile)).getAsJsonObject();
                mergeJsonObjects(defaultJson, userJson);
            }
            CONFIG = (MainConfig) GSON.fromJson(defaultJson, MainConfig.class);
            handleConfigUpdates();
            save();
        } catch (IOException e) {
            Constants.LOG.error("Failed to load config: {}", e.getLocalizedMessage());
        }
    }

    public static void handleConfigUpdates() {
        if (CONFIG.configVersion_DO_NOT_CHANGE < 104 || (CONFIG.configVersion_DO_NOT_CHANGE == 104 && CONFIG.configSubVersion_DO_NOT_CHANGE < 7)) {
            CONFIG.configVersion_DO_NOT_CHANGE = Constants.VERSION;
            CONFIG.configSubVersion_DO_NOT_CHANGE = 7;
            if (!CONFIG.permissionConfigs.permissionsEnabled && CONFIG.permissionConfigs.luckPermsOverridePermissions) {
                CONFIG.permissionConfigs.permissionsEnabled = true;
            }
            if (CONFIG.aliasConfigs.aliasMap != null && !CONFIG.aliasConfigs.aliasMap.isEmpty()) {
                for (Map.Entry<String, String> entry : CONFIG.aliasConfigs.aliasMap.entrySet()) {
                    CONFIG.aliasConfigs.aliasList.put(entry.getKey(), List.of(entry.getValue()));
                }
                CONFIG.aliasConfigs.aliasMap.clear();
            }
        }
        CONFIG.configVersion_DO_NOT_CHANGE = Constants.VERSION;
        CONFIG.configSubVersion_DO_NOT_CHANGE = 7;
    }

    public static void loadBannedItems() {
        if (!new File(configDir).exists()) {
            new File(configDir).mkdirs();
        }
        File bannedItemsConfigFile = new File(configDir, "BannedItems.json");
        if (bannedItemsConfigFile.exists()) {
            try {
                bannedItemsConfig = (BannedItemsConfig) GSON.fromJson(new FileReader(bannedItemsConfigFile), BannedItemsConfig.class);
                BANNED_ITEMS_MAP.clear();
                for (BannedItemsConfig.BannedItem bi : bannedItemsConfig.bannedItems) {
                    BANNED_ITEMS_MAP.put(bi.id(), bi);
                }
                return;
            } catch (IOException e) {
                Constants.LOG.error(e.getLocalizedMessage());
                return;
            }
        }
        try {
            bannedItemsConfigFile.createNewFile();
            saveBannedItems();
            loadBannedItems();
        } catch (IOException e2) {
            Constants.LOG.error(e2.getLocalizedMessage());
        }
    }

    public static void loadAnnouncements(String cfgDir) {
        if (!new File(cfgDir).exists()) {
            new File(cfgDir).mkdirs();
        }
        File announcementsCfgFile = new File(cfgDir, "Announcements.json");
        if (announcementsCfgFile.exists()) {
            try {
                announcementsConfig = (AnnouncementsConfig) GSON.fromJson(new FileReader(announcementsCfgFile), AnnouncementsConfig.class);
                return;
            } catch (IOException e) {
                Constants.LOG.error(e.getLocalizedMessage());
                return;
            }
        }
        try {
            announcementsCfgFile.createNewFile();
            saveAnnouncements();
            loadAnnouncements(cfgDir);
        } catch (IOException e2) {
            Constants.LOG.error(e2.getLocalizedMessage());
        }
    }

    public static void save() throws IOException {
        Gson versionedGson = new GsonBuilder().setVersion(104.0d).setPrettyPrinting().excludeFieldsWithoutExposeAnnotation().disableHtmlEscaping().create();
        FileWriter w = new FileWriter(cfgFile);
        try {
            w.write(versionedGson.toJson(CONFIG));
            w.close();
        } catch (Throwable th) {
            try {
                w.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    public static void saveAnnouncements() throws IOException {
        FileWriter w = new FileWriter(new File(configDir, "Announcements.json"));
        try {
            w.write(GSON.toJson(announcementsConfig));
            w.close();
        } catch (Throwable th) {
            try {
                w.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    public static void saveBannedItems() throws IOException {
        FileWriter w = new FileWriter(new File(configDir, "BannedItems.json"));
        try {
            w.write(GSON.toJson(bannedItemsConfig));
            w.close();
        } catch (Throwable th) {
            try {
                w.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    public static void loadCommandTokensConfig(String configDirPath) {
        File ctokensCfgFile = new File(configDirPath, "CommandTokens.json");
        if (ctokensCfgFile.exists()) {
            try {
                commandTokensConfig = (CommandTokensConfig) GSON.fromJson(new FileReader(ctokensCfgFile), CommandTokensConfig.class);
                for (CommandToken token : commandTokensConfig.tokens) {
                    if (token.permission == null) {
                        token.permission = "";
                    }
                    if (!token.shouldWriteToAuditLog) {
                        token.shouldWriteToAuditLog = false;
                    }
                    TOKENS.put(token.alias, token);
                }
                saveCommandTokensConfig();
                return;
            } catch (Exception e) {
                Constants.LOG.info(e.getLocalizedMessage());
                return;
            }
        }
        try {
            ctokensCfgFile.createNewFile();
            saveCommandTokensConfig();
            loadCommandTokensConfig(configDirPath);
        } catch (IOException e2) {
            throw new RuntimeException(e2);
        }
    }

    public static void saveCommandTokensConfig() throws IOException {
        FileWriter w = new FileWriter(new File(configDir, "CommandTokens.json"));
        try {
            w.write(GSON.toJson(commandTokensConfig));
            w.close();
        } catch (Throwable th) {
            try {
                w.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }
}
