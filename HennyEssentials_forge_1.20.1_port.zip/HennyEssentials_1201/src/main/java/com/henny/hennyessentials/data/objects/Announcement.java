package com.henny.hennyessentials.data.objects;

import com.google.gson.annotations.Expose;
import java.util.ArrayList;
import java.util.List;

public class Announcement {

    @Expose
    public String announcementText;

    @Expose
    public int secondsDelay;

    @Expose
    public List<String> dimensions = new ArrayList();

    public Announcement(String announcementText, int secondsDelay) {
        this.announcementText = "This is an announcement that will appear every 5 minutes!";
        this.secondsDelay = 300;
        this.announcementText = announcementText;
        this.secondsDelay = secondsDelay;
    }
}
