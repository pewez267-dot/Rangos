package com.henny.hennyessentials.command;

import com.henny.hennyessentials.CommonClass;
import com.henny.hennyessentials.config.ConfigManager;
import com.henny.hennyessentials.data.WarpData;
import com.henny.hennyessentials.data.objects.Warp;
import com.henny.hennyessentials.menu.WarpsMenu;
import com.henny.hennyessentials.permission.Permissions;
import com.henny.hennyessentials.util.TextUtils;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.item.ItemArgument;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.registries.VanillaRegistries;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import org.jetbrains.annotations.Nullable;

public class WarpCommands {
    public static List<LiteralArgumentBuilder<CommandSourceStack>> buildWarpCommands() {
        ArrayList<LiteralArgumentBuilder<CommandSourceStack>> returnList = new ArrayList<>();
        LiteralArgumentBuilder<CommandSourceStack> setWarpCommand = Commands.literal("setwarp");
        setWarpCommand.then(Commands.argument("warpName", StringArgumentType.string()).executes(WarpCommands::executeSetWarp).then(Commands.argument("category", StringArgumentType.word()).executes(WarpCommands::executeSetWarp).then(Commands.argument("displayItem", ItemArgument.item(Commands.createValidationContext(VanillaRegistries.createLookup()))).executes(WarpCommands::executeSetWarp))));
        setWarpCommand.requires(src -> {
            return ModCommands.getRequirements(src, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.WARP_SET_PERMISSION));
        });
        returnList.add(setWarpCommand);
        LiteralArgumentBuilder<CommandSourceStack> setTempWarpCommand = Commands.literal("settempwarp");
        setTempWarpCommand.then(Commands.argument("warpName", StringArgumentType.word()).then(Commands.argument("duration", StringArgumentType.word()).executes(WarpCommands::executeSetTempWarp).then(Commands.argument("category", StringArgumentType.word()).executes(WarpCommands::executeSetTempWarp).then(Commands.argument("displayItem", ItemArgument.item(Commands.createValidationContext(VanillaRegistries.createLookup()))).executes(WarpCommands::executeSetTempWarp)))));
        setTempWarpCommand.requires(src2 -> {
            return ModCommands.getRequirements(src2, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.WARP_SET_TEMP_PERMISSION));
        });
        returnList.add(setTempWarpCommand);
        LiteralArgumentBuilder<CommandSourceStack> delWarpCommand = Commands.literal("delwarp");
        delWarpCommand.then(Commands.argument("warpName", StringArgumentType.word()).executes(WarpCommands::executeRemoveWarp).requires(src3 -> {
            return ModCommands.getRequirements(src3, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.WARP_DELETE_PERMISSION));
        }));
        delWarpCommand.requires(src4 -> {
            return ModCommands.getRequirements(src4, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.WARP_DELETE_PERMISSION));
        });
        returnList.add(delWarpCommand);
        LiteralArgumentBuilder<CommandSourceStack> warpCommand = Commands.literal("warp");
        warpCommand.then(Commands.argument("warpName", StringArgumentType.word()).executes(WarpCommands::executeWarp).requires(src5 -> {
            return ModCommands.getPlayerRequirements(src5, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.WARP_PERMISSION));
        }));
        LiteralArgumentBuilder<CommandSourceStack> setWarpCategoryCommand = Commands.literal("setCategory");
        setWarpCategoryCommand.then(Commands.argument("warpName", StringArgumentType.word()).then(Commands.argument("category", StringArgumentType.word()).executes(WarpCommands::executeSetWarpCategory).requires(src6 -> {
            return ModCommands.getRequirements(src6, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.WARP_SET_CATEGORY_PERMISSION));
        })));
        LiteralArgumentBuilder<CommandSourceStack> setWarpDisplayIconCommand = Commands.literal("setDisplayIcon");
        setWarpDisplayIconCommand.then(Commands.literal("warp").then(Commands.argument("warpName", StringArgumentType.word()).executes(WarpCommands::executeSetWarpDisplayIcon).requires(src7 -> {
            return ModCommands.getRequirements(src7, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.WARP_SET_DISPLAY_ICON_PERMISSION));
        })));
        setWarpDisplayIconCommand.then(Commands.literal("category").then(Commands.argument("categoryName", StringArgumentType.word()).suggests(WarpCommands::suggestCategoryOptions).executes(WarpCommands::executeSetWarpCategoryDisplayIcon).requires(src8 -> {
            return ModCommands.getRequirements(src8, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.WARP_SET_PERMISSION));
        })));
        setWarpCategoryCommand.requires(src9 -> {
            return ModCommands.getRequirements(src9, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.WARP_SET_CATEGORY_PERMISSION));
        });
        setWarpDisplayIconCommand.requires(src10 -> {
            return ModCommands.getRequirements(src10, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.WARP_SET_DISPLAY_ICON_PERMISSION));
        });
        warpCommand.then(setWarpCategoryCommand);
        warpCommand.then(setWarpDisplayIconCommand);
        returnList.add(warpCommand);
        LiteralArgumentBuilder<CommandSourceStack> warpsCommand = Commands.literal("warps").executes(WarpCommands::executeListWarps);
        LiteralArgumentBuilder<CommandSourceStack> listWarpsCommand = Commands.literal("listwarps");
        warpsCommand.executes(WarpCommands::executeListWarps).then(Commands.argument("category", StringArgumentType.word()).executes(WarpCommands::executeListWarps).requires(src11 -> {
            return ModCommands.getPlayerRequirements(src11, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.WARP_LIST_PERMISSION));
        }));
        listWarpsCommand.executes(WarpCommands::executeListWarps);
        listWarpsCommand.then(Commands.argument("category", StringArgumentType.word()).executes(WarpCommands::executeListWarps).requires(src12 -> {
            return ModCommands.getPlayerRequirements(src12, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.WARP_LIST_PERMISSION));
        }));
        warpsCommand.requires(src13 -> {
            return ModCommands.getPlayerRequirements(src13, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.WARP_LIST_PERMISSION));
        });
        listWarpsCommand.requires(src14 -> {
            return ModCommands.getPlayerRequirements(src14, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.WARP_LIST_PERMISSION));
        });
        returnList.add(warpsCommand);
        returnList.add(listWarpsCommand);
        return returnList;
    }

    private static int executeSetWarpDisplayIcon(CommandContext<CommandSourceStack> context) {
        String warpName = StringArgumentType.getString(context, "warpName");
        ItemStack item = ((CommandSourceStack) context.getSource()).getPlayer().getMainHandItem();
        if (item != null && !item.isEmpty() && WarpData.getWarpData(CommonClass.minecraftServer).warps.containsKey(warpName)) {
            WarpData.getWarpData(((CommandSourceStack) context.getSource()).getServer()).setWarpDisplayItem(warpName, item);
            ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Set display icon for warp: " + warpName + " to: " + String.valueOf(BuiltInRegistries.ITEM.getKey(item.getItem()))));
            return 1;
        }
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Error setting display icon."));
        return 1;
    }

    private static int executeSetWarpCategoryDisplayIcon(CommandContext<CommandSourceStack> context) {
        String categoryName = StringArgumentType.getString(context, "categoryName");
        ItemStack item = ((CommandSourceStack) context.getSource()).getPlayer().getMainHandItem();
        if (item != null && !item.isEmpty()) {
            WarpData.getWarpData(((CommandSourceStack) context.getSource()).getServer()).setCategoryDisplayItem(categoryName, item);
            ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Set display icon for warp category: " + categoryName + " to: " + String.valueOf(BuiltInRegistries.ITEM.getKey(item.getItem()))));
            return 1;
        }
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Error setting display icon. "));
        return 1;
    }

    private static int executeRemoveWarp(CommandContext<CommandSourceStack> context) {
        String warpName = StringArgumentType.getString(context, "warpName");
        WarpData warpData = WarpData.getWarpData(((CommandSourceStack) context.getSource()).getServer());
        if (!warpData.warps.containsKey(warpName)) {
            ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Warp '" + warpName + "' does not exist."));
            return 1;
        }
        warpData.removeWarp(warpName);
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Warp '" + warpName + "' removed."));
        return 1;
    }

    private static int executeSetWarpCategory(CommandContext<CommandSourceStack> context) {
        String warpName = StringArgumentType.getString(context, "warpName");
        String category = StringArgumentType.getString(context, "category");
        WarpData warpData = WarpData.getWarpData(((CommandSourceStack) context.getSource()).getServer());
        if (!warpData.warps.containsKey(warpName)) {
            ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Warp '" + warpName + "' does not exist."));
            return 1;
        }
        warpData.setWarpCategory(warpName, category);
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Warp '" + warpName + "' has been added to category: " + category));
        return 1;
    }

    private static int executeSetWarp(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        String warpName = StringArgumentType.getString(context, "warpName");
        ServerPlayer player = ((CommandSourceStack) context.getSource()).getPlayerOrException();
        ((CommandSourceStack) context.getSource()).getServer();
        WarpData warpData = WarpData.getWarpData(((CommandSourceStack) context.getSource()).getServer());
        Warp warp = new Warp(warpName, player.getOnPos(), player.serverLevel().dimension().location().toString());
        warp.rotation = player.getYRot();
        if (context.getNodes().stream().anyMatch(node -> {
            return node.getNode().getName().equals("category");
        })) {
            warp.category = StringArgumentType.getString(context, "category");
        }
        if (context.getNodes().stream().anyMatch(node2 -> {
            return node2.getNode().getName().equals("displayItem");
        })) {
            warp.displayItem = ItemArgument.getItem(context, "displayItem").createItemStack(1, false);
        }
        warpData.addWarp(warp);
        player.sendSystemMessage(TextUtils.formatAndHighlight("Set warp with the name [" + warpName + "] at position: [" + warp.dimension + "~" + warp.blockPos.toShortString() + "]"));
        return 1;
    }

    private static int executeSetTempWarp(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        String warpName = StringArgumentType.getString(context, "warpName");
        String duration = StringArgumentType.getString(context, "duration");
        if (TextUtils.canBeParsed(duration)) {
            ServerPlayer player = ((CommandSourceStack) context.getSource()).getPlayerOrException();
            long durationMillis = Duration.parse(TextUtils.parseToISO8601(duration)).toMillis();
            WarpData warpData = WarpData.getWarpData(((CommandSourceStack) context.getSource()).getServer());
            Warp warp = new Warp(warpName, player.getOnPos(), player.serverLevel().dimension().location().toString(), System.currentTimeMillis() + durationMillis);
            warp.rotation = player.getYRot();
            if (context.getNodes().stream().anyMatch(node -> {
                return node.getNode().getName().equals("categor");
            })) {
                warp.category = StringArgumentType.getString(context, "category");
            }
            if (context.getNodes().stream().anyMatch(node2 -> {
                return node2.getNode().getName().equals("displayItem");
            })) {
                warp.displayItem = ItemArgument.getItem(context, "displayItem").createItemStack(1, false);
            }
            warpData.addWarp(warp);
            player.sendSystemMessage(TextUtils.formatAndHighlight("Set temp warp with the name [" + warpName + "] at position: [" + warp.dimension + "~" + warp.blockPos.toShortString() + "]"));
            player.sendSystemMessage(TextUtils.formatAndHighlight("This warp will expire in: [" + TextUtils.readableDuration(warp.expiry - System.currentTimeMillis()) + "]"));
            return 1;
        }
        TextUtils.sendParseError((CommandSourceStack) context.getSource(), duration);
        return 1;
    }

    public static int executeWarp(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        String warpName = StringArgumentType.getString(context, "warpName").toLowerCase();
        MinecraftServer server = ((CommandSourceStack) context.getSource()).getServer();
        ServerPlayer player = ((CommandSourceStack) context.getSource()).getPlayerOrException();
        WarpData warpData = WarpData.getWarpData(((CommandSourceStack) context.getSource()).getServer());
        if (!warpData.warps.containsKey(warpName)) {
            player.sendSystemMessage(TextUtils.formatMessage("Warp '" + warpName + "' does not exist."));
        }
        Warp warp = warpData.warps.get(warpName);
        String warpcat = warp.category;
        if (warpcat == null || warpcat.isBlank()) {
            warpcat = "default";
        }
        if (ConfigManager.CONFIG.permissionConfigs.permissionsRequiredForIndividualWarps && !Permissions.permissionCheckList(player.getUUID(), List.of("warp." + warpName, "warpcategory." + warpcat), CommonClass.minecraftServer)) {
            player.sendSystemMessage(Component.literal("").append(TextUtils.formatMessage(ConfigManager.CONFIG.commandConfigs.warpConfigs.noPermissionForWarpMessage.replace("%warpname%", warpName))));
            return 1;
        }
        if (!Permissions.cooldownChecker(player.getUUID(), Permissions.WARP_COMMAND_COOLDOWN_KEY)) {
            Permissions.handleCooldownNotExpired(player, Permissions.WARP_COMMAND_COOLDOWN_KEY);
            return 1;
        }
        Permissions.updateCooldown(player.getUUID(), Permissions.WARP_COMMAND_COOLDOWN_KEY, System.currentTimeMillis() + (((long) ConfigManager.CONFIG.commandConfigs.warpConfigs.cooldownSeconds) * 1000));
        ServerLevel serverLevel = server.getLevel(ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(warp.dimension)));
        GlobalPos pos = GlobalPos.of(serverLevel.dimension(), warp.blockPos);
        TeleportCommands.teleportPlayer(player, pos, ConfigManager.CONFIG.commandConfigs.teleportConfigs.warpCommandWarmupSeconds, warp.rotation);
        return 1;
    }

    private static int executeListWarps(CommandContext<CommandSourceStack> context) {
        WarpData warpData = WarpData.getWarpData(((CommandSourceStack) context.getSource()).getServer());
        if (ConfigManager.CONFIG.commandConfigs.warpConfigs.shouldUseInventoryMenuForWarps) {
            openWarpsMenu(((CommandSourceStack) context.getSource()).getPlayer());
            return 1;
        }
        String category = "";
        boolean hasCategory = context.getNodes().stream().anyMatch(node -> {
            return node.getNode().getName().equals("category");
        });
        if (hasCategory) {
            category = StringArgumentType.getString(context, "category");
        }
        ArrayList<Component> components = new ArrayList<>();
        Map<String, List<MutableComponent>> categories = new HashMap<>();
        warpData.warps.values().forEach(warp -> {
            String expiry = warp.expiry > 0 ? " | Expires: " + TextUtils.readableDuration(warp.expiry - System.currentTimeMillis()) : "";
            MutableComponent warpComponent = Component.literal("").append("~ " + warp.name + expiry).withStyle(ChatFormatting.GOLD);
            warpComponent.withStyle(Style.EMPTY.withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/" + ModCommands.BASE_COMMAND_ALIAS + " warp " + warp.name)).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal("Click here to warp to: " + warp.name))));
            components.add(warpComponent);
            ((List) categories.computeIfAbsent(warp.category, k -> {
                return new ArrayList();
            })).add(warpComponent);
        });
        if (!hasCategory) {
            if (categories.size() == 1) {
                ((CommandSourceStack) context.getSource()).sendSystemMessage(Component.literal("~ WARP LIST ~").withStyle(ChatFormatting.GREEN));
                components.forEach(component -> {
                    ((CommandSourceStack) context.getSource()).sendSystemMessage(component);
                });
                return 1;
            }
            ((CommandSourceStack) context.getSource()).sendSystemMessage(Component.literal("~ WARP CATEGORIES ~").withStyle(ChatFormatting.GREEN));
            categories.forEach((s, mutableComponents) -> {
                MutableComponent categoryComp = Component.literal("~ " + s);
                Style style = Style.EMPTY.withColor(ChatFormatting.GOLD).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal("Click here to expand this warp category"))).withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/he listwarps " + s));
                ((CommandSourceStack) context.getSource()).sendSystemMessage(categoryComp.withStyle(style));
            });
            return 1;
        }
        ((CommandSourceStack) context.getSource()).sendSystemMessage(Component.literal("~ " + category + " ~").withStyle(ChatFormatting.GREEN));
        categories.getOrDefault(category, new ArrayList<>()).forEach(mutableComponent -> {
            ((CommandSourceStack) context.getSource()).sendSystemMessage(mutableComponent);
        });
        return 1;
    }

    public static void openWarpsMenu(ServerPlayer player) {
        new SimpleContainer(90);
        player.openMenu(new MenuProvider() { // from class: com.henny.hennyessentials.command.WarpCommands.1
            @Nullable
            public AbstractContainerMenu createMenu(int i, Inventory inventory, Player player2) {
                return new WarpsMenu(i, inventory, WarpData.getWarpData(CommonClass.minecraftServer), player2.getUUID());
            }

            public Component getDisplayName() {
                return Component.literal("Warps Menu");
            }
        });
    }

    private static CompletableFuture<Suggestions> suggestCategoryOptions(CommandContext<CommandSourceStack> context, SuggestionsBuilder builder) {
        if (CommonClass.minecraftServer != null) {
            WarpData data = WarpData.getWarpData(CommonClass.minecraftServer);
            HashSet<String> categories = new HashSet<>();
            for (Map.Entry<String, Warp> warp : data.warps.entrySet()) {
                categories.add(warp.getValue().category);
            }
            Objects.requireNonNull(builder);
            categories.forEach(builder::suggest);
        }
        return builder.buildFuture();
    }
}
