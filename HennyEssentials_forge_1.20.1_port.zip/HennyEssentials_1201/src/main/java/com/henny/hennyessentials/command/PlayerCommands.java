package com.henny.hennyessentials.command;

import com.henny.hennyessentials.CommonClass;
import com.henny.hennyessentials.Constants;
import com.henny.hennyessentials.config.ConfigManager;
import com.henny.hennyessentials.config.objects.MainConfig;
import com.henny.hennyessentials.data.PlayerData;
import com.henny.hennyessentials.permission.Permissions;
import com.henny.hennyessentials.util.AFKHandler;
import com.henny.hennyessentials.util.TextUtils;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.Holder;
// 1.20.1: DataComponents not available, use legacy damage API
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoRemovePacket;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.inventory.AnvilMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.CraftingMenu;
import net.minecraft.world.inventory.SmithingMenu;
import net.minecraft.world.inventory.StonecutterMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;

public class PlayerCommands {
    public static List<LiteralArgumentBuilder<CommandSourceStack>> buildPlayerCommands() {
        MainConfig.CommandConfigs.PlayerCommandConfigs playerCommandConfigs = ConfigManager.CONFIG.commandConfigs.playerCommandConfigs;
        ArrayList<LiteralArgumentBuilder<CommandSourceStack>> returnList = new ArrayList<>();
        LiteralArgumentBuilder<CommandSourceStack> vanishCommand = Commands.literal("vanish");
        vanishCommand.executes(PlayerCommands::executeVanish).requires(src -> {
            return ModCommands.getRequirements(src, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, "command.he.vanish"));
        });
        if (playerCommandConfigs.vanishCommandEnabled) {
            returnList.add(vanishCommand);
        }
        LiteralArgumentBuilder<CommandSourceStack> playtimeCommand = Commands.literal("playtime");
        playtimeCommand.executes(ctx -> {
            String duration = TextUtils.readableDuration(TimeUnit.SECONDS.toMillis(Integer.parseInt(PlayerData.getUserData().getPlayerInfoValue(((CommandSourceStack) ctx.getSource()).getPlayer().getUUID(), "playtime"))));
            ((CommandSourceStack) ctx.getSource()).sendSystemMessage(TextUtils.formatMessage("").append(Component.literal(ConfigManager.CONFIG.commandConfigs.playerCommandConfigs.playtimeText.replace("%playtime%", duration))));
            return 1;
        }).requires(src2 -> {
            return ModCommands.getPlayerRequirements(src2, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.PLAYER_PLAYTIME_PERMISSION));
        });
        returnList.add(playtimeCommand);
        LiteralArgumentBuilder<CommandSourceStack> afkCommand = Commands.literal("afk");
        afkCommand.requires(src3 -> {
            return ModCommands.getPlayerRequirements(src3, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.PLAYER_AFK_PERMISSION));
        });
        afkCommand.executes(ctx2 -> {
            if (!((CommandSourceStack) ctx2.getSource()).isPlayer()) {
                return 1;
            }
            AFKHandler.markAFK(((CommandSourceStack) ctx2.getSource()).getPlayer());
            return 1;
        });
        returnList.add(afkCommand);
        LiteralArgumentBuilder<CommandSourceStack> anvilCommand = Commands.literal("anvil");
        anvilCommand.executes(ctx3 -> {
            if (!((CommandSourceStack) ctx3.getSource()).isPlayer()) {
                return 1;
            }
            ServerPlayer p = ((CommandSourceStack) ctx3.getSource()).getPlayer();
            p.openMenu(new SimpleMenuProvider((syncId, playerInventory, playerEntity) -> {
                return new AnvilMenu(syncId, playerInventory);
            }, Component.literal("Henny Anvil")));
            return 1;
        });
        anvilCommand.requires(src4 -> {
            return ModCommands.getRequirements(src4, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PLAYER_ANVIL_PERMISSION));
        });
        returnList.add(anvilCommand);
        LiteralArgumentBuilder<CommandSourceStack> craftingTableCommand = Commands.literal("ctable");
        craftingTableCommand.executes(ctx4 -> {
            if (!((CommandSourceStack) ctx4.getSource()).isPlayer()) {
                return 1;
            }
            ServerPlayer p = ((CommandSourceStack) ctx4.getSource()).getPlayer();
            p.openMenu(new SimpleMenuProvider((syncId, playerInventory, playerEntity) -> {
                return new CraftingMenu(syncId, playerInventory);
            }, Component.literal("Henny Crafting")));
            return 1;
        });
        craftingTableCommand.requires(src5 -> {
            return ModCommands.getRequirements(src5, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PLAYER_CRAFTINGTABLE_PERMISSION));
        });
        returnList.add(craftingTableCommand);
        LiteralArgumentBuilder<CommandSourceStack> stonecutterCommand = Commands.literal("stonecutter");
        stonecutterCommand.executes(ctx5 -> {
            if (!((CommandSourceStack) ctx5.getSource()).isPlayer()) {
                return 1;
            }
            ServerPlayer p = ((CommandSourceStack) ctx5.getSource()).getPlayer();
            p.openMenu(new SimpleMenuProvider((syncId, playerInventory, playerEntity) -> {
                return new StonecutterMenu(syncId, playerInventory);
            }, Component.literal("Henny Stonecutter")));
            return 1;
        });
        stonecutterCommand.requires(src6 -> {
            return ModCommands.getRequirements(src6, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PLAYER_STONECUTTER_PERMISSION));
        });
        returnList.add(stonecutterCommand);
        LiteralArgumentBuilder<CommandSourceStack> smithingTableCommand = Commands.literal("smithtable");
        smithingTableCommand.executes(ctx6 -> {
            if (!((CommandSourceStack) ctx6.getSource()).isPlayer()) {
                return 1;
            }
            ServerPlayer p = ((CommandSourceStack) ctx6.getSource()).getPlayer();
            p.openMenu(new SimpleMenuProvider((syncId, playerInventory, playerEntity) -> {
                return new SmithingMenu(syncId, playerInventory);
            }, Component.literal("Henny Smithing")));
            return 1;
        });
        smithingTableCommand.requires(src7 -> {
            return ModCommands.getRequirements(src7, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PLAYER_SMITHING_PERMISSION));
        });
        returnList.add(smithingTableCommand);
        LiteralArgumentBuilder<CommandSourceStack> hatCommand = Commands.literal("hat");
        hatCommand.requires(src8 -> {
            return ModCommands.getRequirements(src8, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.PLAYER_HAT_PERMISSION));
        });
        hatCommand.executes(ctx7 -> {
            if (!((CommandSourceStack) ctx7.getSource()).isPlayer()) {
                return 1;
            }
            ServerPlayer p = ((CommandSourceStack) ctx7.getSource()).getPlayer();
            ItemStack helm = p.getItemBySlot(EquipmentSlot.HEAD);
            ItemStack main = p.getItemInHand(InteractionHand.MAIN_HAND);
            Constants.LOG.info(helm.getDisplayName().toString());
            if (helm.isEmpty() && !main.isEmpty()) {
                p.setItemSlot(EquipmentSlot.HEAD, main.copyWithCount(1));
                main.shrink(1);
                return 1;
            }
            p.sendSystemMessage(TextUtils.formatMessage("Error setting hat. You need to have an empty helmet slot and hold the item you want to set as your hat in your MAIN HAND."));
            return 1;
        });
        returnList.add(hatCommand);
        LiteralArgumentBuilder<CommandSourceStack> healCommand = Commands.literal("heal");
        healCommand.executes(PlayerCommands::executeHeal).requires(src9 -> {
            return ModCommands.getRequirements(src9, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, "command.he.vanish"));
        });
        if (playerCommandConfigs.healCommandEnabled) {
            returnList.add(healCommand);
        }
        LiteralArgumentBuilder<CommandSourceStack> feedCommand = Commands.literal("feed");
        feedCommand.executes(PlayerCommands::executeFeed).requires(src10 -> {
            return ModCommands.getRequirements(src10, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PLAYER_FEED_PERMISSION));
        });
        if (playerCommandConfigs.feedCommandEnabled) {
            returnList.add(feedCommand);
        }
        LiteralArgumentBuilder<CommandSourceStack> repairCommand = Commands.literal("repair");
        repairCommand.executes(PlayerCommands::executeRepair).requires(src11 -> {
            return ModCommands.getRequirements(src11, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PLAYER_REPAIR_PERMISSION));
        });
        if (playerCommandConfigs.repairCommandEnabled) {
            returnList.add(repairCommand);
        }
        LiteralArgumentBuilder<CommandSourceStack> flyCommand = Commands.literal("fly");
        flyCommand.executes(PlayerCommands::executeFly).requires(src12 -> {
            return ModCommands.getRequirements(src12, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PLAYER_FLY_PERMISSION));
        });
        if (playerCommandConfigs.flyCommandEnabled) {
            returnList.add(flyCommand);
        }
        LiteralArgumentBuilder<CommandSourceStack> EChestCommand = Commands.literal("echest").executes(PlayerCommands::executeEchest).requires(src13 -> {
            return ModCommands.getRequirements(src13, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PLAYER_ECHEST_PERMISSION));
        });
        LiteralArgumentBuilder<CommandSourceStack> viewEChestCommand = Commands.literal("viewechest").then(Commands.argument("playername", EntityArgument.player()).executes(PlayerCommands::executeViewEChest).requires(src14 -> {
            return ModCommands.getRequirements(src14, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PLAYER_VIEW_OTHER_ECHEST_PERMISSION));
        }));
        viewEChestCommand.requires(src15 -> {
            return ModCommands.getRequirements(src15, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PLAYER_VIEW_OTHER_ECHEST_PERMISSION));
        });
        if (playerCommandConfigs.enderChestCommandEnabled) {
            returnList.add(EChestCommand);
        }
        if (playerCommandConfigs.adminViewPlayerEnderChestCommandEnabled) {
            returnList.add(viewEChestCommand);
        }
        return returnList;
    }

    private static int executeEchest(CommandContext<CommandSourceStack> context) {
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        ServerPlayer p = ((CommandSourceStack) context.getSource()).getPlayer();
        p.openMenu(new SimpleMenuProvider((syncId, playerInventory, playerEntity) -> {
            return ChestMenu.threeRows(syncId, playerInventory, p.getEnderChestInventory());
        }, Component.translatable("container.enderchest")));
        return 1;
    }

    private static int executeViewEChest(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        ServerPlayer tosee = EntityArgument.getPlayer(context, "playername");
        ServerPlayer p = ((CommandSourceStack) context.getSource()).getPlayer();
        p.openMenu(new SimpleMenuProvider((syncId, playerInventory, playerEntity) -> {
            return ChestMenu.threeRows(syncId, playerInventory, tosee.getEnderChestInventory());
        }, Component.translatable("container.enderchest")));
        return 1;
    }

    private static int executeVanish(CommandContext<CommandSourceStack> context) {
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        ServerPlayer player = ((CommandSourceStack) context.getSource()).getPlayer();
        Holder<MobEffect> effect = MobEffects.INVISIBILITY;
        MobEffectInstance mobEffectInstance = new MobEffectInstance(MobEffects.INVISIBILITY, Integer.MAX_VALUE, 1, true, false, true);
        if (player.getTags().contains("he.vanish")) {
            CommonClass.playersInVanish.put(player.getUUID(), false);
            player.removeTag("he.vanish");
            player.setInvisible(false);
            player.removeEffect(effect);
            if (ConfigManager.CONFIG.commandConfigs.vanishConfigs.EXPERIMENTAL_shouldHideVanishedPlayersFromTabList) {
                ClientboundPlayerInfoUpdatePacket packet = ClientboundPlayerInfoUpdatePacket.createPlayerInitializing(List.of(player));
                for (ServerPlayer p : player.server.getPlayerList().getPlayers()) {
                    p.connection.send(packet);
                }
            }
            player.sendSystemMessage(TextUtils.formatMessage(ConfigManager.CONFIG.commandConfigs.playerCommandConfigs.vanishText.replace("%b", String.valueOf(false))));
            return 1;
        }
        if (ConfigManager.CONFIG.commandConfigs.vanishConfigs.EXPERIMENTAL_shouldHideVanishedPlayersFromTabList) {
            ClientboundPlayerInfoRemovePacket packet2 = new ClientboundPlayerInfoRemovePacket(List.of(player.getUUID()));
            for (ServerPlayer p2 : player.server.getPlayerList().getPlayers()) {
                p2.connection.send(packet2);
            }
        }
        AABB box = new AABB(player.getOnPos()).inflate(50.0d);
        player.level().getEntitiesOfClass(Mob.class, box).forEach(mob -> {
            if (mob != null && mob.getTarget() != null && mob.getTarget() == player) {
                mob.setTarget((LivingEntity) null);
            }
        });
        player.addEffect(mobEffectInstance);
        player.setInvisible(true);
        player.addTag("he.vanish");
        CommonClass.playersInVanish.put(player.getUUID(), true);
        player.sendSystemMessage(TextUtils.formatMessage(ConfigManager.CONFIG.commandConfigs.playerCommandConfigs.vanishText.replace("%b", String.valueOf(true))));
        return 1;
    }

    private static int executeHeal(CommandContext<CommandSourceStack> context) {
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        ServerPlayer player = ((CommandSourceStack) context.getSource()).getPlayer();
        player.setHealth(player.getMaxHealth());
        player.sendSystemMessage(TextUtils.formatMessage("You have been healed."));
        return 1;
    }

    private static List<Mob> findMobsAround(ServerPlayer player, double radius) {
        AABB box = new AABB(player.getOnPos()).inflate(radius);
        return player.level().getEntitiesOfClass(Mob.class, box);
    }

    private static int executeFeed(CommandContext<CommandSourceStack> context) {
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        ServerPlayer player = ((CommandSourceStack) context.getSource()).getPlayer();
        player.getFoodData().setExhaustion(0.0f);
        player.getFoodData().setFoodLevel(20);
        player.getFoodData().setSaturation(20.0f);
        player.sendSystemMessage(TextUtils.formatMessage("You have been fed."));
        return 1;
    }

    private static int executeRepair(CommandContext<CommandSourceStack> context) {
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        ServerPlayer player = ((CommandSourceStack) context.getSource()).getPlayer();
        ItemStack item = player.getItemInHand(InteractionHand.MAIN_HAND);
        // 1.20.1: use isDamageableItem() and setDamageValue() instead of DataComponents.DAMAGE
        if (!item.isEmpty() && item.isDamageableItem()) {
            item.setDamageValue(0);
            player.sendSystemMessage(TextUtils.formatMessage("Repaired held item."));
            return 1;
        }
        TextUtils.formatMessage("Error repairing item");
        return 1;
    }

    private static int executeFly(CommandContext<CommandSourceStack> context) {
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        ServerPlayer player = ((CommandSourceStack) context.getSource()).getPlayer();
        boolean canFly = CommonClass.playersInFly.getOrDefault(player.getUUID(), false).booleanValue();
        boolean newFlyState = !canFly;
        player.getAbilities().mayfly = newFlyState;
        player.getAbilities().flying = newFlyState;
        player.onUpdateAbilities();
        CommonClass.playersInFly.put(player.getUUID(), Boolean.valueOf(newFlyState));
        if (newFlyState) {
            player.addTag("he.fly");
        } else {
            player.removeTag("he.fly");
        }
        player.sendSystemMessage(TextUtils.formatMessage(ConfigManager.CONFIG.commandConfigs.playerCommandConfigs.flyText.replace("%b", String.valueOf(newFlyState))));
        return 1;
    }
}
