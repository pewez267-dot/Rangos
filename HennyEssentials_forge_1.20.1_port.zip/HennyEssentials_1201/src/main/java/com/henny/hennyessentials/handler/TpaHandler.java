package com.henny.hennyessentials.handler;

import com.henny.hennyessentials.data.objects.Tpa;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;

public class TpaHandler {
    public static Map<UUID, Tpa> tpaReqs = new HashMap();

    public static void addTpaRequest(UUID requestID, Tpa tpa) {
        tpaReqs.put(requestID, tpa);
    }

    public static void teleportPlayerToPlayer(UUID reqUUID, ServerPlayer from, ServerPlayer to) {
    }
}
