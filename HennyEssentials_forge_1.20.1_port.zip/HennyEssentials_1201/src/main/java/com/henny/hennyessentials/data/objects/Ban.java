package com.henny.hennyessentials.data.objects;

import java.util.UUID;

public class Ban {
    public UUID bannedPlayerUUID;
    public long banExpiry;
    public String banReason;

    public Ban(UUID bannedPlayerUUID, long banExpiry, String banReason) {
        this.banExpiry = 0L;
        this.bannedPlayerUUID = bannedPlayerUUID;
        this.banExpiry = banExpiry;
        this.banReason = banReason;
    }

    public Ban(UUID bannedPlayerUUID, String banReason) {
        this.banExpiry = 0L;
        this.bannedPlayerUUID = bannedPlayerUUID;
        this.banReason = banReason;
    }
}
