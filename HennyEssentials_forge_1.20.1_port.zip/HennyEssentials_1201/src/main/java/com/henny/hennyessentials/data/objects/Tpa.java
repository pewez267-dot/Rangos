package com.henny.hennyessentials.data.objects;

import java.util.UUID;

public class Tpa {
    public UUID UUIDToTeleport;
    public UUID teleportToUUID;
    public UUID requestUUID;
    public String type;

    public Tpa(UUID UUIDToTeleport, UUID teleportToUUID, UUID requestUUID) {
        this.UUIDToTeleport = UUIDToTeleport;
        this.teleportToUUID = teleportToUUID;
        this.requestUUID = requestUUID;
    }
}
