package com.henny.hennyessentials.menu;

import com.henny.hennyessentials.CommonClass;
import com.henny.hennyessentials.command.TeleportCommands;
import com.henny.hennyessentials.config.ConfigManager;
import com.henny.hennyessentials.data.WarpData;
import com.henny.hennyessentials.data.objects.Warp;
import com.henny.hennyessentials.permission.Permissions;
import com.henny.hennyessentials.util.TextUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.jetbrains.annotations.NotNull;

public class WarpsMenu extends AbstractContainerMenu {
    private final SimpleContainer container;
    private final List<ItemStack> allItems;
    private int currentPage;
    private String currentCategory;
    private final int itemsPerPage = 26;
    private final int totalSlots = 54;
    private static final int PREV_PAGE_SLOT = 52;
    private static final int NEXT_PAGE_SLOT = 53;
    private final WarpData warpData;
    private UUID viewerUUID;

    public WarpsMenu(int id, Inventory playerInventory, WarpData warpData, UUID viewerUUID) {
        super(MenuType.GENERIC_9x6, id);
        this.currentPage = 0;
        this.currentCategory = null;
        this.itemsPerPage = 26;
        this.totalSlots = 54;
        this.warpData = warpData;
        this.container = new SimpleContainer(54);
        this.allItems = new ArrayList();
        this.viewerUUID = viewerUUID;
        for (int i = 0; i < this.container.getContainerSize(); i++) {
            addSlot(new Slot(this, this.container, i, 8 + ((i % 9) * 18), 18 + ((i / 9) * 18)) { // from class: com.henny.hennyessentials.menu.WarpsMenu.1
                public boolean mayPlace(ItemStack pStack) {
                    return false;
                }

                public boolean mayPickup(Player pPlayer) {
                    return false;
                }
            });
        }
        if (warpData.currentlyMoreThanOneCategory()) {
            loadCategoryItems();
        } else {
            loadDefaultItems();
        }
        populatePage();
    }

    private void loadDefaultItems() {
        this.allItems.clear();
        for (Warp warp : this.warpData.warps.values()) {
            if (!ConfigManager.CONFIG.permissionConfigs.permissionsRequiredForIndividualWarps || Permissions.permissionCheck(this.viewerUUID, "warp." + warp.name, CommonClass.minecraftServer)) {
                ItemStack warpItem = new ItemStack(Items.ENDER_PEARL);
                if (!warp.displayItem.isEmpty()) {
                    warpItem = warp.displayItem;
                }
                warpItem.setHoverName(Component.literal("Warp: " + warp.name));
                CompoundTag tag = new CompoundTag();
                tag.putString("he-warp", warp.name);
                warpItem.setTag(tag);
                this.allItems.add(warpItem);
            }
        }
    }

    private void loadCategoryItems() {
        this.allItems.clear();
        Set<String> addedCategories = new HashSet<>();
        Map<String, List<Warp>> warpsByCategory = new HashMap<>();
        for (Warp warp : this.warpData.warps.values()) {
            warpsByCategory.computeIfAbsent(warp.category != null ? warp.category : "default", k -> {
                return new ArrayList();
            }).add(warp);
        }
        for (Map.Entry<String, List<Warp>> entry : warpsByCategory.entrySet()) {
            String category = entry.getKey();
            List<Warp> warpsInCategory = entry.getValue();
            boolean hasCategoryPermission = Permissions.permissionCheck(this.viewerUUID, "warpcategory." + category, CommonClass.minecraftServer);
            boolean hasWarpPermission = warpsInCategory.stream().anyMatch(warp2 -> {
                return Permissions.permissionCheck(this.viewerUUID, "warp." + warp2.name, CommonClass.minecraftServer);
            });
            if (hasCategoryPermission || hasWarpPermission || !ConfigManager.CONFIG.permissionConfigs.permissionsRequiredForIndividualWarps) {
                if (!addedCategories.contains(category)) {
                    addedCategories.add(category);
                    ItemStack categoryItem = new ItemStack(Items.END_PORTAL_FRAME);
                    if (!warpsInCategory.get(0).categoryDisplayItem.isEmpty()) {
                        categoryItem = warpsInCategory.get(0).categoryDisplayItem;
                    }
                    categoryItem.setHoverName(Component.literal("Category: " + category));
                    CompoundTag tag = new CompoundTag();
                    tag.putString("he-category", category);
                    categoryItem.setTag(tag);
                    this.allItems.add(categoryItem);
                }
            }
        }
    }

    private void loadWarpsForCategory(String category) {
        this.allItems.clear();
        for (Map.Entry<String, Warp> entry : this.warpData.warps.entrySet()) {
            Warp warp = entry.getValue();
            String warpCategory = warp.category != null ? warp.category : "default";
            if (warpCategory.equals(category) && (!ConfigManager.CONFIG.permissionConfigs.permissionsRequiredForIndividualWarps || Permissions.permissionCheckList(this.viewerUUID, List.of("warp." + entry.getKey(), "warpcategory." + warpCategory), CommonClass.minecraftServer))) {
                ItemStack warpItem = new ItemStack(Items.ENDER_PEARL);
                if (!warp.displayItem.isEmpty()) {
                    warpItem = warp.displayItem;
                }
                warpItem.setHoverName(Component.literal("Warp: " + entry.getKey()));
                CompoundTag tag = new CompoundTag();
                tag.putString("he-warp", entry.getKey());
                warpItem.setTag(tag);
                this.allItems.add(warpItem);
            }
        }
        ItemStack backItem = new ItemStack(Items.BARRIER);
        backItem.setHoverName(Component.literal("Back to Categories"));
        CompoundTag tag2 = new CompoundTag();
        tag2.putBoolean("he-back", true);
        backItem.setTag(tag2);
        this.allItems.add(backItem);
    }

    public void clicked(int slotId, int button, @NotNull ClickType clickType, @NotNull Player player) {
        if (player instanceof ServerPlayer) {
            if (slotId == PREV_PAGE_SLOT) {
                if (this.currentPage > 0) {
                    this.currentPage--;
                    populatePage();
                    return;
                }
                return;
            }
            if (slotId == NEXT_PAGE_SLOT) {
                if (this.currentPage < getMaxPage()) {
                    this.currentPage++;
                    populatePage();
                    return;
                }
                return;
            }
            if (slotId < 0 || slotId >= this.container.getContainerSize()) {
                return;
            }
            ItemStack clicked = getSlot(slotId).getItem();
            CompoundTag itemCustomData = clicked.hasTag() ? clicked.getTag() : new CompoundTag();
            if (itemCustomData.contains("he-warp")) {
                String warpName = itemCustomData.getString("he-warp");
                if (this.warpData.warps.containsKey(warpName)) {
                    Warp warp = this.warpData.warps.get(warpName);
                    String warpcat = warp.category;
                    if (warpcat == null || warpcat.isBlank()) {
                        warpcat = "default";
                    }
                    if (ConfigManager.CONFIG.permissionConfigs.permissionsRequiredForIndividualWarps && !Permissions.permissionCheckList(player.getUUID(), List.of("warp." + warpName, "warpcategory." + warpcat), CommonClass.minecraftServer)) {
                        player.sendSystemMessage(Component.literal("").append(TextUtils.formatMessage(ConfigManager.CONFIG.commandConfigs.warpConfigs.noPermissionForWarpMessage.replace("%warpname%", warpName))));
                        return;
                    }
                    if (!Permissions.cooldownChecker(player.getUUID(), Permissions.WARP_COMMAND_COOLDOWN_KEY)) {
                        Permissions.handleCooldownNotExpired((ServerPlayer) player, Permissions.WARP_COMMAND_COOLDOWN_KEY);
                        ((ServerPlayer) player).closeContainer();
                        return;
                    } else {
                        Permissions.updateCooldown(player.getUUID(), Permissions.WARP_COMMAND_COOLDOWN_KEY, System.currentTimeMillis() + (((long) ConfigManager.CONFIG.commandConfigs.warpConfigs.cooldownSeconds) * 1000));
                        GlobalPos pos = GlobalPos.of(ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(warp.dimension)), warp.blockPos);
                        TeleportCommands.teleportPlayer((ServerPlayer) player, pos, ConfigManager.CONFIG.commandConfigs.teleportConfigs.warpCommandWarmupSeconds, warp.rotation);
                        ((ServerPlayer) player).closeContainer();
                        return;
                    }
                }
                return;
            }
            if (itemCustomData.contains("he-category")) {
                this.currentCategory = itemCustomData.getString("he-category");
                loadWarpsForCategory(this.currentCategory);
                this.currentPage = 0;
                populatePage();
                return;
            }
            if (itemCustomData.contains("he-back")) {
                this.currentCategory = null;
                loadCategoryItems();
                this.currentPage = 0;
                populatePage();
            }
        }
    }

    public ItemStack quickMoveStack(Player player, int i) {
        return ItemStack.EMPTY;
    }

    public boolean stillValid(Player player) {
        return true;
    }

    private void populatePage() {
        for (int i = 0; i < 26; i++) {
            this.container.setItem(i, ItemStack.EMPTY);
        }
        ItemStack blackGlass = new ItemStack(Items.BLACK_STAINED_GLASS_PANE);
        blackGlass.setHoverName(Component.literal("Henny Essentials Mod").withStyle(ChatFormatting.GREEN));
        ItemStack limeGlass = new ItemStack(Items.LIME_STAINED_GLASS_PANE);
        limeGlass.setHoverName(Component.literal("Henny Essentials Mod").withStyle(ChatFormatting.GREEN));
        int i2 = 0;
        while (i2 < 54) {
            boolean isBorder = i2 < 9 || i2 >= 45 || i2 % 9 == 0 || i2 % 9 == 8;
            if (isBorder && i2 != PREV_PAGE_SLOT && i2 != NEXT_PAGE_SLOT) {
                ItemStack glass = i2 % 2 == 0 ? blackGlass.copy() : limeGlass.copy();
                this.container.setItem(i2, glass);
            }
            i2++;
        }
        int start = this.currentPage * 26;
        int itemIndex = 0;
        int i3 = 0;
        while (i3 < 54) {
            boolean isBorder2 = i3 < 9 || i3 >= 45 || i3 % 9 == 0 || i3 % 9 == 8;
            if (!isBorder2 && i3 != PREV_PAGE_SLOT && i3 != NEXT_PAGE_SLOT) {
                int i4 = itemIndex;
                itemIndex++;
                int index = start + i4;
                if (index < this.allItems.size()) {
                    this.container.setItem(i3, this.allItems.get(index));
                }
            }
            i3++;
        }
        ItemStack nextPage = new ItemStack(Items.ARROW);
        nextPage.setHoverName(Component.literal("Next Page"));
        ItemStack prevPage = new ItemStack(Items.ARROW);
        prevPage.setHoverName(Component.literal("Previous Page"));
        this.container.setItem(PREV_PAGE_SLOT, this.currentPage > 0 ? prevPage : ItemStack.EMPTY);
        this.container.setItem(NEXT_PAGE_SLOT, this.currentPage < getMaxPage() ? nextPage : ItemStack.EMPTY);
    }

    private int getMaxPage() {
        return ((int) Math.ceil(((double) this.allItems.size()) / 26.0d)) - 1;
    }
}
