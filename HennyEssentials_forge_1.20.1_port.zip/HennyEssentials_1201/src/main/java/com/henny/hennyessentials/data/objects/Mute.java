package com.henny.hennyessentials.data.objects;

import java.util.UUID;

public class Mute {
    public UUID mutedPlayerUUID;
    public long muteExpiry;
    public String muteReason;

    public Mute(UUID mutedPlayerUUID, long muteExpiry, String muteReason) {
        this.muteExpiry = 0L;
        this.mutedPlayerUUID = mutedPlayerUUID;
        this.muteExpiry = muteExpiry;
        this.muteReason = muteReason;
    }

    public Mute(UUID mutedPlayerUUID, String muteReason) {
        this.muteExpiry = 0L;
        this.mutedPlayerUUID = mutedPlayerUUID;
        this.muteReason = muteReason;
    }
}
