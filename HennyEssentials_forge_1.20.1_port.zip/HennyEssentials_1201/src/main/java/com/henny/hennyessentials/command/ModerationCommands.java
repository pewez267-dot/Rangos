package com.henny.hennyessentials.command;

import com.henny.hennyessentials.CommonClass;
import com.henny.hennyessentials.config.ConfigManager;
import com.henny.hennyessentials.config.objects.BannedItemsConfig;
import com.henny.hennyessentials.data.PlayerData;
import com.henny.hennyessentials.data.objects.Ban;
import com.henny.hennyessentials.data.objects.Mute;
import com.henny.hennyessentials.menu.InvseeMenu;
import com.henny.hennyessentials.permission.Permissions;
import com.henny.hennyessentials.util.ModerationUtils;
import com.henny.hennyessentials.util.Pagination;
import com.henny.hennyessentials.util.TextUtils;
import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.UuidArgument;
import net.minecraft.commands.arguments.item.ItemArgument;
import net.minecraft.commands.arguments.item.ItemInput;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.data.registries.VanillaRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtAccounter;
import net.minecraft.nbt.NbtIo;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ClientInformation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.players.GameProfileCache;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.ChatVisiblity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.storage.LevelResource;

public class ModerationCommands {
    public static List<LiteralArgumentBuilder<CommandSourceStack>> buildModerationCommands() {
        ArrayList<LiteralArgumentBuilder<CommandSourceStack>> returnList = new ArrayList<>();
        LiteralArgumentBuilder<CommandSourceStack> rulesCommand = Commands.literal("rules");
        rulesCommand.executes(ModerationCommands::executeRules);
        rulesCommand.requires(src -> {
            return ModCommands.getPlayerRequirements(src, (List<String>) List.of(Permissions.USER_PERMISSIONS, "command.he.banitem"));
        });
        returnList.add(rulesCommand);
        LiteralArgumentBuilder<CommandSourceStack> broadcastCommand = Commands.literal("broadcast").requires(src2 -> {
            return ModCommands.getRequirements(src2, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_BROADCAST_PERMISSION));
        });
        broadcastCommand.then(Commands.argument("broadcastString", StringArgumentType.string()).executes(ModerationCommands::executeBroadcast).requires(src3 -> {
            return ModCommands.getRequirements(src3, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_BROADCAST_PERMISSION));
        }).then(Commands.argument("bypassHiddenChat?", BoolArgumentType.bool()).executes(ModerationCommands::executeBroadcast).requires(src4 -> {
            return ModCommands.getRequirements(src4, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_BROADCAST_PERMISSION));
        })));
        returnList.add(broadcastCommand);
        LiteralArgumentBuilder<CommandSourceStack> banCommand = Commands.literal("ban").then(Commands.argument("playername", StringArgumentType.word()).then(Commands.argument("reason", StringArgumentType.greedyString()).executes(ModerationCommands::executeBan).requires(src5 -> {
            return ModCommands.getRequirements(src5, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_BAN_PERMISSION));
        })));
        banCommand.requires(src6 -> {
            return ModCommands.getRequirements(src6, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_BAN_PERMISSION));
        });
        LiteralArgumentBuilder<CommandSourceStack> banUUIDCommand = Commands.literal("banuuid").then(Commands.argument("playerUUID", UuidArgument.uuid()).then(Commands.argument("reason", StringArgumentType.greedyString()).executes(ModerationCommands::executeBanUUID).requires(src7 -> {
            return ModCommands.getRequirements(src7, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_BAN_UUID_PERMISSION));
        })));
        banUUIDCommand.requires(src8 -> {
            return ModCommands.getRequirements(src8, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_BAN_UUID_PERMISSION));
        });
        LiteralArgumentBuilder<CommandSourceStack> tempBanCommand = Commands.literal("tempban").then(Commands.argument("playername", StringArgumentType.word()).then(Commands.argument("duration", StringArgumentType.string()).then(Commands.argument("reason", StringArgumentType.greedyString()).executes(ModerationCommands::executeTempBan).requires(src9 -> {
            return ModCommands.getRequirements(src9, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_TEMP_BAN_PERMISSION));
        }))));
        tempBanCommand.requires(src10 -> {
            return ModCommands.getRequirements(src10, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_TEMP_BAN_PERMISSION));
        });
        LiteralArgumentBuilder<CommandSourceStack> muteCommand = Commands.literal("mute").then(Commands.argument("playername", StringArgumentType.word()).then(Commands.argument("reason", StringArgumentType.greedyString()).executes(ModerationCommands::executeMute).requires(src11 -> {
            return ModCommands.getRequirements(src11, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_MUTE_PERMISSION));
        })));
        muteCommand.requires(src12 -> {
            return ModCommands.getRequirements(src12, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_MUTE_PERMISSION));
        });
        LiteralArgumentBuilder<CommandSourceStack> tempMuteCommand = Commands.literal("tempmute").then(Commands.argument("playername", StringArgumentType.word()).then(Commands.argument("duration", StringArgumentType.string()).then(Commands.argument("reason", StringArgumentType.greedyString()).executes(ModerationCommands::executeTempMute).requires(src13 -> {
            return ModCommands.getRequirements(src13, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_TEMP_MUTE_PERMISSION));
        }))));
        tempMuteCommand.requires(src14 -> {
            return ModCommands.getRequirements(src14, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_TEMP_MUTE_PERMISSION));
        });
        LiteralArgumentBuilder<CommandSourceStack> unmuteCommand = Commands.literal("unmute").then(Commands.argument("playername", StringArgumentType.string()).executes(ModerationCommands::executeUnmute).requires(src15 -> {
            return ModCommands.getRequirements(src15, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_UNMUTE_PERMISSION));
        }));
        unmuteCommand.requires(src16 -> {
            return ModCommands.getRequirements(src16, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_UNMUTE_PERMISSION));
        });
        LiteralArgumentBuilder<CommandSourceStack> unbanCommand = Commands.literal("unban").then(Commands.argument("playername", StringArgumentType.string()).executes(ModerationCommands::executeUnban).requires(src17 -> {
            return ModCommands.getRequirements(src17, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_UNBAN_PERMISSION));
        }));
        unbanCommand.requires(src18 -> {
            return ModCommands.getRequirements(src18, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_UNBAN_PERMISSION));
        });
        LiteralArgumentBuilder<CommandSourceStack> unbanUUIDCommand = Commands.literal("unbanUUID").then(Commands.argument("uuid", UuidArgument.uuid()).executes(ModerationCommands::executeUnbanUUID).requires(src19 -> {
            return ModCommands.getRequirements(src19, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, "command.he.unbanuuid"));
        }));
        unbanUUIDCommand.requires(src20 -> {
            return ModCommands.getRequirements(src20, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, "command.he.unbanuuid"));
        });
        LiteralArgumentBuilder<CommandSourceStack> invseeCommand = Commands.literal("invsee").then(Commands.argument("playername", EntityArgument.player()).executes(ctx -> {
            if (!((CommandSourceStack) ctx.getSource()).isPlayer()) {
                return 1;
            }
            ServerPlayer p = ((CommandSourceStack) ctx.getSource()).getPlayer();
            ServerPlayer target = EntityArgument.getPlayer(ctx, "playername");
            p.openMenu(new SimpleMenuProvider((windowId, inv, player) -> {
                return new InvseeMenu(windowId, inv, target.getInventory(), false, target.getUUID());
            }, Component.literal("Inventory of " + target.getGameProfile().getName())));
            return 1;
        }));
        LiteralArgumentBuilder<CommandSourceStack> invseeOfflineCommand = Commands.literal("invseeoffline").then(Commands.argument("playername", StringArgumentType.word()).executes(ctx2 -> {
            if (!((CommandSourceStack) ctx2.getSource()).isPlayer()) {
                return 1;
            }
            ServerPlayer p = ((CommandSourceStack) ctx2.getSource()).getPlayer();
            ((CommandSourceStack) ctx2.getSource()).getServer().getProfileCache().get(StringArgumentType.getString(ctx2, "playername")).ifPresentOrElse(gameProfile -> {
                Path datfile = CommonClass.minecraftServer.getWorldPath(LevelResource.PLAYER_DATA_DIR).resolve(String.valueOf(gameProfile.getId()) + ".dat");
                try {
                    InputStream is = Files.newInputStream(datfile, new OpenOption[0]);
                    try {
                        CompoundTag playerTag = NbtIo.readCompressed(is, NbtAccounter.unlimitedHeap());
                        if (is != null) {
                            is.close();
                        }
                        ListTag inventoryList = playerTag.getList("Inventory", 10);
                        ServerPlayer sp = new ServerPlayer(CommonClass.minecraftServer, CommonClass.minecraftServer.overworld(), gameProfile, new ClientInformation("en", 1, ChatVisiblity.HIDDEN, false, 0, HumanoidArm.LEFT, false, false));
                        sp.getInventory().load(inventoryList);
                        p.openMenu(new SimpleMenuProvider((windowId, inv, player) -> {
                            return new InvseeMenu(windowId, inv, sp.getInventory(), true, gameProfile.getId());
                        }, Component.literal("Inventory of " + sp.getGameProfile().getName())));
                    } finally {
                    }
                } catch (IOException e) {
                    ((CommandSourceStack) ctx2.getSource()).sendSystemMessage(TextUtils.formatMessage("Error opening player inventory."));
                }
            }, () -> {
                ((CommandSourceStack) ctx2.getSource()).sendSystemMessage(TextUtils.formatMessage("Couldn't find that player"));
            });
            return 1;
        }));
        invseeCommand.requires(src21 -> {
            return ModCommands.getRequirements(src21, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_INVSEE_PERMISSION));
        });
        invseeOfflineCommand.requires(src22 -> {
            return ModCommands.getRequirements(src22, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_INVSEE_PERMISSION));
        });
        returnList.add(invseeCommand);
        returnList.add(invseeOfflineCommand);
        LiteralArgumentBuilder<CommandSourceStack> banHeldItemCommand = Commands.literal("banHeldItem").then(Commands.argument("reason", StringArgumentType.greedyString()).executes(context -> {
            ItemStack item = ((CommandSourceStack) context.getSource()).getPlayer().getItemInHand(InteractionHand.MAIN_HAND);
            if (!item.is(Items.AIR)) {
                ConfigManager.bannedItemsConfig.addBannedItems(BuiltInRegistries.ITEM.getKey(((CommandSourceStack) context.getSource()).getPlayer().getItemInHand(InteractionHand.MAIN_HAND).getItem()).toString(), StringArgumentType.getString(context, "reason"));
                return 1;
            }
            ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("You cannot ban Air!"));
            return 1;
        }).requires(src23 -> {
            return ModCommands.getRequirements(src23, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_BAN_HELD_ITEM_PERMISSION));
        }));
        banHeldItemCommand.requires(src24 -> {
            return ModCommands.getRequirements(src24, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_BAN_HELD_ITEM_PERMISSION));
        });
        LiteralArgumentBuilder<CommandSourceStack> banItemCommand = Commands.literal("banItem").then(Commands.argument("item", ItemArgument.item(Commands.createValidationContext(VanillaRegistries.createLookup()))).then(Commands.argument("reason", StringArgumentType.greedyString()).executes(context2 -> {
            ItemInput item = ItemArgument.getItem(context2, "item");
            if (!item.createItemStack(1, false).is(Items.AIR)) {
                ConfigManager.bannedItemsConfig.addBannedItems(BuiltInRegistries.ITEM.getKey(item.getItem()).toString(), StringArgumentType.getString(context2, "reason"));
                return 1;
            }
            ((CommandSourceStack) context2.getSource()).sendSystemMessage(TextUtils.formatMessage("You cannot ban Air!"));
            return 1;
        }).requires(src25 -> {
            return ModCommands.getRequirements(src25, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, "command.he.banitem"));
        })));
        LiteralArgumentBuilder<CommandSourceStack> removeBannedItemCommand = Commands.literal("removeBannedItem").then(Commands.argument("itemID", ItemArgument.item(Commands.createValidationContext(VanillaRegistries.createLookup()))).executes(ctx3 -> {
            ItemInput item = ItemArgument.getItem(ctx3, "itemID");
            if (!item.createItemStack(1, false).isEmpty()) {
                String id = BuiltInRegistries.ITEM.getKey(item.getItem()).toString();
                ConfigManager.bannedItemsConfig.removeBannedItems(id);
                ((CommandSourceStack) ctx3.getSource()).sendSystemMessage(TextUtils.formatAndHighlight("Banned item with ID: [" + id + "] was removed from the Banned Items list."));
                return 1;
            }
            ((CommandSourceStack) ctx3.getSource()).sendSystemMessage(TextUtils.formatAndHighlight("Couldn't find that item on the Banned Items list."));
            return 1;
        }).requires(src26 -> {
            return ModCommands.getRequirements(src26, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_REMOVE_BANNED_ITEM_PERMISSION));
        }));
        removeBannedItemCommand.requires(src27 -> {
            return ModCommands.getRequirements(src27, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.MODERATION_REMOVE_BANNED_ITEM_PERMISSION));
        });
        LiteralArgumentBuilder<CommandSourceStack> listBannedItemsCommand = Commands.literal("banneditems");
        listBannedItemsCommand.executes(ModerationCommands::executeListBannedItems);
        listBannedItemsCommand.requires(src28 -> {
            return ModCommands.getPlayerRequirements(src28, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.MODERATION_LIST_BANNED_ITEMS_PERMISSION));
        });
        banItemCommand.requires(src29 -> {
            return ModCommands.getRequirements(src29, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, "command.he.banitem"));
        });
        returnList.add(banItemCommand);
        returnList.add(banHeldItemCommand);
        returnList.add(removeBannedItemCommand);
        returnList.add(listBannedItemsCommand);
        returnList.add(banCommand);
        returnList.add(banUUIDCommand);
        returnList.add(tempBanCommand);
        returnList.add(muteCommand);
        returnList.add(tempMuteCommand);
        returnList.add(unbanCommand);
        returnList.add(unbanUUIDCommand);
        returnList.add(unmuteCommand);
        return returnList;
    }

    private static int executeBroadcast(CommandContext<CommandSourceStack> ctx) {
        String string = StringArgumentType.getString(ctx, "broadcastString");
        boolean bypass = false;
        boolean hasBypass = ctx.getNodes().stream().anyMatch(node -> {
            return node.getNode().getName().equals("bypassHiddenChat?");
        });
        if (hasBypass) {
            bypass = BoolArgumentType.getBool(ctx, "bypassHiddenChat?");
        }
        CommonClass.minecraftServer.getPlayerList().broadcastSystemMessage(TextUtils.getModPrefix().append(Component.literal(string.replace("&", "§"))), bypass);
        return 1;
    }

    private static int executeRules(CommandContext<CommandSourceStack> ctx) {
        if (!((CommandSourceStack) ctx.getSource()).isPlayer()) {
            return 1;
        }
        ArrayList<MutableComponent> returnComps = new ArrayList<>();
        for (String rule : ConfigManager.CONFIG.moderationConfigs.rulesConfigs.rules) {
            returnComps.add(Component.literal(rule));
        }
        new Pagination.PaginationBuilder(((CommandSourceStack) ctx.getSource()).getPlayer(), returnComps).header(ConfigManager.CONFIG.moderationConfigs.rulesConfigs.rulesPageHeader).padding(ConfigManager.CONFIG.moderationConfigs.rulesConfigs.rulesPagePadding).linesPerPage(ConfigManager.CONFIG.moderationConfigs.rulesConfigs.rulesPerPage).build().send();
        return 1;
    }

    private static int executeListBannedItems(CommandContext<CommandSourceStack> ctx) {
        List<MutableComponent> componentsToSend = new ArrayList<>();
        if (!((CommandSourceStack) ctx.getSource()).isPlayer()) {
            return 1;
        }
        for (Map.Entry<String, BannedItemsConfig.BannedItem> entry : ConfigManager.BANNED_ITEMS_MAP.entrySet()) {
            MutableComponent individualComp = Component.literal("");
            MutableComponent id = Component.literal(entry.getKey()).withStyle(ChatFormatting.GREEN);
            MutableComponent separator = Component.literal(ConfigManager.CONFIG.moderationConfigs.bannedItemsConfigs.bannedItemsListSeparator);
            MutableComponent reason = Component.literal(entry.getValue().reason()).withStyle(ChatFormatting.GREEN);
            individualComp.append(id).append(separator).append(reason);
            componentsToSend.add(individualComp);
        }
        if (!componentsToSend.isEmpty()) {
            new Pagination.PaginationBuilder(((CommandSourceStack) ctx.getSource()).getPlayer(), componentsToSend).header(ConfigManager.CONFIG.moderationConfigs.bannedItemsConfigs.bannedItemsListHeader).linesPerPage(ConfigManager.CONFIG.moderationConfigs.bannedItemsConfigs.bannedItemsPerPage).padding(ConfigManager.CONFIG.moderationConfigs.bannedItemsConfigs.bannedItemsListPadding).build().send();
            return 1;
        }
        return 1;
    }

    private static int executeBan(CommandContext<CommandSourceStack> context) {
        String playerName = StringArgumentType.getString(context, "playername");
        MinecraftServer server = ((CommandSourceStack) context.getSource()).getServer();
        String reason = StringArgumentType.getString(context, "reason");
        GameProfileCache cache = ((CommandSourceStack) context.getSource()).getServer().getProfileCache();
        if (cache.get(playerName).isPresent()) {
            GameProfile gameprofile = (GameProfile) cache.get(playerName).get();
            UUID uuid = gameprofile.getId();
            for (ServerPlayer next : new ArrayList(server.getPlayerList().getPlayers())) {
                if (next.getUUID().equals(gameprofile.getId())) {
                    next.connection.disconnect(Component.literal("You have been banned from this server for: " + reason + "\nThis ban is permanent.").withStyle(ChatFormatting.RED));
                }
            }
            PlayerData.getUserData(server).updateBanList(new Ban(uuid, reason));
            if (ConfigManager.CONFIG.moderationConfigs.auditConfigs.shouldWriteBansToAuditLog) {
                ModerationUtils.writeToAuditLog("BAN", playerName + " was banned by: " + ((CommandSourceStack) context.getSource()).getTextName());
                return 1;
            }
            return 1;
        }
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessageWithHighlight("Could not locate game profile for user: ", playerName, ". Make sure you have spelled the username corretly."));
        return 1;
    }

    private static int executeBanUUID(CommandContext<CommandSourceStack> context) {
        UUID uuid = UuidArgument.getUuid(context, "playerUUID");
        MinecraftServer server = ((CommandSourceStack) context.getSource()).getServer();
        String reason = StringArgumentType.getString(context, "reason");
        ((CommandSourceStack) context.getSource()).getServer().getProfileCache();
        PlayerData.getUserData(server).updateBanList(new Ban(uuid, reason));
        if (ConfigManager.CONFIG.moderationConfigs.auditConfigs.shouldWriteBansToAuditLog) {
            ModerationUtils.writeToAuditLog("BAN", String.valueOf(uuid) + " was banned by: " + ((CommandSourceStack) context.getSource()).getTextName());
        }
        for (ServerPlayer serverPlayer : new ArrayList(server.getPlayerList().getPlayers())) {
            if (serverPlayer.getUUID().equals(uuid)) {
                serverPlayer.connection.disconnect(Component.literal("You have been banned from this server for: " + reason + "\nThis ban is permanent."));
            }
        }
        return 1;
    }

    private static int executeTempBan(CommandContext<CommandSourceStack> context) {
        String playerName = StringArgumentType.getString(context, "playername");
        MinecraftServer server = ((CommandSourceStack) context.getSource()).getServer();
        String reason = StringArgumentType.getString(context, "reason");
        String duration = StringArgumentType.getString(context, "duration");
        if (!TextUtils.canBeParsed(duration)) {
            TextUtils.sendParseError((CommandSourceStack) context.getSource(), duration);
            return 1;
        }
        GameProfileCache cache = ((CommandSourceStack) context.getSource()).getServer().getProfileCache();
        if (cache.get(playerName).isPresent()) {
            GameProfile gameprofile = (GameProfile) cache.get(playerName).get();
            UUID uuid = gameprofile.getId();
            long durationMillis = Duration.parse(TextUtils.parseToISO8601(duration)).toMillis();
            long expiry = System.currentTimeMillis() + durationMillis;
            for (ServerPlayer serverPlayer : new ArrayList(server.getPlayerList().getPlayers())) {
                if (serverPlayer.getUUID().equals(gameprofile.getId())) {
                    serverPlayer.connection.disconnect(Component.literal("You have been banned from this server for: " + reason + "\nThis ban is will expire in: " + TextUtils.readableDuration(expiry - System.currentTimeMillis()) + ".").withStyle(ChatFormatting.RED));
                }
            }
            Ban ban = new Ban(uuid, expiry, reason);
            PlayerData.getUserData(server).updateBanList(ban);
            if (ConfigManager.CONFIG.moderationConfigs.auditConfigs.shouldWriteBansToAuditLog) {
                ModerationUtils.writeToAuditLog("TEMPBAN", playerName + " was temp banned for " + TextUtils.readableDuration(expiry - System.currentTimeMillis()) + " by: " + ((CommandSourceStack) context.getSource()).getTextName());
                return 1;
            }
            return 1;
        }
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessageWithHighlight("Could not locate game profile for user: ", playerName, ". Make sure you have spelled the username corretly."));
        return 1;
    }

    private static int executeMute(CommandContext<CommandSourceStack> context) {
        String playerName = StringArgumentType.getString(context, "playername");
        MinecraftServer server = ((CommandSourceStack) context.getSource()).getServer();
        String reason = StringArgumentType.getString(context, "reason");
        GameProfileCache cache = ((CommandSourceStack) context.getSource()).getServer().getProfileCache();
        if (cache.get(playerName).isPresent()) {
            GameProfile gameprofile = (GameProfile) cache.get(playerName).get();
            UUID uuid = gameprofile.getId();
            server.getPlayerList().getPlayers().forEach(serverPlayer -> {
                if (serverPlayer.getUUID().equals(gameprofile.getId())) {
                    serverPlayer.sendSystemMessage(TextUtils.formatMessageWithHighlight("You have been muted for: ", reason, "."));
                    serverPlayer.sendSystemMessage(TextUtils.formatMessage("Your messages can no longer be seen by others."));
                    ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessageWithHighlight("Player: ", playerName, " has been muted."));
                }
            });
            PlayerData.getUserData(server).updateMuteList(new Mute(uuid, reason));
            if (ConfigManager.CONFIG.moderationConfigs.auditConfigs.shouldWriteMutesToAuditLog) {
                ModerationUtils.writeToAuditLog("MUTE", playerName + " was muted by: " + ((CommandSourceStack) context.getSource()).getTextName());
                return 1;
            }
            return 1;
        }
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessageWithHighlight("Could not locate game profile for user: ", playerName, ". Make sure you have spelled the username correctly."));
        return 1;
    }

    private static int executeTempMute(CommandContext<CommandSourceStack> context) {
        String playerName = StringArgumentType.getString(context, "playername");
        MinecraftServer server = ((CommandSourceStack) context.getSource()).getServer();
        String reason = StringArgumentType.getString(context, "reason");
        String duration = StringArgumentType.getString(context, "duration");
        if (!TextUtils.canBeParsed(duration)) {
            TextUtils.sendParseError((CommandSourceStack) context.getSource(), duration);
            return 1;
        }
        GameProfileCache cache = ((CommandSourceStack) context.getSource()).getServer().getProfileCache();
        if (cache.get(playerName).isPresent()) {
            GameProfile gameprofile = (GameProfile) cache.get(playerName).get();
            UUID uuid = gameprofile.getId();
            long durationMillis = Duration.parse(TextUtils.parseToISO8601(duration)).toMillis();
            long expiry = System.currentTimeMillis() + durationMillis;
            server.getPlayerList().getPlayers().forEach(serverPlayer -> {
                if (serverPlayer.getUUID().equals(gameprofile.getId())) {
                    serverPlayer.sendSystemMessage(TextUtils.formatMessageWithHighlight("You have been temporarily muted for reason: ", reason, "."));
                    serverPlayer.sendSystemMessage(TextUtils.formatMessageWithHighlight("Your mute will expire in: ", TextUtils.readableDuration(expiry - System.currentTimeMillis()), "."));
                    ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessageWithHighlight("Player: ", playerName, " has been muted."));
                    ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessageWithHighlight("Their mute will expire in: ", TextUtils.readableDuration(expiry - System.currentTimeMillis()), "."));
                }
            });
            Mute mute = new Mute(uuid, expiry, reason);
            PlayerData.getUserData(server).updateMuteList(mute);
            if (ConfigManager.CONFIG.moderationConfigs.auditConfigs.shouldWriteMutesToAuditLog) {
                ModerationUtils.writeToAuditLog("TEMPMUTE", playerName + " was temp muted for " + TextUtils.readableDuration(expiry - System.currentTimeMillis()) + " by: " + ((CommandSourceStack) context.getSource()).getTextName());
                return 1;
            }
            return 1;
        }
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessageWithHighlight("Could not locate game profile for user: ", playerName, ". Make sure you have spelled the username corretly."));
        return 1;
    }

    private static int executeUnmute(CommandContext<CommandSourceStack> context) {
        String playerName = StringArgumentType.getString(context, "playername");
        MinecraftServer server = ((CommandSourceStack) context.getSource()).getServer();
        GameProfileCache cache = ((CommandSourceStack) context.getSource()).getServer().getProfileCache();
        if (cache.get(playerName).isPresent()) {
            PlayerData.getUserData(server).unmutePlayer(((GameProfile) cache.get(playerName).get()).getId());
            if (ConfigManager.CONFIG.moderationConfigs.auditConfigs.shouldWriteMutesToAuditLog) {
                ModerationUtils.writeToAuditLog("UNMUTE", playerName + " was unmuted by: " + ((CommandSourceStack) context.getSource()).getTextName());
            }
            ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Player has been unmuted."));
            return 1;
        }
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Error finding game profile for user: " + playerName));
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Could not unmute player."));
        return 1;
    }

    private static int executeUnban(CommandContext<CommandSourceStack> context) {
        String playerName = StringArgumentType.getString(context, "playername");
        MinecraftServer server = ((CommandSourceStack) context.getSource()).getServer();
        GameProfileCache cache = ((CommandSourceStack) context.getSource()).getServer().getProfileCache();
        if (cache.get(playerName).isPresent()) {
            PlayerData.getUserData(server).unbanPlayer(((GameProfile) cache.get(playerName).get()).getId());
            if (ConfigManager.CONFIG.moderationConfigs.auditConfigs.shouldWriteBansToAuditLog) {
                ModerationUtils.writeToAuditLog("UNBAN", playerName + " was unbanned by: " + ((CommandSourceStack) context.getSource()).getTextName());
            }
            ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Player has been unbanned."));
            return 1;
        }
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Error finding game profile for user: " + playerName));
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Could not unban player."));
        return 1;
    }

    private static int executeUnbanUUID(CommandContext<CommandSourceStack> context) {
        UUID uuid = UuidArgument.getUuid(context, "uuid");
        PlayerData.getUserData(((CommandSourceStack) context.getSource()).getServer()).unbanPlayer(uuid);
        if (ConfigManager.CONFIG.moderationConfigs.auditConfigs.shouldWriteBansToAuditLog) {
            ModerationUtils.writeToAuditLog("UNBAN", String.valueOf(uuid) + " was unbanned by: " + ((CommandSourceStack) context.getSource()).getTextName());
        }
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Player has been unbanned."));
        return 1;
    }
}
