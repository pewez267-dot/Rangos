package com.henny.hennyessentials.data;

import com.henny.hennyessentials.data.objects.Warp;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.datafix.DataFixTypes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.saveddata.SavedData;

public class WarpData extends SavedData {
    public Map<String, Warp> warps;

    public static SavedData.Factory<WarpData> factory() {
        return new SavedData.Factory<>(WarpData::new, WarpData::load, DataFixTypes.LEVEL);
    }

    private static WarpData load(CompoundTag compoundTag, HolderLookup.Provider provider) {
        Map<String, Warp> warpListTemp = new HashMap<>();
        CompoundTag warpsTag = compoundTag.getCompound("warps");
        for (String key : warpsTag.getAllKeys()) {
            String warpName = key.toLowerCase();
            Warp warp = new Warp(warpName, (BlockPos) NbtUtils.readBlockPos(warpsTag.getCompound(key), "blockPos").orElse(BlockPos.ZERO), warpsTag.getCompound(key).getString("dimension"), warpsTag.getCompound(key).getLong("expiry"));
            if (warpsTag.getCompound(key).contains("displayItem")) {
                ItemStack displayItem = ItemStack.parseOptional(provider, warpsTag.getCompound(key).get("displayItem"));
                warp.displayItem = displayItem;
            }
            if (warpsTag.getCompound(key).contains("categoryDisplayItem")) {
                ItemStack categoryDisplayItem = ItemStack.parseOptional(provider, warpsTag.getCompound(key).get("categoryDisplayItem"));
                warp.categoryDisplayItem = categoryDisplayItem;
            }
            if (warpsTag.getCompound(key).contains("category")) {
                warp.category = warpsTag.getCompound(key).getString("category");
            }
            if (warpsTag.getCompound(key).contains("rotation")) {
                warp.rotation = warpsTag.getCompound(key).getFloat("rotation");
            }
            warp.displayItem = ItemStack.parseOptional(provider, warpsTag.getCompound(key).getCompound("displayItem"));
            warp.categoryDisplayItem = ItemStack.parseOptional(provider, warpsTag.getCompound(key).getCompound("categoryDisplayItem"));
            warpListTemp.put(warpName, warp);
        }
        return new WarpData(warpListTemp);
    }

    public WarpData() {
        this.warps = new HashMap();
    }

    public WarpData(Map<String, Warp> warps) {
        this.warps = warps;
    }

    public CompoundTag save(CompoundTag compoundTag, HolderLookup.Provider provider) {
        CompoundTag warpList = new CompoundTag();
        for (Warp warp : this.warps.values()) {
            warp.name = warp.name.toLowerCase();
            CompoundTag warpTag = new CompoundTag();
            warpTag.putString("name", warp.name.toLowerCase());
            warpTag.putString("category", warp.category);
            warpTag.putLong("expiry", warp.expiry);
            warpTag.put("blockPos", NbtUtils.writeBlockPos(warp.blockPos));
            warpTag.putString("dimension", warp.dimension);
            if (!warp.displayItem.isEmpty()) {
                warpTag.put("displayItem", warp.displayItem.save(provider));
            }
            if (!warp.displayItem.isEmpty()) {
                warpTag.put("categoryDisplayItem", warp.categoryDisplayItem.save(provider));
            }
            warpTag.putFloat("rotation", warp.rotation);
            warpList.put(warp.name, warpTag);
        }
        compoundTag.put("warps", warpList);
        return compoundTag;
    }

    public void addWarp(Warp warp) {
        warp.name = warp.name.toLowerCase();
        this.warps.put(warp.name, warp);
        setDirty();
    }

    public void removeWarp(String warpName) {
        this.warps.remove(warpName);
        setDirty();
    }

    public void setWarpCategory(String warpName, String category) {
        if (this.warps.containsKey(warpName)) {
            this.warps.get(warpName).category = category;
        }
        setDirty();
    }

    public void setWarpDisplayItem(String warpName, ItemStack item) {
        if (this.warps.containsKey(warpName)) {
            this.warps.get(warpName).displayItem = item.copy();
        }
        setDirty();
    }

    public void setCategoryDisplayItem(String categoryName, ItemStack item) {
        for (Warp k : this.warps.values()) {
            if (Objects.equals(k.category, categoryName)) {
                k.categoryDisplayItem = item.copy();
            }
        }
        setDirty();
    }

    public boolean currentlyMoreThanOneCategory() {
        HashSet<String> counter = new HashSet<>();
        for (Warp w : this.warps.values()) {
            counter.add(w.category);
        }
        return counter.size() != 1;
    }

    public void purgeExpired() {
        this.warps.entrySet().removeIf(entry -> {
            return ((Warp) entry.getValue()).expiry != 0 && System.currentTimeMillis() > ((Warp) entry.getValue()).expiry;
        });
        setDirty();
    }

    public static WarpData getWarpData(MinecraftServer minecraftServer) {
        return (WarpData) minecraftServer.overworld().getDataStorage().computeIfAbsent(factory(), "hennyessentials-warps");
    }
}
