package com.henny.hennyessentials.data.objects;

import com.google.gson.annotations.Expose;
import java.util.List;

public class Condition {

    @Expose
    public String type;

    @Expose
    public Object triggerValue;

    @Expose
    public List<String> commands;

    @Expose
    public String conditionID;

    public Condition(String conditionID, String type, Object triggerValue, List<String> commands) {
        this.conditionID = conditionID;
        this.type = type;
        this.triggerValue = triggerValue;
        this.commands = commands;
    }
}
