package com.henny.hennyessentials.command;

import com.henny.hennyessentials.CommonClass;
import com.henny.hennyessentials.data.PermissionGroupData;
import com.henny.hennyessentials.data.PermissionUserData;
import com.henny.hennyessentials.permission.Permissions;
import com.henny.hennyessentials.util.TextUtils;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.UuidArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerPlayer;

public class PermCommands {
    public static List<LiteralArgumentBuilder<CommandSourceStack>> buildUserPermCommands() {
        ArrayList<LiteralArgumentBuilder<CommandSourceStack>> returnList = new ArrayList<>();
        LiteralArgumentBuilder<CommandSourceStack> permissionBaseCommand = Commands.literal("permission");
        permissionBaseCommand.requires(src -> {
            return ModCommands.getRequirements(src, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, "he.permission"));
        });
        LiteralArgumentBuilder<CommandSourceStack> verboseCommand = Commands.literal("verbose").executes(PermCommands::executeVerbose);
        permissionBaseCommand.then(verboseCommand);
        LiteralArgumentBuilder<CommandSourceStack> permissionUserCommand = Commands.literal("user");
        LiteralArgumentBuilder<CommandSourceStack> permissionUUUIDCommand = Commands.literal("uuid");
        LiteralArgumentBuilder<CommandSourceStack> permissionGroupCommand = Commands.literal("group");
        LiteralArgumentBuilder<CommandSourceStack> prefixGroupGiveCommand = Commands.literal("addPrefix").then(Commands.argument("groupname", StringArgumentType.word()).then(Commands.argument("prefix", StringArgumentType.greedyString()).executes(PermCommands::executePrefixGiveGroup).requires(src2 -> {
            return ModCommands.getRequirements(src2, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PERMISSION_PREFIX_ADD_GROUP_PERMISSION));
        })));
        LiteralArgumentBuilder<CommandSourceStack> prefixGroupRemoveCommand = Commands.literal("removePrefix").then(Commands.argument("groupname", StringArgumentType.word()).executes(PermCommands::executeRemovePrefixGroup).requires(src3 -> {
            return ModCommands.getRequirements(src3, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PERMISSION_PREFIX_REMOVE_GROUP_PERMISSION));
        }));
        permissionGroupCommand.then(prefixGroupGiveCommand);
        permissionGroupCommand.then(prefixGroupRemoveCommand);
        LiteralArgumentBuilder<CommandSourceStack> prefixUserGiveCommand = Commands.literal("addPrefix").then(Commands.argument("username", EntityArgument.player()).then(Commands.argument("prefix", StringArgumentType.greedyString()).executes(PermCommands::executePrefixGiveUser).requires(src4 -> {
            return ModCommands.getRequirements(src4, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PERMISSION_PREFIX_ADD_USER_PERMISSION));
        })));
        LiteralArgumentBuilder<CommandSourceStack> prefixUserRemoveCommand = Commands.literal("removePrefix").then(Commands.argument("username", EntityArgument.player()).executes(PermCommands::executeRemovePrefixUser).requires(src5 -> {
            return ModCommands.getRequirements(src5, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PERMISSION_PREFIX_REMOVE_USER_PERMISSION));
        }));
        permissionUserCommand.then(prefixUserGiveCommand);
        permissionUserCommand.then(prefixUserRemoveCommand);
        LiteralArgumentBuilder<CommandSourceStack> suffixGroupGiveCommand = Commands.literal("addSuffix").then(Commands.argument("groupname", StringArgumentType.word()).then(Commands.argument("suffix", StringArgumentType.greedyString()).executes(PermCommands::executeSuffixGiveGroup).requires(src6 -> {
            return ModCommands.getRequirements(src6, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PERMISSION_SUFFIX_ADD_GROUP_PERMISSION));
        })));
        LiteralArgumentBuilder<CommandSourceStack> suffixGroupRemoveCommand = Commands.literal("removeSuffix").then(Commands.argument("groupname", StringArgumentType.word()).executes(PermCommands::executeRemoveSuffixGroup).requires(src7 -> {
            return ModCommands.getRequirements(src7, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PERMISSION_SUFFIX_REMOVE_GROUP_PERMISSION));
        }));
        permissionGroupCommand.then(suffixGroupGiveCommand);
        permissionGroupCommand.then(suffixGroupRemoveCommand);
        LiteralArgumentBuilder<CommandSourceStack> suffixUserGiveCommand = Commands.literal("addSuffix").then(Commands.argument("username", EntityArgument.player()).then(Commands.argument("suffix", StringArgumentType.greedyString()).executes(PermCommands::executeSuffixGiveUser).requires(src8 -> {
            return ModCommands.getRequirements(src8, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PERMISSION_SUFFIX_ADD_USER_PERMISSION));
        })));
        LiteralArgumentBuilder<CommandSourceStack> suffixUserRemoveCommand = Commands.literal("removeSuffix").then(Commands.argument("username", EntityArgument.player()).executes(PermCommands::executeRemoveSuffixUser).requires(src9 -> {
            return ModCommands.getRequirements(src9, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PERMISSION_SUFFIX_REMOVE_USER_PERMISSION));
        }));
        permissionUserCommand.then(suffixUserGiveCommand);
        permissionUserCommand.then(suffixUserRemoveCommand);
        LiteralArgumentBuilder<CommandSourceStack> permissionUserGiveCommand = Commands.literal("add").then(Commands.argument("playername", EntityArgument.player()).then(Commands.argument("permissionNode", StringArgumentType.greedyString()).executes(PermCommands::executePermissionGiveUser)));
        permissionUserGiveCommand.requires(src10 -> {
            return ModCommands.getRequirements(src10, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PERMISSION_ADD_USER_PERMISSION));
        });
        permissionUserCommand.then(permissionUserGiveCommand);
        LiteralArgumentBuilder<CommandSourceStack> permissionUUIDGiveCommand = Commands.literal("add").then(Commands.argument("playerUUID", UuidArgument.uuid()).then(Commands.argument("permissionNode", StringArgumentType.greedyString()).executes(PermCommands::executePermissionGiveUUID).requires(src11 -> {
            return ModCommands.getRequirements(src11, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PERMISSION_ADD_UUID_PERMISSION));
        })));
        permissionUUUIDCommand.then(permissionUUIDGiveCommand);
        LiteralArgumentBuilder<CommandSourceStack> permissionUUIDRemoveCommand = Commands.literal("remove").then(Commands.argument("playerUUID", UuidArgument.uuid()).then(Commands.argument("permissionNode", StringArgumentType.greedyString()).executes(PermCommands::executePermissionRemoveUUID).requires(src12 -> {
            return ModCommands.getRequirements(src12, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PERMISSION_REMOVE_UUID_PERMISSION));
        })));
        permissionUUUIDCommand.then(permissionUUIDRemoveCommand);
        LiteralArgumentBuilder<CommandSourceStack> permissionUserRemoveCommand = Commands.literal("remove").then(Commands.argument("playername", EntityArgument.player()).then(Commands.argument("permissionNode", StringArgumentType.greedyString()).executes(PermCommands::executePermissionRemoveUser).requires(src13 -> {
            return ModCommands.getRequirements(src13, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PERMISSION_REMOVE_USER_PERMISSION));
        })));
        permissionUserCommand.then(permissionUserRemoveCommand);
        LiteralArgumentBuilder<CommandSourceStack> permissionGroupGiveCommand = Commands.literal("add").then(Commands.argument("groupName", StringArgumentType.word()).then(Commands.argument("permissionNode", StringArgumentType.string()).executes(PermCommands::executePermissionGiveGroup).requires(src14 -> {
            return ModCommands.getRequirements(src14, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PERMISSION_ADD_GROUP_PERMISSION));
        })));
        permissionGroupCommand.then(permissionGroupGiveCommand);
        LiteralArgumentBuilder<CommandSourceStack> permissionGroupRemoveCommand = Commands.literal("remove").then(Commands.argument("groupName", StringArgumentType.word()).then(Commands.argument("permissionNode", StringArgumentType.string()).executes(PermCommands::executePermissionRemoveGroup).requires(src15 -> {
            return ModCommands.getRequirements(src15, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PERMISSION_REMOVE_GROUP_PERMISSION));
        })));
        permissionGroupCommand.then(permissionGroupRemoveCommand);
        permissionBaseCommand.then(permissionUserCommand);
        permissionBaseCommand.then(permissionGroupCommand);
        permissionBaseCommand.then(permissionUUUIDCommand);
        returnList.add(permissionBaseCommand);
        return returnList;
    }

    private static int executeInfoUser(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        ((CommandSourceStack) context.getSource()).getPlayer();
        EntityArgument.getPlayer(context, "userName");
        return 1;
    }

    private static int executeVerbose(CommandContext<CommandSourceStack> context) {
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        ServerPlayer ply = ((CommandSourceStack) context.getSource()).getPlayer();
        if (ply.getTags().contains("hessentials.verbose")) {
            ply.sendSystemMessage(TextUtils.formatMessage("Verbose disabled"));
            ply.removeTag("hessentials.verbose");
            return 1;
        }
        ply.sendSystemMessage(TextUtils.formatMessage("Verbose enabled"));
        ply.addTag("hessentials.verbose");
        return 1;
    }

    private static int executePermissionGiveUser(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        ServerPlayer targetPlayer = EntityArgument.getPlayer(context, "playername");
        String permissionNode = StringArgumentType.getString(context, "permissionNode");
        PermissionUserData userPermData = PermissionUserData.getPermissionUserData(((CommandSourceStack) context.getSource()).getServer());
        userPermData.addUserPermission(targetPlayer.getUUID(), permissionNode);
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Permission node: " + permissionNode + " added to user: " + targetPlayer.getScoreboardName()));
        return 1;
    }

    private static int executePermissionRemoveUser(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        ServerPlayer targetPlayer = EntityArgument.getPlayer(context, "playername");
        String permissionNode = StringArgumentType.getString(context, "permissionNode");
        PermissionUserData userPermData = PermissionUserData.getPermissionUserData(((CommandSourceStack) context.getSource()).getServer());
        userPermData.removeUserPermission(targetPlayer.getUUID(), permissionNode);
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Permission node: " + permissionNode + " removed from user: " + targetPlayer.getScoreboardName()));
        return 1;
    }

    private static int executePermissionGiveUUID(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        UUID targetPlayer = UuidArgument.getUuid(context, "playerUUID");
        String permissionNode = StringArgumentType.getString(context, "permissionNode");
        PermissionUserData userPermData = PermissionUserData.getPermissionUserData(((CommandSourceStack) context.getSource()).getServer());
        userPermData.addUserPermission(targetPlayer, permissionNode);
        AtomicReference<String> pName = new AtomicReference<>("");
        CommonClass.minecraftServer.getProfileCache().get(targetPlayer).ifPresent(gp -> {
            pName.set(gp.getName());
        });
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Permission node: " + permissionNode + " added to user: " + (pName.get().isBlank() ? targetPlayer.toString() : pName.get())));
        return 1;
    }

    private static int executePermissionRemoveUUID(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        UUID targetPlayer = UuidArgument.getUuid(context, "playerUUID");
        String permissionNode = StringArgumentType.getString(context, "permissionNode");
        PermissionUserData userPermData = PermissionUserData.getPermissionUserData(((CommandSourceStack) context.getSource()).getServer());
        userPermData.removeUserPermission(targetPlayer, permissionNode);
        AtomicReference<String> pName = new AtomicReference<>("");
        CommonClass.minecraftServer.getProfileCache().get(targetPlayer).ifPresent(gp -> {
            pName.set(gp.getName());
        });
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Permission node: " + permissionNode + " removed from user: " + (pName.get().isBlank() ? targetPlayer.toString() : pName.get())));
        return 1;
    }

    private static int executePermissionGiveGroup(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        String targetGroup = StringArgumentType.getString(context, "groupName");
        String permissionNode = StringArgumentType.getString(context, "permissionNode");
        PermissionGroupData groupPermData = PermissionGroupData.getPermissionGroupData(((CommandSourceStack) context.getSource()).getServer());
        groupPermData.addGroupPermission(targetGroup, permissionNode);
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Permission node: " + permissionNode + " added to group: " + targetGroup));
        return 1;
    }

    private static int executePermissionRemoveGroup(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        String targetGroup = StringArgumentType.getString(context, "groupName");
        String permissionNode = StringArgumentType.getString(context, "permissionNode");
        PermissionGroupData groupPermData = PermissionGroupData.getPermissionGroupData(((CommandSourceStack) context.getSource()).getServer());
        groupPermData.removeGroupPermission(targetGroup, permissionNode);
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Permission node: " + permissionNode + " removed from group: " + targetGroup));
        return 1;
    }

    private static int executePrefixGiveGroup(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        MutableComponent prefixComponent;
        String targetGroup = StringArgumentType.getString(context, "groupname");
        String prefix = StringArgumentType.getString(context, "prefix");
        Component.literal("");
        if (prefix.contains("{")) {
            prefixComponent = Component.Serializer.fromJson(prefix, ((CommandSourceStack) context.getSource()).getServer().registryAccess());
        } else {
            prefixComponent = Component.literal(prefix);
        }
        PermissionGroupData groupPermData = PermissionGroupData.getPermissionGroupData(((CommandSourceStack) context.getSource()).getServer());
        groupPermData.addGroupPrefix(targetGroup, prefixComponent);
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Prefix: ").append(prefix).append(Component.literal(" added to group " + targetGroup).setStyle(Style.EMPTY.applyFormats(new ChatFormatting[]{ChatFormatting.GREEN}))));
        return 1;
    }

    private static int executePrefixGiveUser(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        MutableComponent prefixComponent;
        ServerPlayer targetUser = EntityArgument.getPlayer(context, "username");
        String prefix = StringArgumentType.getString(context, "prefix");
        Component.literal("");
        if (prefix.contains("{")) {
            prefixComponent = Component.Serializer.fromJson(prefix, ((CommandSourceStack) context.getSource()).getServer().registryAccess());
        } else {
            prefixComponent = Component.literal(prefix);
        }
        if (prefixComponent == null) {
            return 1;
        }
        PermissionUserData userPermData = PermissionUserData.getPermissionUserData(((CommandSourceStack) context.getSource()).getServer());
        userPermData.addUserPrefix(targetUser.getUUID(), prefixComponent);
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Prefix: ").append(prefixComponent).append(Component.literal(" added to user " + targetUser.getScoreboardName()).setStyle(Style.EMPTY.applyFormats(new ChatFormatting[]{ChatFormatting.GREEN}))));
        return 1;
    }

    private static int executeSuffixGiveGroup(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        MutableComponent suffixComponent;
        String targetGroup = StringArgumentType.getString(context, "groupname");
        String suffix = StringArgumentType.getString(context, "suffix");
        Component.literal("");
        if (suffix.contains("{")) {
            suffixComponent = Component.Serializer.fromJson(suffix, ((CommandSourceStack) context.getSource()).getServer().registryAccess());
        } else {
            suffixComponent = Component.literal(suffix);
        }
        if (suffixComponent == null) {
            return 1;
        }
        PermissionGroupData groupPermData = PermissionGroupData.getPermissionGroupData(((CommandSourceStack) context.getSource()).getServer());
        groupPermData.addGroupSuffix(targetGroup, suffixComponent);
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Suffix: ").append(suffixComponent).append(Component.literal(" added to group " + targetGroup).setStyle(Style.EMPTY.applyFormats(new ChatFormatting[]{ChatFormatting.GREEN}))));
        return 1;
    }

    private static int executeSuffixGiveUser(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        MutableComponent suffixComponent;
        ServerPlayer targetUser = EntityArgument.getPlayer(context, "username");
        String suffix = StringArgumentType.getString(context, "suffix");
        Component.literal("");
        if (suffix.contains("{")) {
            suffixComponent = Component.Serializer.fromJson(suffix, ((CommandSourceStack) context.getSource()).getServer().registryAccess());
        } else {
            suffixComponent = Component.literal(suffix);
        }
        if (suffixComponent == null) {
            return 1;
        }
        PermissionUserData userPermData = PermissionUserData.getPermissionUserData(((CommandSourceStack) context.getSource()).getServer());
        userPermData.addUserSuffix(targetUser.getUUID(), suffixComponent);
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Suffix: ").append(suffixComponent).append(Component.literal(" added to user " + targetUser.getScoreboardName()).setStyle(Style.EMPTY.applyFormats(new ChatFormatting[]{ChatFormatting.GREEN}))));
        return 1;
    }

    private static int executeRemovePrefixUser(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        ServerPlayer target = EntityArgument.getPlayer(context, "username");
        PermissionUserData.getPermissionUserData(((CommandSourceStack) context.getSource()).getServer()).removeUserPrefix(target.getUUID());
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Prefix removed."));
        return 1;
    }

    private static int executeRemoveSuffixUser(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        ServerPlayer target = EntityArgument.getPlayer(context, "username");
        PermissionUserData.getPermissionUserData(((CommandSourceStack) context.getSource()).getServer()).removeUserSuffix(target.getUUID());
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Suffix removed."));
        return 1;
    }

    private static int executeRemovePrefixGroup(CommandContext<CommandSourceStack> context) {
        String target = StringArgumentType.getString(context, "groupname");
        PermissionGroupData.getPermissionGroupData(((CommandSourceStack) context.getSource()).getServer()).removeGroupPrefix(target);
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Prefix removed."));
        return 1;
    }

    private static int executeRemoveSuffixGroup(CommandContext<CommandSourceStack> context) {
        String target = StringArgumentType.getString(context, "groupname");
        PermissionGroupData.getPermissionGroupData(((CommandSourceStack) context.getSource()).getServer()).removeGroupSuffix(target);
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("Suffix removed."));
        return 1;
    }
}
