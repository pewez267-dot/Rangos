package com.henny.hennyessentials.command;

import com.henny.hennyessentials.config.ConfigManager;
import com.henny.hennyessentials.data.objects.ConfigPage;
import com.henny.hennyessentials.permission.Permissions;
import com.henny.hennyessentials.util.Pagination;
import com.henny.hennyessentials.util.TextUtils;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

public class PageCommands {
    public static List<LiteralArgumentBuilder<CommandSourceStack>> buildPageCommands() {
        ArrayList<LiteralArgumentBuilder<CommandSourceStack>> returnList = new ArrayList<>();
        LiteralArgumentBuilder<CommandSourceStack> pageCommand = Commands.literal("page");
        pageCommand.requires(src -> {
            return ModCommands.getPlayerRequirements(src, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.PAGE_PERMISSION));
        });
        RequiredArgumentBuilder<CommandSourceStack, String> arg = Commands.argument("pageID", StringArgumentType.string());
        arg.suggests(PageCommands::suggestPages);
        arg.executes(ctx -> {
            String pageid = StringArgumentType.getString(ctx, "pageID");
            if (!ConfigManager.PAGES.containsKey(pageid)) {
                ((CommandSourceStack) ctx.getSource()).sendSystemMessage(TextUtils.formatAndHighlight("Could not find page with ID: [" + pageid + "]."));
                return 1;
            }
            ConfigPage page = ConfigManager.PAGES.get(pageid);
            ArrayList<MutableComponent> lines = new ArrayList<>();
            for (String line : page.content) {
                lines.add(Component.literal(line));
            }
            new Pagination.PaginationBuilder(((CommandSourceStack) ctx.getSource()).getPlayer(), lines).linesPerPage(page.linesPerPage).header(page.header).padding(page.padding).build().send();
            return 1;
        });
        arg.requires(src2 -> {
            return ModCommands.getPlayerRequirements(src2, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.PAGE_PERMISSION));
        });
        pageCommand.then(arg);
        LiteralArgumentBuilder<CommandSourceStack> reloadPagesConfigCommand = Commands.literal("reloadpages");
        reloadPagesConfigCommand.requires(src3 -> {
            return ModCommands.getRequirements(src3, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.PAGE_RELOADCONFIG_PERMISSION));
        });
        reloadPagesConfigCommand.executes(ctx2 -> {
            ConfigManager.reloadPagesConfig();
            ((CommandSourceStack) ctx2.getSource()).sendSystemMessage(TextUtils.formatMessage("Pages reloaded."));
            return 1;
        });
        pageCommand.then(reloadPagesConfigCommand);
        returnList.add(pageCommand);
        return returnList;
    }

    private static CompletableFuture<Suggestions> suggestPages(CommandContext<CommandSourceStack> context, SuggestionsBuilder builder) {
        for (String pageID : ConfigManager.PAGES.keySet()) {
            builder.suggest(pageID);
        }
        return builder.buildFuture();
    }
}
