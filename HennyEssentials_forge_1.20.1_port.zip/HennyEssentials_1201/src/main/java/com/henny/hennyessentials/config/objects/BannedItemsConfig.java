package com.henny.hennyessentials.config.objects;

import com.google.gson.annotations.Expose;
import com.henny.hennyessentials.Constants;
import com.henny.hennyessentials.config.ConfigManager;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.runtime.ObjectMethods;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class BannedItemsConfig {

    @Expose
    public List<BannedItem> bannedItems = new ArrayList();

    public static final class BannedItem extends Record {

        @Expose
        private final String id;

        @Expose
        private final String reason;

        public BannedItem(String id, String reason) {
            this.id = id;
            this.reason = reason;
        }

        @Override // java.lang.Record
        public final String toString() {
            return (String) ObjectMethods.bootstrap(MethodHandles.lookup(), "toString", MethodType.methodType(String.class, BannedItem.class), BannedItem.class, "id;reason", "FIELD:Lcom/henny/hennyessentials/config/objects/BannedItemsConfig$BannedItem;->id:Ljava/lang/String;", "FIELD:Lcom/henny/hennyessentials/config/objects/BannedItemsConfig$BannedItem;->reason:Ljava/lang/String;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final int hashCode() {
            return (int) ObjectMethods.bootstrap(MethodHandles.lookup(), "hashCode", MethodType.methodType(Integer.TYPE, BannedItem.class), BannedItem.class, "id;reason", "FIELD:Lcom/henny/hennyessentials/config/objects/BannedItemsConfig$BannedItem;->id:Ljava/lang/String;", "FIELD:Lcom/henny/hennyessentials/config/objects/BannedItemsConfig$BannedItem;->reason:Ljava/lang/String;").dynamicInvoker().invoke(this) /* invoke-custom */;
        }

        @Override // java.lang.Record
        public final boolean equals(Object o) {
            return (boolean) ObjectMethods.bootstrap(MethodHandles.lookup(), "equals", MethodType.methodType(Boolean.TYPE, BannedItem.class, Object.class), BannedItem.class, "id;reason", "FIELD:Lcom/henny/hennyessentials/config/objects/BannedItemsConfig$BannedItem;->id:Ljava/lang/String;", "FIELD:Lcom/henny/hennyessentials/config/objects/BannedItemsConfig$BannedItem;->reason:Ljava/lang/String;").dynamicInvoker().invoke(this, o) /* invoke-custom */;
        }

        public String id() {
            return this.id;
        }

        public String reason() {
            return this.reason;
        }
    }

    public void addBannedItems(String itemID, String reason) {
        try {
            this.bannedItems.add(new BannedItem(itemID, reason));
            ConfigManager.saveBannedItems();
            ConfigManager.loadBannedItems();
        } catch (Exception e) {
            Constants.LOG.info(e.getLocalizedMessage());
        }
    }

    public void removeBannedItems(String itemID) {
        try {
            ListIterator<BannedItem> li = this.bannedItems.listIterator();
            while (li.hasNext()) {
                BannedItem bitem = li.next();
                if (bitem.id.equals(itemID)) {
                    li.remove();
                }
            }
            ConfigManager.saveBannedItems();
            ConfigManager.loadBannedItems();
        } catch (Exception e) {
            Constants.LOG.info(e.getLocalizedMessage());
        }
    }
}
