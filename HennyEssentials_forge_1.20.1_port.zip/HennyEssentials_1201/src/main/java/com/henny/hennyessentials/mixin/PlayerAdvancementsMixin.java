package com.henny.hennyessentials.mixin;

import com.henny.hennyessentials.CommonClass;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.server.PlayerAdvancements;
import net.minecraft.server.level.ServerPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin({PlayerAdvancements.class})
public class PlayerAdvancementsMixin {

    @Shadow
    private ServerPlayer player;

    @WrapOperation(method = {"award"}, at = {@At(value = "INVOKE", target = "Ljava/util/Optional;ifPresent(Ljava/util/function/Consumer;)V")})
    private <T> void hideBroadcastIfVanished(Optional instance, Consumer<? super T> action, Operation<Void> original) {
        if (!CommonClass.playersInVanish.getOrDefault(this.player.getUUID(), false).booleanValue()) {
            original.call(instance, action);
        }
    }
}
