package com.henny.hennyessentials.data.objects;

import net.minecraft.core.GlobalPos;

public class SpawnPosData {
    public GlobalPos pos;
    public float rotation;

    public SpawnPosData() {
    }

    public SpawnPosData(GlobalPos pos, float rotation) {
        this.pos = pos;
        this.rotation = rotation;
    }
}
