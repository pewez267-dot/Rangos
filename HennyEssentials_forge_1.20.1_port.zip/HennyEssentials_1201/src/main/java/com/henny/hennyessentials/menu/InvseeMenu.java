package com.henny.hennyessentials.menu;

import com.henny.hennyessentials.CommonClass;
import com.henny.hennyessentials.Constants;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtAccounter;
import net.minecraft.nbt.NbtIo;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.LevelResource;

public class InvseeMenu extends AbstractContainerMenu {
    private final Inventory targetInventory;
    public boolean isOffline;
    public UUID targetUUID;

    public InvseeMenu(int windowId, Inventory viewerInventory, Inventory targetInventory, boolean isOffline, UUID targetUUID) {
        super(MenuType.GENERIC_9x4, windowId);
        this.targetInventory = targetInventory;
        this.isOffline = isOffline;
        this.targetUUID = targetUUID;
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(targetInventory, col + (row * 9) + 9, 8 + (col * 18), 18 + (row * 18)));
            }
        }
        for (int i = 0; i < 9; i++) {
            addSlot(new Slot(targetInventory, i, 8 + (i * 18), 72));
        }
        for (int row2 = 0; row2 < 3; row2++) {
            for (int col2 = 0; col2 < 9; col2++) {
                addSlot(new Slot(viewerInventory, col2 + (row2 * 9) + 9, 8 + (col2 * 18), 140 + (row2 * 18)));
            }
        }
        for (int i2 = 0; i2 < 9; i2++) {
            addSlot(new Slot(viewerInventory, i2, 8 + (i2 * 18), 198));
        }
    }

    public boolean stillValid(Player player) {
        return true;
    }

    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = (Slot) this.slots.get(index);
        if (!slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack originalStack = slot.getItem();
        ItemStack copy = originalStack.copy();
        int viewerEnd = this.slots.size();
        if (index < 36) {
            if (!moveItemStackTo(originalStack, 36, viewerEnd, false)) {
                return ItemStack.EMPTY;
            }
        } else if (!moveItemStackTo(originalStack, 0, 36, false)) {
            return ItemStack.EMPTY;
        }
        if (originalStack.isEmpty()) {
            slot.set(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        return copy;
    }

    public void removed(Player pPlayer) {
        if (this.isOffline) {
            for (ItemStack stack : this.targetInventory.items) {
                if (!stack.isEmpty()) {
                    saveInventoryToTag();
                }
            }
        }
    }

    public void saveInventoryToTag() {
        Path datfile = CommonClass.minecraftServer.getWorldPath(LevelResource.PLAYER_DATA_DIR).resolve(String.valueOf(this.targetUUID) + ".dat");
        try {
            InputStream is = Files.newInputStream(datfile, new OpenOption[0]);
            try {
                CompoundTag playerTag = NbtIo.readCompressed(is, NbtAccounter.unlimitedHeap());
                if (is != null) {
                    is.close();
                }
                ListTag newList = new ListTag();
                for (int i = 0; i < this.targetInventory.getContainerSize(); i++) {
                    ItemStack stack = this.targetInventory.getItem(i);
                    if (!stack.isEmpty()) {
                        CompoundTag itemTag = new CompoundTag();
                        itemTag.putByte("Slot", (byte) i);
                        newList.add(stack.save(CommonClass.minecraftServer.registryAccess(), itemTag));
                    }
                }
                playerTag.put("Inventory", newList);
                try {
                    OutputStream os = Files.newOutputStream(datfile, new OpenOption[0]);
                    try {
                        NbtIo.writeCompressed(playerTag, os);
                        if (os != null) {
                            os.close();
                        }
                    } finally {
                    }
                } catch (IOException e) {
                    Constants.LOG.info("Invsee offline error saving data: {}", e.getLocalizedMessage());
                }
            } finally {
            }
        } catch (IOException e2) {
        }
    }
}
