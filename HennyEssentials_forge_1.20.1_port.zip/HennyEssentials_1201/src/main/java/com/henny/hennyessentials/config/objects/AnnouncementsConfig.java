package com.henny.hennyessentials.config.objects;

import com.google.gson.annotations.Expose;
import com.henny.hennyessentials.data.objects.Announcement;
import java.util.ArrayList;
import java.util.List;

public class AnnouncementsConfig {

    @Expose
    public List<Announcement> announcements = new ArrayList<Announcement>() { // from class: com.henny.hennyessentials.config.objects.AnnouncementsConfig.1
        {
            add(new Announcement("§bThis example broadcast will appear every §610§b minutes!", 600));
            add(new Announcement("[\"\",{\"text\":\"This server is running\",\"color\":\"green\"},{\"text\":\" \"},{\"text\":\"Henny Essentials\",\"bold\":true,\"underlined\":true,\"color\":\"gold\",\"clickEvent\":{\"action\":\"open_url\",\"value\":\"https://modrinth.com/mod/henny-essentials\"},\"hoverEvent\":{\"action\":\"show_text\",\"contents\":\"Click to go to Henny Essentials mod page\"}}]", 300));
        }
    };
}
