package com.henny.hennyessentials.util;

import com.henny.hennyessentials.Constants;
import com.henny.hennyessentials.config.ConfigManager;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public class ModerationUtils {
    public static boolean isBannedItem(Item item) {
        boolean isBannedItem = false;
        if (ConfigManager.bannedItemsConfig.bannedItems.stream().anyMatch(b -> {
            return b.id().equals(BuiltInRegistries.ITEM.getKey(item).toString());
        })) {
            isBannedItem = true;
        }
        return isBannedItem;
    }

    public static void handleBannedItem(ItemStack item, ServerPlayer owner) {
        String regName = BuiltInRegistries.ITEM.getKey(item.getItem()).toString();
        if (ConfigManager.CONFIG.moderationConfigs.bannedItemsConfigs.shouldRemoveBannedItemFromPlayer) {
            item.setCount(-item.getCount());
        }
        owner.getInventory().items.forEach(itemStack -> {
            if (BuiltInRegistries.ITEM.getKey(itemStack.getItem()).toString().equals(regName) && ConfigManager.CONFIG.moderationConfigs.bannedItemsConfigs.shouldRemoveBannedItemFromPlayer) {
                itemStack.shrink(itemStack.getCount());
            }
        });
        owner.sendSystemMessage(TextUtils.formatMessage(ConfigManager.CONFIG.moderationConfigs.bannedItemsConfigs.bannedItemMessageToPlayer.replace("%item%", regName).replace("%reason%", ConfigManager.bannedItemsConfig.bannedItems.stream().filter(bannedItem -> {
            return bannedItem.id().equals(regName);
        }).findFirst().get().reason())));
        if (ConfigManager.CONFIG.moderationConfigs.auditConfigs.shouldWriteBannedItemPickupToAuditLog) {
            String auditLogEntry = owner.getScoreboardName() + " was caught with item: " + regName + ". Player UUID is: " + String.valueOf(owner.getUUID());
            writeToAuditLog("BANNED ITEM", auditLogEntry);
        }
    }

    public static void writeToAuditLog(String type, String text) {
        String timestamp = new SimpleDateFormat(ConfigManager.CONFIG.moderationConfigs.auditConfigs.auditLogTimestampFormat).format(new Date());
        String line = "[" + timestamp + "] [" + type + "] " + text;
        File logDir = new File(ConfigManager.configDir, "logs");
        if (!logDir.exists()) {
            logDir.mkdirs();
        }
        File logFile = new File(logDir, "AuditLog.txt");
        try {
            if (!logFile.exists()) {
                logFile.createNewFile();
            }
        } catch (IOException e) {
            Constants.LOG.error("Cannot create audit log: {}", e.getLocalizedMessage());
        }
        try {
            BufferedWriter w = new BufferedWriter(new FileWriter(logFile, StandardCharsets.UTF_8, true));
            try {
                w.write(line);
                w.newLine();
                w.close();
            } finally {
            }
        } catch (Exception e2) {
            Constants.LOG.error("Error writing to audit log: {}", e2.getLocalizedMessage());
        }
    }
}
