package com.henny.hennyessentials.command;

import com.henny.hennyessentials.CommonClass;
import com.henny.hennyessentials.config.ConfigManager;
import com.henny.hennyessentials.data.PlayerData;
import com.henny.hennyessentials.data.objects.Condition;
import com.henny.hennyessentials.permission.Permissions;
import com.henny.hennyessentials.util.TextUtils;
import com.mojang.brigadier.ParseResults;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.server.level.ServerPlayer;

public class ConditionCommands {
    public static List<LiteralArgumentBuilder<CommandSourceStack>> buildConditionCommands() {
        ArrayList<LiteralArgumentBuilder<CommandSourceStack>> returnList = new ArrayList<>();
        LiteralArgumentBuilder<CommandSourceStack> conditionBase = Commands.literal("condition");
        conditionBase.requires(src -> {
            return ModCommands.getRequirements(src, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.CONDITION_PERMISSION));
        });
        LiteralArgumentBuilder<CommandSourceStack> unredeemConditionCommand = Commands.literal("unredeem");
        unredeemConditionCommand.then(Commands.argument("playername", EntityArgument.player()).then(Commands.argument("conditionID", StringArgumentType.string()).suggests(ConditionCommands::suggestConditionIDs).executes(ConditionCommands::executeUnredeemCondition)));
        unredeemConditionCommand.requires(src2 -> {
            return ModCommands.getRequirements(src2, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.CONDITION_UNREDEEM_PERMISSION));
        });
        LiteralArgumentBuilder<CommandSourceStack> manualRedeemConditionCommand = Commands.literal("manualredeem");
        manualRedeemConditionCommand.requires(src3 -> {
            return ModCommands.getRequirements(src3, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.CONDITION_MANUALREDEEM_PERMISSION));
        });
        manualRedeemConditionCommand.then(Commands.argument("playername", EntityArgument.player()).then(Commands.argument("conditionID", StringArgumentType.string()).suggests(ConditionCommands::suggestConditionIDs).executes(ConditionCommands::executeManualRedeemCondition)));
        LiteralArgumentBuilder<CommandSourceStack> reloadConditionsConfigCommand = Commands.literal("reloadconfig");
        reloadConditionsConfigCommand.requires(src4 -> {
            return ModCommands.getRequirements(src4, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.CONDITION_RELOADCONFIG_PERMISSION));
        });
        reloadConditionsConfigCommand.executes(ctx -> {
            ConfigManager.reloadConditionsConfig();
            ((CommandSourceStack) ctx.getSource()).sendSystemMessage(TextUtils.formatMessage("Conditions reloaded."));
            return 1;
        });
        conditionBase.then(unredeemConditionCommand);
        conditionBase.then(manualRedeemConditionCommand);
        conditionBase.then(reloadConditionsConfigCommand);
        returnList.add(conditionBase);
        return returnList;
    }

    private static int executeUnredeemCondition(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        ServerPlayer p = EntityArgument.getPlayer(context, "playername");
        String conditionID = StringArgumentType.getString(context, "conditionID");
        PlayerData.getUserData().updatePlayerInfo(p.getUUID(), conditionID + "-condition", "false");
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatAndHighlight("Player [" + p.getScoreboardName() + "] has had their redeem status for condition [" + conditionID + "] refreshed."));
        return 1;
    }

    private static int executeManualRedeemCondition(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        ServerPlayer p = EntityArgument.getPlayer(context, "playername");
        String conditionID = StringArgumentType.getString(context, "conditionID");
        boolean found = false;
        for (Condition condition : ConfigManager.conditions) {
            if (condition.conditionID.equals(conditionID)) {
                found = true;
                for (String cmd : condition.commands) {
                    String cmdreplace = cmd.replace("%p", p.getScoreboardName());
                    ParseResults<CommandSourceStack> parseRes = CommonClass.minecraftServer.getCommands().getDispatcher().parse(cmdreplace, CommonClass.minecraftServer.createCommandSourceStack());
                    CommonClass.minecraftServer.getCommands().getDispatcher().execute(parseRes);
                }
                PlayerData.getUserData().updatePlayerInfo(p.getUUID(), conditionID + "-condition", "true");
            }
        }
        if (found) {
            ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatAndHighlight("You have manually redeemed condition [" + conditionID + "] for player [" + p.getScoreboardName() + "]."));
            return 1;
        }
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatAndHighlight("Could not find condition with ID [" + conditionID + "]. Please try again."));
        return 1;
    }

    private static CompletableFuture<Suggestions> suggestConditionIDs(CommandContext<CommandSourceStack> context, SuggestionsBuilder builder) {
        for (Condition c : ConfigManager.conditions) {
            builder.suggest(c.conditionID);
        }
        return builder.buildFuture();
    }
}
