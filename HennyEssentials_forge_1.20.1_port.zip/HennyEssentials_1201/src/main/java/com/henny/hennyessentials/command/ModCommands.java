package com.henny.hennyessentials.command;

import com.henny.hennyessentials.CommonClass;
import com.henny.hennyessentials.config.ConfigManager;
import com.henny.hennyessentials.config.objects.MainConfig;
import com.henny.hennyessentials.permission.Permissions;
import com.henny.hennyessentials.util.Pagination;
import com.henny.hennyessentials.util.TextUtils;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.tree.ArgumentCommandNode;
import com.mojang.brigadier.tree.CommandNode;
import com.mojang.brigadier.tree.LiteralCommandNode;
import com.mojang.brigadier.tree.RootCommandNode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.UuidArgument;

public class ModCommands {
    public static String BASE_COMMAND_ALIAS = "he";

    public static void register(CommandDispatcher<CommandSourceStack> cmdDispatcher) {
        LiteralArgumentBuilder<CommandSourceStack> baseCommand = Commands.literal(BASE_COMMAND_ALIAS);
        LiteralArgumentBuilder<CommandSourceStack> callback = Commands.literal("pcallback").then(Commands.argument("uuid", UuidArgument.uuid()).executes(ctx -> {
            UUID uuid = UuidArgument.getUuid(ctx, "uuid");
            if (Pagination.callbackRunnables.containsKey(uuid)) {
                Pagination.callbackRunnables.get(uuid).run();
                return 1;
            }
            return 1;
        }));
        baseCommand.then(callback);
        ArrayList<LiteralArgumentBuilder<CommandSourceStack>> childCommands = new ArrayList<>();
        MainConfig.CommandConfigs commandConfigs = ConfigManager.CONFIG.commandConfigs;
        if (commandConfigs.warpConfigs.warpCommandEnabled) {
            childCommands.addAll(WarpCommands.buildWarpCommands());
        }
        childCommands.addAll(CommandTokenCommands.buildCommandTokenCommands());
        if (commandConfigs.kitConfigs.kitsEnabled) {
            childCommands.addAll(KitCommands.buildKitCommands());
        }
        childCommands.addAll(ModerationCommands.buildModerationCommands());
        childCommands.addAll(PlayerCommands.buildPlayerCommands());
        if (commandConfigs.teleportConfigs.tpaCommandsEnabled) {
            childCommands.addAll(TeleportCommands.buildTeleportCommands());
        }
        if (ConfigManager.CONFIG.permissionConfigs.permissionsEnabled) {
            childCommands.addAll(PermCommands.buildUserPermCommands());
        }
        childCommands.addAll(ConditionCommands.buildConditionCommands());
        childCommands.addAll(PageCommands.buildPageCommands());
        for (LiteralArgumentBuilder<CommandSourceStack> child : childCommands) {
            baseCommand.then(child);
        }
        LiteralArgumentBuilder<CommandSourceStack> reloadConfigCmd = Commands.literal("reloadConfig").executes(ctx2 -> {
            ConfigManager.reloadHEConfig(true);
            ((CommandSourceStack) ctx2.getSource()).sendSystemMessage(TextUtils.formatMessage("HE Config reloaded"));
            return 1;
        }).requires(src -> {
            return getRequirements(src, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.RELOAD_CONFIG_PERMISSION));
        }).then(Commands.argument("shouldRestartTasks?", BoolArgumentType.bool()).executes(context -> {
            ConfigManager.reloadHEConfig(BoolArgumentType.getBool(context, "shouldRestartTasks?"));
            ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("HE Config reloaded"));
            ((CommandSourceStack) context.getSource()).getServer().getProfileCache().get(((CommandSourceStack) context.getSource()).getPlayer().getUUID()).get();
            return 1;
        }).requires(src2 -> {
            return getRequirements(src2, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.RELOAD_CONFIG_PERMISSION));
        }));
        LiteralArgumentBuilder<CommandSourceStack> reloadAnnouncementsConfig = Commands.literal("reloadAnnouncements");
        reloadAnnouncementsConfig.executes(ctx3 -> {
            ConfigManager.reloadAnnouncements();
            ((CommandSourceStack) ctx3.getSource()).sendSystemMessage(TextUtils.formatMessage("Announcements reloaded."));
            return 1;
        }).requires(src3 -> {
            return getRequirements(src3, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.RELOAD_ANNOUNCEMENTS_PERMISSION));
        });
        baseCommand.then(reloadConfigCmd);
        baseCommand.then(reloadAnnouncementsConfig);
        cmdDispatcher.register(baseCommand);
        registerAliases(cmdDispatcher);
    }

    public static boolean getRequirements(CommandSourceStack commandSourceStack, String permission) {
        if (!ConfigManager.CONFIG.permissionConfigs.permissionsEnabled) {
            return commandSourceStack.hasPermission(2);
        }
        if (ConfigManager.CONFIG.permissionConfigs.luckPermsOverridePermissions && commandSourceStack.isPlayer()) {
            return Permissions.permissionCheck(commandSourceStack.getPlayer().getUUID(), permission, CommonClass.minecraftServer);
        }
        return true;
    }

    public static boolean getRequirements(CommandSourceStack commandSourceStack, List<String> permission) {
        if (!ConfigManager.CONFIG.permissionConfigs.permissionsEnabled) {
            return commandSourceStack.hasPermission(2);
        }
        if (ConfigManager.CONFIG.permissionConfigs.luckPermsOverridePermissions && commandSourceStack.isPlayer()) {
            return Permissions.permissionCheckList(commandSourceStack.getPlayer().getUUID(), permission, CommonClass.minecraftServer);
        }
        return true;
    }

    public static boolean getPlayerRequirements(CommandSourceStack commandSourceStack, String permission) {
        if (!ConfigManager.CONFIG.permissionConfigs.permissionsEnabled) {
            return commandSourceStack.hasPermission(0);
        }
        if (ConfigManager.CONFIG.permissionConfigs.luckPermsOverridePermissions && commandSourceStack.isPlayer()) {
            return Permissions.permissionCheck(commandSourceStack.getPlayer().getUUID(), permission, CommonClass.minecraftServer);
        }
        return true;
    }

    public static boolean getPlayerRequirements(CommandSourceStack commandSourceStack, List<String> permission) {
        if (!ConfigManager.CONFIG.permissionConfigs.permissionsEnabled) {
            return commandSourceStack.hasPermission(0);
        }
        if (ConfigManager.CONFIG.permissionConfigs.luckPermsOverridePermissions && commandSourceStack.isPlayer()) {
            return Permissions.permissionCheckList(commandSourceStack.getPlayer().getUUID(), permission, CommonClass.minecraftServer);
        }
        return true;
    }

    public static void registerAliases(CommandDispatcher<CommandSourceStack> dispatcher) {
        for (Map.Entry<String, List<String>> alias : ConfigManager.CONFIG.aliasConfigs.aliasList.entrySet()) {
            String oldCmd = alias.getKey();
            List<String> aliases = alias.getValue();
            String[] parts = oldCmd.split(" ");
            CommandNode<CommandSourceStack> originalNode = dispatcher.getRoot().getChild(parts[0]);
            if (originalNode != null) {
                for (int i = 1; i < parts.length; i++) {
                    originalNode = originalNode.getChild(parts[i]);
                    if (originalNode == null) {
                        break;
                    }
                }
                if (originalNode != null) {
                    for (String cmdAlias : aliases) {
                        removeExistingCommand(dispatcher, cmdAlias);
                        dispatcher.register(createAliasTree(originalNode, cmdAlias));
                    }
                }
            }
        }
    }

    private static void removeExistingCommand(CommandDispatcher<CommandSourceStack> dispatcher, String commandName) {
        try {
            RootCommandNode<CommandSourceStack> root = dispatcher.getRoot();
            CommandNode<CommandSourceStack> existingCommand = root.getChild(commandName);
            if (existingCommand != null) {
                root.getChildren().remove(existingCommand);
            }
        } catch (Exception e) {
        }
    }

    private static LiteralArgumentBuilder<CommandSourceStack> createAliasTree(CommandNode<CommandSourceStack> original, String alias) {
        LiteralArgumentBuilder<CommandSourceStack> builder = Commands.literal(alias);
        builder.requires(original.getRequirement());
        if (original.getCommand() != null) {
            builder.executes(original.getCommand());
        }
        for (CommandNode<CommandSourceStack> child : original.getChildren()) {
            builder.then(cloneNode(child));
        }
        return builder;
    }

    private static ArgumentBuilder<CommandSourceStack, ?> cloneNode(CommandNode<CommandSourceStack> node) {
        LiteralArgumentBuilder literalArgumentBuilderArgument;
        if (node instanceof LiteralCommandNode) {
            LiteralCommandNode<CommandSourceStack> literal = (LiteralCommandNode) node;
            literalArgumentBuilderArgument = Commands.literal(literal.getLiteral());
        } else if (node instanceof ArgumentCommandNode) {
            ArgumentCommandNode<?, ?> argument = (ArgumentCommandNode) node;
            literalArgumentBuilderArgument = Commands.argument(argument.getName(), argument.getType());
        } else {
            throw new IllegalStateException("Unsupported node type: " + String.valueOf(node.getClass()));
        }
        literalArgumentBuilderArgument.requires(node.getRequirement());
        if (node.getCommand() != null) {
            literalArgumentBuilderArgument.executes(node.getCommand());
        }
        for (CommandNode<CommandSourceStack> child : node.getChildren()) {
            literalArgumentBuilderArgument.then(cloneNode(child));
        }
        if (node.getRedirect() != null) {
            literalArgumentBuilderArgument.redirect(node.getRedirect());
        }
        return literalArgumentBuilderArgument;
    }
}
