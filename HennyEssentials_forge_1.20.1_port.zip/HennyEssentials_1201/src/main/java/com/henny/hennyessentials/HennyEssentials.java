package com.henny.hennyessentials;

import com.henny.hennyessentials.compat.LuckPermsIntegration;
import com.henny.hennyessentials.config.ConfigManager;
import com.henny.hennyessentials.permission.Permissions;
import com.henny.hennyessentials.util.ModerationUtils;
import com.henny.hennyessentials.util.TextUtils;
import com.mojang.brigadier.context.ParsedCommandNode;
import com.mojang.brigadier.tree.ArgumentCommandNode;
import com.mojang.brigadier.tree.LiteralCommandNode;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.CommandEvent;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.loading.FMLPaths;

@Mod(Constants.MOD_ID)
public class HennyEssentials {
    public HennyEssentials() {
        Constants.LOG.info("Hello Forge world!");
        CommonClass.init(FMLPaths.CONFIGDIR.get().toString() + "/HennyEssentials/");
        MinecraftForge.EVENT_BUS.register(this);
        LuckPermsIntegration.isLuckPermsLoaded = ModList.get().isLoaded("luckperms");
    }

    @SubscribeEvent
    public void playerDeathEvent(LivingDeathEvent e) {
        ServerPlayer entity = e.getEntity();
        if (entity instanceof ServerPlayer) {
            ServerPlayer p = entity;
            CommonClass.playerDeathEvent(p, GlobalPos.of(p.serverLevel().dimension(), p.getOnPos()));
        }
    }

    @SubscribeEvent
    public void playerRespawnEvent(PlayerEvent.PlayerRespawnEvent e) {
        ServerPlayer entity = e.getEntity();
        if (entity instanceof ServerPlayer) {
            ServerPlayer p = entity;
            if (p.getLastDeathLocation().isPresent()) {
                CommonClass.playerDeathEvent(p, (GlobalPos) p.getLastDeathLocation().get());
            }
        }
    }

    @SubscribeEvent
    public void playerLeaveEvent(PlayerEvent.PlayerLoggedOutEvent e) {
        ServerPlayer entity = e.getEntity();
        if (entity instanceof ServerPlayer) {
            ServerPlayer p = entity;
            CommonClass.playerLeaveEvent(p);
        }
    }

    @SubscribeEvent
    public void serverStart(ServerStartingEvent e) {
        CommonClass.minecraftServer = e.getServer();
    }

    @SubscribeEvent
    public void onItemCrafted(PlayerEvent.ItemCraftedEvent e) {
        ServerPlayer entity = e.getEntity();
        if (entity instanceof ServerPlayer) {
            ServerPlayer p = entity;
            if (ModerationUtils.isBannedItem(e.getCrafting().getItem())) {
                if (ConfigManager.CONFIG.permissionConfigs.permissionsEnabled) {
                    if (!Permissions.permissionCheck(p.getUUID(), "he.banneditem.bypass." + BuiltInRegistries.ITEM.getKey(e.getCrafting().getItem()).toString(), p.getServer())) {
                        ModerationUtils.handleBannedItem(e.getCrafting(), p);
                        return;
                    }
                    return;
                }
                ModerationUtils.handleBannedItem(e.getCrafting(), p);
            }
        }
    }

    @SubscribeEvent
    public void onItemPickup(PlayerEvent.ItemPickupEvent e) {
        ServerPlayer entity = e.getEntity();
        if (entity instanceof ServerPlayer) {
            ServerPlayer p = entity;
            if (ModerationUtils.isBannedItem(e.getOriginalEntity().getItem().getItem())) {
                if (ConfigManager.CONFIG.permissionConfigs.permissionsEnabled) {
                    if (!Permissions.permissionCheck(p.getUUID(), "he.banneditem.bypass." + BuiltInRegistries.ITEM.getKey(e.getOriginalEntity().getItem().getItem()).toString(), p.getServer())) {
                        if (ConfigManager.CONFIG.moderationConfigs.bannedItemsConfigs.shouldRemoveBannedItemFromPlayer) {
                            e.setCanceled(true);
                        }
                        ModerationUtils.handleBannedItem(e.getOriginalEntity().getItem(), p);
                        return;
                    }
                    return;
                }
                if (ConfigManager.CONFIG.moderationConfigs.bannedItemsConfigs.shouldRemoveBannedItemFromPlayer) {
                    e.setCanceled(true);
                }
                ModerationUtils.handleBannedItem(e.getOriginalEntity().getItem(), p);
            }
        }
    }

    @SubscribeEvent
    public void serverTickPost(TickEvent.ServerTickEvent event) {
        // In 1.20.1, TickEvent.ServerTickEvent does not have getServer()
        // We use the server instance stored during ServerStartingEvent instead
        if (CommonClass.minecraftServer != null) {
            CommonClass.tickEvent(CommonClass.minecraftServer);
        }
    }

    @SubscribeEvent
    public void serverStarted(ServerStartedEvent e) {
        CommonClass.serverStartedEvent();
    }

    @SubscribeEvent
    public void playerJoin(EntityJoinLevelEvent e) {
        Entity ent = e.getEntity();
        if ((ent instanceof ServerPlayer) && e.getLevel().getServer().getPlayerList().getPlayer(ent.getUUID()) != null) {
            CommonClass.playerJoinEvent(e.getLevel().getServer().getPlayerList().getPlayer(e.getEntity().getUUID()));
        }
    }

    @SubscribeEvent
    public void commandRegister(RegisterCommandsEvent e) {
        CommonClass.commandRegistrationEvent(e.getDispatcher());
    }

    @SubscribeEvent
    public void commandPerform(CommandEvent e) {
        if (!ConfigManager.CONFIG.permissionConfigs.permissionsEnabled || ConfigManager.CONFIG.permissionConfigs.luckPermsOverridePermissions) {
            return;
        }
        CommandSourceStack source = (CommandSourceStack) e.getParseResults().getContext().getSource();
        if (!source.isPlayer()) {
            return;
        }
        UUID uuid = source.getPlayer().getUUID();
        MinecraftServer server = source.getServer();
        List<ParsedCommandNode<CommandSourceStack>> cmdNodes = e.getParseResults().getContext().getNodes();
        if (cmdNodes.isEmpty()) {
            return;
        }
        StringBuilder sb = new StringBuilder("command");
        for (ParsedCommandNode<CommandSourceStack> cmdNode : cmdNodes) {
            if ((cmdNode.getNode() instanceof LiteralCommandNode) || (ConfigManager.CONFIG.permissionConfigs.shouldIncludeArgumentNodesInPermissions && (cmdNode.getNode() instanceof ArgumentCommandNode))) {
                sb.append(".").append(cmdNode.getNode().getName());
            }
        }
        String basePermission = sb.toString().toLowerCase();
        String permission = basePermission;
        String rawInput = e.getParseResults().getReader().getString();
        String commandLabel = rawInput.split(" ")[0].substring(1);
        Map<String, List<String>> aliasList = ConfigManager.CONFIG.aliasConfigs.aliasList;
        Iterator<Map.Entry<String, List<String>>> it = aliasList.entrySet().iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            Map.Entry<String, List<String>> entry = it.next();
            if (entry.getValue().contains(commandLabel)) {
                permission = "command." + entry.getKey().replace(" ", ".").toLowerCase();
                break;
            }
        }
        if (source.getPlayer().getTags().contains("hessentials.verbose")) {
            source.sendSystemMessage(TextUtils.formatMessage("Permission check: " + permission));
        }
        if (Permissions.permissionCheck(uuid, permission, server)) {
            return;
        }
        for (String group : Permissions.getDefinedGroups()) {
            if (Permissions.permissionCheck(uuid, group, server) && Permissions.hasGroupPermission(group, permission)) {
                return;
            }
        }
        source.sendSystemMessage(TextUtils.formatMessage("You do not have the required permission to execute this command."));
        e.setCanceled(true);
    }

    @SubscribeEvent
    public void interactItemRightClick(PlayerInteractEvent.RightClickItem e) {
        if (e.getEntity() instanceof ServerPlayer) {
            CommonClass.interactItemRightClickEvent(e.getEntity(), e.getHand());
        }
    }

    @SubscribeEvent
    public void playerInteractBlockRightClickEvent(PlayerInteractEvent.RightClickBlock e) {
        if (e.getEntity() instanceof ServerPlayer) {
            CommonClass.interactBlockRightClickEvent(e.getEntity(), e.getPos());
        }
    }

    @SubscribeEvent
    public void playerChatEvent(ServerChatEvent e) {
        e.setCanceled(!CommonClass.serverChatEventResult(e.getPlayer(), e.getMessage()));
    }

    @SubscribeEvent
    public void playerChangeLevelEvent(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer) {
            CommonClass.changeLevelEventResult(e.getTo().location().toString(), e.getEntity());
        }
    }

    @SubscribeEvent
    public void onMobTargetChange(LivingChangeTargetEvent event) {
        if (event.getNewTarget() instanceof ServerPlayer) {
            event.setCanceled(CommonClass.entityChangeTargetEventResult(event.getNewTarget()));
        }
    }
}
