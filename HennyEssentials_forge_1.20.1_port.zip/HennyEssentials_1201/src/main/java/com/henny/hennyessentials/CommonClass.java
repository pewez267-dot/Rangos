package com.henny.hennyessentials;

import com.henny.hennyessentials.command.ModCommands;
import com.henny.hennyessentials.compat.LuckPermsIntegration;
import com.henny.hennyessentials.config.ConfigManager;
import com.henny.hennyessentials.data.PermissionUserData;
import com.henny.hennyessentials.data.PlayerData;
import com.henny.hennyessentials.data.WarpData;
import com.henny.hennyessentials.data.objects.Ban;
import com.henny.hennyessentials.data.objects.CommandToken;
import com.henny.hennyessentials.data.objects.Mute;
import com.henny.hennyessentials.permission.Permissions;
import com.henny.hennyessentials.platform.Services;
import com.henny.hennyessentials.task.TaskManager;
import com.henny.hennyessentials.util.AFKHandler;
import com.henny.hennyessentials.util.BackHandler;
import com.henny.hennyessentials.util.ModerationUtils;
import com.henny.hennyessentials.util.TextUtils;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.ParseResults;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoRemovePacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.item.ItemStack;

public class CommonClass {
    public static MinecraftServer minecraftServer;
    static final int[] tickCounter = {0};
    public static Map<UUID, BlockPos> teleportMoveLock = new HashMap();
    public static Map<UUID, Boolean> playersInVanish = new HashMap();
    public static Map<UUID, Boolean> playersInFly = new HashMap();

    public static void init(String configDir) {
        ConfigManager.load(configDir);
        ConfigManager.loadCommandTokensConfig(configDir);
        ConfigManager.loadAnnouncements(configDir);
        ConfigManager.loadBannedItems();
        ConfigManager.reloadConditionsConfig();
        ConfigManager.reloadPagesConfig();
        if (Services.PLATFORM.isModLoaded(Constants.MOD_ID)) {
            Constants.LOG.info("Hello to hennyessentials");
        }
    }

    public static void playerDeathEvent(ServerPlayer player, GlobalPos deathPos) {
        BackHandler.setLastDeathLocation(player, deathPos);
    }

    public static void playerLeaveEvent(ServerPlayer player) {
        if (playersInVanish.containsKey(player.getUUID())) {
            player.setInvisible(false);
            player.removeEffect(MobEffects.INVISIBILITY);
            playersInVanish.remove(player.getUUID());
            if (player.getTags().contains("he.vanish")) {
                player.removeTag("he.vanish");
            }
        }
        if (player.getTags().contains("he.vanish")) {
            player.removeTag("he.vanish");
            player.setInvisible(false);
            player.removeEffect(MobEffects.INVISIBILITY);
        }
        AFKHandler.AFKTracker.remove(player.getUUID());
    }

    public static void playerJoinEvent(ServerPlayer serverPlayer) {
        if (serverPlayer.getTags().contains("he.fly")) {
            Abilities abs = serverPlayer.getAbilities();
            abs.flying = true;
            abs.mayfly = true;
            serverPlayer.onUpdateAbilities();
        }
        if (ConfigManager.CONFIG.commandConfigs.vanishConfigs.EXPERIMENTAL_shouldHideVanishedPlayersFromTabList) {
            ArrayList<UUID> vanishedPlayers = new ArrayList<>();
            for (Map.Entry<UUID, Boolean> entry : playersInVanish.entrySet()) {
                if (entry.getValue().booleanValue() && entry.getKey() != serverPlayer.getUUID()) {
                    vanishedPlayers.add(entry.getKey());
                }
            }
            ClientboundPlayerInfoRemovePacket packet = new ClientboundPlayerInfoRemovePacket(vanishedPlayers);
            serverPlayer.connection.send(packet);
        }
        PlayerData data = PlayerData.getUserData(serverPlayer.server);
        PermissionUserData.getPermissionUserData(serverPlayer.server).addUserPermission(serverPlayer.getUUID(), "group.default");
        Map<UUID, Ban> bannedPlayers = data.bannedPlayers;
        if (bannedPlayers.containsKey(serverPlayer.getUUID())) {
            long expiry = bannedPlayers.get(serverPlayer.getUUID()).banExpiry;
            String reason = bannedPlayers.get(serverPlayer.getUUID()).banReason;
            String expiryStr = expiry == 0 ? "Never" : TextUtils.readableDuration(expiry - System.currentTimeMillis());
            if (expiry == 0 || expiry > System.currentTimeMillis()) {
                serverPlayer.connection.disconnect(Component.literal(ConfigManager.CONFIG.moderationConfigs.banConfigs.bannedMessage.replace("%reason%", reason) + "\n" + ConfigManager.CONFIG.moderationConfigs.banConfigs.expiryMessage.replace("%expiry%", expiryStr)));
            }
        }
    }

    public static void serverStartedEvent() {
        TaskManager.startHETasks();
        TaskManager.startAnnouncementTasks();
    }

    public static void commandRegistrationEvent(CommandDispatcher<CommandSourceStack> cmdDispatcher) {
        ModCommands.register(cmdDispatcher);
    }

    public static void interactItemRightClickEvent(ServerPlayer player, InteractionHand interactionHand) {
        if (ConfigManager.CONFIG.moderationConfigs.afkConfigs.rightClickItemCountsAsMovement) {
            AFKHandler.updatePlayer(player);
        }
        ItemStack itemStack = player.getItemInHand(interactionHand);
        // 1.20.1: use legacy NBT tag API instead of DataComponents
        CompoundTag tag = itemStack.getTag();
        boolean hasData = tag != null && tag.contains("commandtoken");
        if (hasData && !tag.getString("commandtoken").isEmpty()) {
            CommandToken token = ConfigManager.TOKENS.get(tag.getString("commandtoken"));
            if (token.permission != null && !token.permission.isBlank() && ConfigManager.CONFIG.permissionConfigs.permissionsEnabled && !Permissions.permissionCheck(player.getUUID(), token.permission, minecraftServer)) {
                player.sendSystemMessage(Component.literal(ConfigManager.CONFIG.tokenConfigs.tokenNoPermissionMessage));
                return;
            }
            if (!tag.getString("locked").isEmpty() && !player.getUUID().toString().equals(tag.getString("locked"))) {
                player.sendSystemMessage(TextUtils.formatMessage(ConfigManager.CONFIG.tokenConfigs.lockedTokenNoPermissionMessage));
                return;
            }
            if (token.reusableUsageLimit > 0 && token.isReusable()) {
                CompoundTag tokenData = itemStack.getOrCreateTag();
                int usages = 0;
                if (tokenData.contains("usages")) {
                    usages = tokenData.getInt("usages");
                }
                if (usages >= token.reusableUsageLimit) {
                    player.sendSystemMessage(TextUtils.formatMessage(ConfigManager.CONFIG.tokenConfigs.maxUsagesText));
                    PlayerData.getUserData().updatePlayerInfo(player.getUUID(), "token-usage-" + token.alias, String.valueOf(token.reusableUsageLimit));
                    itemStack.shrink(1);
                    return;
                }
                tokenData.putInt("usages", usages + 1);
                itemStack.setTag(tokenData);
            }
            token.commands.stream().map(cmd -> {
                return cmd.replace("%p", player.getName().getString());
            }).forEach(cmd2 -> {
                MinecraftServer server = player.getServer();
                Commands commands = server.getCommands();
                ParseResults<CommandSourceStack> parseRes = commands.getDispatcher().parse(cmd2, server.createCommandSourceStack().withPermission(4));
                try {
                    commands.getDispatcher().execute(parseRes);
                } catch (CommandSyntaxException e) {
                    throw new RuntimeException((Throwable) e);
                }
            });
            if (ConfigManager.CONFIG.moderationConfigs.auditConfigs.shouldWriteCommandTokenUsagesToAuditLog && token.shouldWriteToAuditLog) {
                ModerationUtils.writeToAuditLog("TOKEN", player.getScoreboardName() + " redeemed token: " + token.alias + ". Player UUID is: " + String.valueOf(player.getUUID()));
            }
            if (!token.reusable) {
                itemStack.shrink(1);
            }
        }
    }

    public static boolean serverChatEventResult(ServerPlayer serverPlayer, Component msg) {
        if (serverPlayer != null && PlayerData.getUserData(minecraftServer).mutedPlayers.containsKey(serverPlayer.getUUID())) {
            Mute muteData = PlayerData.getUserData(minecraftServer).mutedPlayers.get(serverPlayer.getUUID());
            if (muteData.muteExpiry == 0 || muteData.muteExpiry > System.currentTimeMillis()) {
                String expiry = muteData.muteExpiry == 0 ? "Never" : TextUtils.readableDuration(muteData.muteExpiry - System.currentTimeMillis());
                serverPlayer.sendSystemMessage(Component.literal(ConfigManager.CONFIG.moderationConfigs.muteConfigs.mutedMessage.replace("%reason%", muteData.muteReason)));
                serverPlayer.sendSystemMessage(Component.literal(ConfigManager.CONFIG.moderationConfigs.muteConfigs.expiryMessage.replace("%expiry%", expiry)));
                return false;
            }
        }
        if (serverPlayer != null && ConfigManager.CONFIG.moderationConfigs.afkConfigs.chatMessageOrCommandCountsAsMovement) {
            AFKHandler.updatePlayer(serverPlayer);
        }
        if (ConfigManager.CONFIG.chatConfigs.chatFormattingEnabled) {
            String raw = msg.getString().replace(ConfigManager.CONFIG.chatConfigs.chatColorCode, "§");
            if (ConfigManager.CONFIG.chatConfigs.chatColorsEnabled && ConfigManager.CONFIG.permissionConfigs.permissionsEnabled && ConfigManager.CONFIG.chatConfigs.permissionCheckForChatColors) {
                raw = removeUnauthorizedColorCodes(raw, serverPlayer, minecraftServer);
            }
            MutableComponent messageComponent = Component.literal(raw);
            MutableComponent prefix = Component.literal("");
            MutableComponent suffix = Component.literal("");
            if (ConfigManager.CONFIG.permissionConfigs.luckPermsOverridePermissions) {
                prefix = Component.literal(LuckPermsIntegration.getPrefix(serverPlayer.getUUID()).replace("&", "§"));
                suffix = Component.literal(LuckPermsIntegration.getSuffix(serverPlayer.getUUID()).replace("&", "§"));
            } else if (ConfigManager.CONFIG.permissionConfigs.permissionsEnabled) {
                prefix = PermissionUserData.getChatPrefix(serverPlayer.getUUID(), serverPlayer.server);
                suffix = PermissionUserData.getChatSuffix(serverPlayer.getUUID(), serverPlayer.server);
            }
            String username = serverPlayer.getName().getString();
            String format = ConfigManager.CONFIG.chatConfigs.playerChatMessageFormat.replace(ConfigManager.CONFIG.chatConfigs.chatColorCode, "§");
            Pattern pattern = Pattern.compile("%(prefix|username|suffix|message)%");
            Matcher matcher = pattern.matcher(format);
            int lastEnd = 0;
            MutableComponent finalMsg = Component.empty();
            while (matcher.find()) {
                String before = format.substring(lastEnd, matcher.start());
                if (!before.isEmpty()) {
                    finalMsg.append(parseFormattedLiteral(before));
                }
                switch (matcher.group(1)) {
                    case "prefix":
                        finalMsg.append(prefix);
                        break;
                    case "username":
                        finalMsg.append(Component.literal(username));
                        break;
                    case "suffix":
                        finalMsg.append(suffix);
                        break;
                    case "message":
                        finalMsg.append(messageComponent);
                        break;
                }
                lastEnd = matcher.end();
            }
            if (lastEnd < format.length()) {
                finalMsg.append(parseFormattedLiteral(format.substring(lastEnd)));
            }
            serverPlayer.server.getPlayerList().broadcastSystemMessage(finalMsg, false);
            return false;
        }
        return true;
    }

    private static MutableComponent parseFormattedLiteral(String input) {
        return Component.literal(input);
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x006f  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private static java.lang.String removeUnauthorizedColorCodes(java.lang.String r4, net.minecraft.server.level.ServerPlayer r5, net.minecraft.server.MinecraftServer r6) {
        /*
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r1 = r0
            r1.<init>()
            r7 = r0
            r0 = 0
            r8 = r0
        Lb:
            r0 = r8
            r1 = r4
            int r1 = r1.length()
            if (r0 >= r1) goto L7c
            r0 = r4
            r1 = r8
            char r0 = r0.charAt(r1)
            r9 = r0
            r0 = r9
            r1 = 167(0xa7, float:2.34E-43)
            if (r0 != r1) goto L6f
            r0 = r8
            r1 = 1
            int r0 = r0 + r1
            r1 = r4
            int r1 = r1.length()
            if (r0 >= r1) goto L6f
            r0 = r4
            r1 = r8
            r2 = 1
            int r1 = r1 + r2
            char r0 = r0.charAt(r1)
            char r0 = java.lang.Character.toLowerCase(r0)
            r10 = r0
            java.util.Map<java.lang.Character, java.lang.String> r0 = com.henny.hennyessentials.permission.Permissions.COLOR_CODE_PERMISSIONS
            r1 = r10
            java.lang.Character r1 = java.lang.Character.valueOf(r1)
            java.lang.Object r0 = r0.get(r1)
            java.lang.String r0 = (java.lang.String) r0
            r11 = r0
            r0 = r11
            if (r0 == 0) goto L6f
            r0 = r11
            java.lang.String r0 = "he.chat.format." + r0
            r12 = r0
            r0 = r5
            java.util.UUID r0 = r0.getUUID()
            r1 = r12
            r2 = r6
            boolean r0 = com.henny.hennyessentials.permission.Permissions.permissionCheck(r0, r1, r2)
            if (r0 != 0) goto L6f
            int r8 = r8 + 1
            goto L76
        L6f:
            r0 = r7
            r1 = r9
            java.lang.StringBuilder r0 = r0.append(r1)
        L76:
            int r8 = r8 + 1
            goto Lb
        L7c:
            r0 = r7
            java.lang.String r0 = r0.toString()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.henny.hennyessentials.CommonClass.removeUnauthorizedColorCodes(java.lang.String, net.minecraft.server.level.ServerPlayer, net.minecraft.server.MinecraftServer):java.lang.String");
    }

    public static void interactBlockRightClickEvent(ServerPlayer player, BlockPos blockPos) {
        if (ConfigManager.CONFIG.moderationConfigs.afkConfigs.rightClickBlockCountsAsMovement) {
            AFKHandler.updatePlayer(player);
        }
    }

    public static void tickEvent(MinecraftServer server) {
        TaskManager.tick(server);
        AFKHandler.tick(server);
        int[] iArr = tickCounter;
        iArr[0] = iArr[0] + 1;
        if (tickCounter[0] >= 120) {
            WarpData.getWarpData(server).purgeExpired();
            PlayerData.getUserData(server).purgeExpiredBansMutes();
            for (Map.Entry<UUID, Boolean> entry : playersInVanish.entrySet()) {
                if (server.getPlayerList().getPlayer(entry.getKey()) != null) {
                    playersInVanish.put(entry.getKey(), Boolean.valueOf(server.getPlayerList().getPlayer(entry.getKey()).getTags().contains("he.vanish")));
                }
            }
            tickCounter[0] = 0;
        }
    }

    public static boolean entityChangeTargetEventResult(ServerPlayer newTarget) {
        return playersInVanish.getOrDefault(newTarget.getUUID(), false).booleanValue();
    }

    public static void changeLevelEventResult(String level, ServerPlayer player) {
        if (ConfigManager.CONFIG.permissionConfigs.permissionRequiredToEnterDimensions && !level.equals(ConfigManager.CONFIG.permissionConfigs.defaultDimensionNoPermsRequired) && !Permissions.permissionCheck(player.getUUID(), "dimension." + level, player.server)) {
            ServerLevel ow = player.server.overworld();
            BlockPos owspawn = player.server.overworld().getSharedSpawnPos();
            player.teleportTo(ow, owspawn.getX(), owspawn.getY() + 1, owspawn.getZ(), player.getYRot(), player.getXRot());
            player.sendSystemMessage(TextUtils.formatMessage(ConfigManager.CONFIG.commandConfigs.teleportConfigs.normalTeleportToDimNoPermission.replace("%dimension%", level)));
        }
    }
}
