package com.henny.hennyessentials.config.objects;

import com.google.gson.annotations.Expose;
import com.henny.hennyessentials.data.objects.Condition;
import java.util.ArrayList;
import java.util.List;

public class ConditionsConfig {

    @Expose
    public List<Condition> conditions = new ArrayList<Condition>() { // from class: com.henny.hennyessentials.config.objects.ConditionsConfig.1
        {
            add(new Condition("novice-rank", "playtime", Integer.valueOf("300"), List.of("say %p has played for 5 minutes and is now Novice rank!", "give %p minecraft:diamond")));
        }
    };
}
