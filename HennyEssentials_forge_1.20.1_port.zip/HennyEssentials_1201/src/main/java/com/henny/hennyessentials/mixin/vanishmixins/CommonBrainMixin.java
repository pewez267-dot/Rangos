package com.henny.hennyessentials.mixin.vanishmixins;

import com.henny.hennyessentials.CommonClass;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.Brain;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Brain.class})
public class CommonBrainMixin {
    @Inject(method = {"setMemory(Lnet/minecraft/world/entity/ai/memory/MemoryModuleType;Ljava/lang/Object;)V"}, at = {@At("HEAD")}, cancellable = true)
    private <U> void onSetMemory(MemoryModuleType<U> pMemoryType, U pMemory, CallbackInfo ci) {
        if ((pMemoryType == MemoryModuleType.ATTACK_TARGET || pMemoryType == MemoryModuleType.NEAREST_VISIBLE_PLAYER || pMemoryType == MemoryModuleType.NEAREST_HOSTILE || pMemoryType == MemoryModuleType.ANGRY_AT || pMemoryType == MemoryModuleType.NEAREST_VISIBLE_ATTACKABLE_PLAYER) && (pMemory instanceof ServerPlayer)) {
            ServerPlayer player = (ServerPlayer) pMemory;
            if (CommonClass.playersInVanish.getOrDefault(player.getUUID(), false).booleanValue()) {
                ci.cancel();
            }
        }
    }
}
