package com.henny.hennyessentials.data.objects;

import com.google.gson.annotations.Expose;
import com.henny.hennyessentials.config.ConfigManager;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public class CommandToken {

    @Expose
    public String name;

    @Expose
    public List<String> commands;

    @Expose
    public String alias;

    @Expose
    public String description;

    @Expose
    public boolean reusable;

    @Expose
    public boolean lockedToPlayer;

    @Expose
    public String permission;

    @Expose
    public boolean shouldWriteToAuditLog;

    @Expose
    public int reusableUsageLimit;

    public CommandToken(String name, List<String> commands, String alias, String description, boolean reusable) {
        this.reusable = false;
        this.lockedToPlayer = false;
        this.permission = "";
        this.shouldWriteToAuditLog = false;
        this.reusableUsageLimit = 0;
        this.name = name;
        this.commands = commands;
        this.alias = alias;
        this.description = description;
        this.reusable = reusable;
        this.permission = "";
    }

    public CommandToken(String name, List<String> commands, String alias, String description, String permission) {
        this.reusable = false;
        this.lockedToPlayer = false;
        this.permission = "";
        this.shouldWriteToAuditLog = false;
        this.reusableUsageLimit = 0;
        this.name = name;
        this.commands = commands;
        this.alias = alias;
        this.description = description;
        this.lockedToPlayer = false;
        this.reusable = false;
        this.permission = permission;
    }

    public CommandToken(String name, List<String> commands, String alias, String description) {
        this.reusable = false;
        this.lockedToPlayer = false;
        this.permission = "";
        this.shouldWriteToAuditLog = false;
        this.reusableUsageLimit = 0;
        this.name = name;
        this.commands = commands;
        this.alias = alias;
        this.description = description;
        this.lockedToPlayer = false;
        this.reusable = false;
        this.permission = "";
    }

    public static ItemStack createTokenItemStack(ItemStack itemStack, String tokenName, boolean lockedToPlayer, ServerPlayer receivingPlayer) {
        // 1.20.1: use legacy NBT tag API instead of DataComponents
        CompoundTag tokenData = itemStack.getOrCreateTag();
        CommandToken token = ConfigManager.TOKENS.get(tokenName);
        tokenData.putString("commandtoken", tokenName);
        if (lockedToPlayer) {
            tokenData.putString("locked", receivingPlayer.getUUID().toString());
        }
        itemStack.setTag(tokenData);

        String playerName = receivingPlayer != null ? receivingPlayer.getName().getString() : null;
        // 1.20.1: use setHoverName for display name (replaces DataComponents.ITEM_NAME)
        if (token.name != null && !token.name.isEmpty()) {
            String name = playerName != null ? token.name.replace("%p", playerName) : token.name;
            itemStack.setHoverName(Component.literal(name));
        }

        // 1.20.1: lore is stored as JSON strings in display.Lore NBT list
        List<Component> loreComponents = new ArrayList<>();
        if (token.description != null && !token.description.isEmpty()) {
            String desc = playerName != null ? token.description.replace("%p", playerName) : token.description;
            loreComponents.add(Component.literal(desc));
        }
        loreComponents.add(Component.literal(ConfigManager.CONFIG.tokenConfigs.usageLoreText));
        if (token.reusable) {
            loreComponents.add(Component.literal(ConfigManager.CONFIG.tokenConfigs.reusableText));
        }
        if (!loreComponents.isEmpty()) {
            CompoundTag display = itemStack.getOrCreateTagElement("display");
            ListTag loreTag = new ListTag();
            for (Component lore : loreComponents) {
                loreTag.add(StringTag.valueOf(Component.Serializer.toJson(lore)));
            }
            display.put("Lore", loreTag);
        }
        return itemStack;
    }

    public boolean isReusable() {
        return this.reusable;
    }

    public boolean isLockedToPlayer() {
        return this.lockedToPlayer;
    }
}
