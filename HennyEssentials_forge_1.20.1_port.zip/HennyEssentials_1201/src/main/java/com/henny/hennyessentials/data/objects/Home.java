package com.henny.hennyessentials.data.objects;

import net.minecraft.core.GlobalPos;

public class Home {
    public String name;
    public GlobalPos pos;
    public float rotation;

    public Home(String name, GlobalPos pos) {
        this.rotation = 0.0f;
        this.name = name;
        this.pos = pos;
        this.rotation = 0.0f;
    }
}
