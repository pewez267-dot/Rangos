package com.henny.hennyessentials.mixin;

import com.henny.hennyessentials.CommonClass;
import com.henny.hennyessentials.config.ConfigManager;
import com.henny.hennyessentials.permission.Permissions;
import com.henny.hennyessentials.task.Task;
import com.henny.hennyessentials.task.TaskManager;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.network.Connection;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundPlayerInfoRemovePacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.server.players.PlayerList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin({PlayerList.class})
public class PlayerJoinMixin {

    @Shadow
    private MinecraftServer server;

    @Shadow
    public void broadcastSystemMessage(Component message, boolean force) {
    }

    @WrapOperation(method = {"placeNewPlayer"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/server/players/PlayerList;broadcastSystemMessage(Lnet/minecraft/network/chat/Component;Z)V")})
    private void wrapPlaceNewPlayerOperation(PlayerList instance, Component pMessage, boolean pBypassHiddenChat, Operation<Void> original, Connection connection, ServerPlayer player, CommonListenerCookie cookie) {
        boolean isVanished = ConfigManager.CONFIG.permissionConfigs.permissionsEnabled && Permissions.permissionCheck(player.getUUID(), Permissions.VANISH_ON_LOGIN_PERMISSION, this.server);
        if (!isVanished) {
            original.call(instance, pMessage, Boolean.valueOf(pBypassHiddenChat));
            return;
        }
        original.call(instance, Component.empty(), true);
        CommonClass.minecraftServer.getCommands().performCommand(CommonClass.minecraftServer.getCommands().getDispatcher().parse("he vanish", player.createCommandSourceStack()), "he vanish");
        if (ConfigManager.CONFIG.commandConfigs.vanishConfigs.EXPERIMENTAL_shouldHideVanishedPlayersFromTabList) {
            AtomicInteger tempCounter = new AtomicInteger(0);
            Task task = Task.builder().name(String.valueOf(player.getUUID()) + "-vanish-remove-playerlist").interval(1, TimeUnit.SECONDS).execute(t -> {
                if (tempCounter.getAndIncrement() >= 2) {
                    ClientboundPlayerInfoRemovePacket packet = new ClientboundPlayerInfoRemovePacket(List.of(player.getUUID()));
                    for (ServerPlayer p : player.server.getPlayerList().getPlayers()) {
                        p.connection.send(packet);
                    }
                    t.completed = true;
                }
            }).build();
            TaskManager.addTask(task);
        }
    }
}
