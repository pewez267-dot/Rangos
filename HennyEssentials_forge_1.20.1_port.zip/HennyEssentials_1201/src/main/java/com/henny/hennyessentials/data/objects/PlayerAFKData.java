package com.henny.hennyessentials.data.objects;

public class PlayerAFKData {
    public long lastActiveTime;
    public boolean isAFK;
    public long afkStartTime = 0;
    public boolean justWentAFK = false;

    public PlayerAFKData(long lastActiveTime, boolean isAFK) {
        this.lastActiveTime = lastActiveTime;
        this.isAFK = isAFK;
    }
}
