package com.henny.hennyessentials.platform;

import com.henny.hennyessentials.Constants;
import com.henny.hennyessentials.platform.services.IPlatformHelper;
import java.util.ServiceLoader;

public class Services {
    public static final IPlatformHelper PLATFORM = (IPlatformHelper) load(IPlatformHelper.class);

    public static <T> T load(Class<T> cls) {
        T t = (T) ServiceLoader.load(cls).findFirst().orElseThrow(() -> {
            return new NullPointerException("Failed to load service for " + cls.getName());
        });
        Constants.LOG.debug("Loaded {} for service {}", t, cls);
        return t;
    }
}
