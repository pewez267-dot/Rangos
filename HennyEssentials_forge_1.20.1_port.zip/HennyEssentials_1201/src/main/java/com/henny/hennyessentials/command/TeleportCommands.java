package com.henny.hennyessentials.command;

import com.henny.hennyessentials.CommonClass;
import com.henny.hennyessentials.config.ConfigManager;
import com.henny.hennyessentials.data.HEData;
import com.henny.hennyessentials.data.PlayerData;
import com.henny.hennyessentials.data.objects.Home;
import com.henny.hennyessentials.data.objects.SpawnPosData;
import com.henny.hennyessentials.data.objects.Tpa;
import com.henny.hennyessentials.handler.TpaHandler;
import com.henny.hennyessentials.permission.Permissions;
import com.henny.hennyessentials.task.Task;
import com.henny.hennyessentials.task.TaskManager;
import com.henny.hennyessentials.util.BackHandler;
import com.henny.hennyessentials.util.Pagination;
import com.henny.hennyessentials.util.TextUtils;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.UuidArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

public class TeleportCommands {
    public static List<LiteralArgumentBuilder<CommandSourceStack>> buildTeleportCommands() {
        ArrayList<LiteralArgumentBuilder<CommandSourceStack>> returnList = new ArrayList<>();
        LiteralArgumentBuilder<CommandSourceStack> tpaCommand = Commands.literal("tpa");
        tpaCommand.then(Commands.argument("playerName", EntityArgument.player()).executes(TeleportCommands::executeTpa).requires(src -> {
            return ModCommands.getPlayerRequirements(src, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.TELEPORT_TPA_PERMISSION));
        }));
        returnList.add(tpaCommand);
        LiteralArgumentBuilder<CommandSourceStack> tpaHereCommand = Commands.literal("tpahere");
        tpaHereCommand.then(Commands.argument("playerName", EntityArgument.player()).executes(TeleportCommands::executeTpaHere).requires(src2 -> {
            return ModCommands.getPlayerRequirements(src2, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.TELEPORT_TPAHERE_PERMISSION));
        }));
        returnList.add(tpaHereCommand);
        LiteralArgumentBuilder<CommandSourceStack> backCommand = Commands.literal("back");
        backCommand.executes(TeleportCommands::executeBack);
        backCommand.requires(src3 -> {
            return ModCommands.getPlayerRequirements(src3, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.TELEPORT_BACK_PERMISSION));
        });
        returnList.add(backCommand);
        LiteralArgumentBuilder<CommandSourceStack> tpaAcceptCommand = Commands.literal("tpaaccept");
        tpaAcceptCommand.then(Commands.argument("requestUUID", UuidArgument.uuid()).executes(TeleportCommands::executeTpaAccept).requires(src4 -> {
            return ModCommands.getPlayerRequirements(src4, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.TELEPORT_TPAACCEPT_PERMISSION));
        }));
        LiteralArgumentBuilder<CommandSourceStack> tpaDenyCommand = Commands.literal("tpadeny");
        tpaDenyCommand.then(Commands.argument("requestUUID", UuidArgument.uuid()).executes(TeleportCommands::executeTpaDeny).requires(src5 -> {
            return ModCommands.getPlayerRequirements(src5, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.TELEPORT_TPADENY_PERMISSION));
        }));
        LiteralArgumentBuilder<CommandSourceStack> setHomeCommand = Commands.literal("sethome").executes(TeleportCommands::executeSetHome).requires(src6 -> {
            return ModCommands.getPlayerRequirements(src6, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.TELEPORT_SETHOME_PERMISSION));
        }).then(Commands.argument("homeName", StringArgumentType.word()).executes(TeleportCommands::executeSetHome).requires(src7 -> {
            return ModCommands.getPlayerRequirements(src7, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.TELEPORT_SETHOME_PERMISSION));
        }));
        LiteralArgumentBuilder<CommandSourceStack> delHomeCommand = Commands.literal("delhome").then(Commands.argument("homeName", StringArgumentType.word()).executes(TeleportCommands::executeDelHome).requires(src8 -> {
            return ModCommands.getPlayerRequirements(src8, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.TELEPORT_DELHOME_PERMISSION));
        }));
        delHomeCommand.requires(src9 -> {
            return ModCommands.getPlayerRequirements(src9, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.TELEPORT_DELHOME_PERMISSION));
        });
        LiteralArgumentBuilder<CommandSourceStack> homeCommand = Commands.literal("home").executes(TeleportCommands::executeGoHome).requires(src10 -> {
            return ModCommands.getPlayerRequirements(src10, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.TELEPORT_GOHOME_PERMISSION));
        }).then(Commands.argument("homeName", StringArgumentType.word()).executes(TeleportCommands::executeGoHome).requires(src11 -> {
            return ModCommands.getPlayerRequirements(src11, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.TELEPORT_GOHOME_PERMISSION));
        }));
        LiteralArgumentBuilder<CommandSourceStack> listHomes = Commands.literal("homes").executes(TeleportCommands::executeListHomes).requires(src12 -> {
            return ModCommands.getPlayerRequirements(src12, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.TELEPORT_LISTHOME_PERMISSION));
        });
        LiteralArgumentBuilder<CommandSourceStack> spawnCommand = Commands.literal("spawn");
        spawnCommand.executes(TeleportCommands::executeTeleportToSpawn);
        spawnCommand.requires(src13 -> {
            return ModCommands.getPlayerRequirements(src13, (List<String>) List.of(Permissions.USER_PERMISSIONS, Permissions.TELEPORT_GOSPAWN_PERMISSION));
        });
        LiteralArgumentBuilder<CommandSourceStack> setSpawnCommand = Commands.literal("setspawn");
        setSpawnCommand.executes(context -> {
            if (!((CommandSourceStack) context.getSource()).isPlayer()) {
                return 1;
            }
            ServerPlayer p = ((CommandSourceStack) context.getSource()).getPlayer();
            SpawnPosData spd = new SpawnPosData(GlobalPos.of(p.serverLevel().dimension(), p.getOnPos()), p.getYRot());
            HEData.getHEData().addSpawnPoint(spd);
            p.serverLevel().setDefaultSpawnPos(p.getOnPos(), p.getYRot());
            p.sendSystemMessage(TextUtils.formatAndHighlight("Set the spawn position for dimension: [" + String.valueOf(p.serverLevel().dimension().location()) + "] to: [" + p.getOnPos().toShortString() + "]"));
            return 1;
        }).requires(src14 -> {
            return ModCommands.getRequirements(src14, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.TELEPORT_SET_SPAWN_PERMISSION));
        });
        returnList.add(tpaAcceptCommand);
        returnList.add(tpaDenyCommand);
        if (ConfigManager.CONFIG.commandConfigs.teleportConfigs.spawnCommandEnabled) {
            returnList.add(spawnCommand);
        }
        if (ConfigManager.CONFIG.commandConfigs.teleportConfigs.setSpawnCommandEnabled) {
            returnList.add(setSpawnCommand);
        }
        if (ConfigManager.CONFIG.commandConfigs.teleportConfigs.homeCommandsEnabled) {
            returnList.add(setHomeCommand);
            returnList.add(delHomeCommand);
            returnList.add(homeCommand);
            returnList.add(listHomes);
        }
        return returnList;
    }

    private static int executeTeleportToSpawn(CommandContext<CommandSourceStack> context) {
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        ServerPlayer p = ((CommandSourceStack) context.getSource()).getPlayer();
        ServerLevel ow = p.serverLevel();
        if (ConfigManager.CONFIG.commandConfigs.teleportConfigs.spawnCommandAlwaysTeleportsToOverworld) {
            ow = p.getServer().overworld();
        }
        ow.getSharedSpawnPos();
        if (HEData.getHEData().SPAWN_DATA.containsKey(p.serverLevel().dimension().location().toString())) {
            SpawnPosData spd = HEData.getHEData().SPAWN_DATA.get(p.serverLevel().dimension().location().toString());
            teleportPlayer(p, spd.pos, ConfigManager.CONFIG.commandConfigs.teleportConfigs.spawnCommandWarmupSeconds, spd.rotation);
            return 1;
        }
        teleportPlayer(p, GlobalPos.of(ow.dimension(), ow.getSharedSpawnPos()), ConfigManager.CONFIG.commandConfigs.teleportConfigs.spawnCommandWarmupSeconds, p.getYRot());
        return 1;
    }

    private static int executeSetHome(CommandContext<CommandSourceStack> context) {
        int maxHomes;
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        String name = "home";
        boolean hasHome = context.getNodes().stream().anyMatch(node -> {
            return node.getNode().getName().equals("homeName");
        });
        if (hasHome) {
            name = StringArgumentType.getString(context, "homeName");
        }
        String name2 = name.toLowerCase();
        ServerPlayer player = ((CommandSourceStack) context.getSource()).getPlayer();
        UUID uuid = player.getUUID();
        int currentHomes = PlayerData.getUserData().countPlayerHomes(uuid);
        if (ConfigManager.CONFIG.permissionConfigs.permissionsEnabled) {
            maxHomes = Permissions.getMaxHomeLimit(uuid);
        } else {
            maxHomes = ConfigManager.CONFIG.commandConfigs.teleportConfigs.defaultNumberOfHomes;
        }
        if (currentHomes >= maxHomes) {
            player.sendSystemMessage(TextUtils.formatMessage("You have reached your home limit of " + maxHomes + "."));
            if (maxHomes == 0) {
                player.sendSystemMessage(TextUtils.formatMessage("Your max homes is: 0. This is odd... Does your user group have a home.limit.NUMBER permission set? (eg: home.limit.5)"));
                return 1;
            }
            return 1;
        }
        boolean success = PlayerData.getUserData().addPlayerHome(uuid, new Home(name2, GlobalPos.of(player.level().dimension(), BlockPos.containing(player.getOnPos().getCenter()))));
        if (success) {
            player.sendSystemMessage(TextUtils.formatMessage("").append(Component.literal(ConfigManager.CONFIG.commandConfigs.teleportConfigs.setHomeText.replace("%homename%", name2))));
            return 1;
        }
        player.sendSystemMessage(TextUtils.formatMessage("").append(Component.literal(ConfigManager.CONFIG.commandConfigs.teleportConfigs.failedToSetHomeText.replace("%homename%", name2))));
        return 1;
    }

    private static int executeDelHome(CommandContext<CommandSourceStack> context) {
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        String name = "home";
        boolean hasHome = context.getNodes().stream().anyMatch(node -> {
            return node.getNode().getName().equals("homeName");
        });
        if (hasHome) {
            name = StringArgumentType.getString(context, "homeName");
        }
        String name2 = name.toLowerCase();
        if (PlayerData.getUserData().removePlayerHome(((CommandSourceStack) context.getSource()).getPlayer().getUUID(), name2)) {
            ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("").append(Component.literal(ConfigManager.CONFIG.commandConfigs.teleportConfigs.delHomeText.replace("%homename%", name2))));
            return 1;
        }
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("").append(Component.literal(ConfigManager.CONFIG.commandConfigs.teleportConfigs.failedToDelHomeText.replace("%homename%", name2))));
        return 1;
    }

    private static int executeGoHome(CommandContext<CommandSourceStack> context) {
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        String name = "home";
        boolean hasHome = context.getNodes().stream().anyMatch(node -> {
            return node.getNode().getName().equals("homeName");
        });
        if (hasHome) {
            name = StringArgumentType.getString(context, "homeName");
        }
        String name2 = name.toLowerCase();
        ServerPlayer p = ((CommandSourceStack) context.getSource()).getPlayer();
        if (PlayerData.getUserData().getPlayerHome(p.getUUID(), name2) != null) {
            if (!Permissions.cooldownChecker(p.getUUID(), Permissions.HOME_COMMAND_COOLDOWN_KEY)) {
                Permissions.handleCooldownNotExpired(p, Permissions.HOME_COMMAND_COOLDOWN_KEY);
                return 1;
            }
            Permissions.updateCooldown(p.getUUID(), Permissions.HOME_COMMAND_COOLDOWN_KEY, System.currentTimeMillis() + (((long) ConfigManager.CONFIG.commandConfigs.teleportConfigs.homeCommandCooldownSeconds) * 1000));
            Home home = PlayerData.getUserData().getPlayerHome(p.getUUID(), name2);
            ServerLevel levelToTPTo = CommonClass.minecraftServer.getLevel(home.pos.dimension());
            if (levelToTPTo != null) {
                teleportPlayer(p, home.pos, ConfigManager.CONFIG.commandConfigs.teleportConfigs.homeCommandWarmupSeconds, home.rotation);
                return 1;
            }
            p.sendSystemMessage(TextUtils.formatMessage("Error finding dimension to teleport to"));
            return 1;
        }
        p.sendSystemMessage(TextUtils.formatMessage("Couldn't find a home with the name: " + name2));
        return 1;
    }

    private static int executeListHomes(CommandContext<CommandSourceStack> context) {
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        ServerPlayer p = ((CommandSourceStack) context.getSource()).getPlayer();
        Collection<Home> data = PlayerData.getUserData().listPlayerHomes(p.getUUID());
        List<MutableComponent> comps = new ArrayList<>();
        for (Home entry : data) {
            MutableComponent comp = Component.literal("~ " + entry.name);
            Style style = Style.EMPTY.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal("Click here to teleport to this home"))).withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/he home " + entry.name)).withColor(ChatFormatting.GOLD);
            comp.setStyle(style);
            comps.add(comp);
        }
        new Pagination.PaginationBuilder(((CommandSourceStack) context.getSource()).getPlayer(), comps).linesPerPage(ConfigManager.CONFIG.commandConfigs.teleportConfigs.homeListLinesPerPage).header(ConfigManager.CONFIG.commandConfigs.teleportConfigs.homeListHeader).padding(ConfigManager.CONFIG.commandConfigs.teleportConfigs.homeListPadding).build().send();
        return 1;
    }

    private static int executeBack(CommandContext<CommandSourceStack> context) {
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        ServerPlayer player = ((CommandSourceStack) context.getSource()).getPlayer();
        if (!BackHandler.hasBackLocation(player)) {
            player.sendSystemMessage(TextUtils.formatMessage("").append(Component.literal(ConfigManager.CONFIG.commandConfigs.teleportConfigs.backCommandNoSavedDeathLocation)));
            return 0;
        }
        GlobalPos deathPos = BackHandler.getLastDeathLocation(player);
        ServerLevel level = player.server.getLevel(deathPos.dimension());
        BlockPos safePos = BackHandler.findSafeNearby(level, deathPos.pos(), 5);
        if (safePos != null) {
            if (!Permissions.cooldownChecker(player.getUUID(), Permissions.BACK_COMMAND_COOLDOWN_KEY)) {
                Permissions.handleCooldownNotExpired(player, Permissions.BACK_COMMAND_COOLDOWN_KEY);
                return 1;
            }
            Permissions.updateCooldown(player.getUUID(), Permissions.BACK_COMMAND_COOLDOWN_KEY, System.currentTimeMillis() + (((long) ConfigManager.CONFIG.commandConfigs.teleportConfigs.backCommandCooldownSeconds) * 1000));
            player.sendSystemMessage(TextUtils.formatMessage("").append(Component.literal(ConfigManager.CONFIG.commandConfigs.teleportConfigs.backCommandTeleportSuccess)));
            teleportPlayer(player, GlobalPos.of(level.dimension(), safePos), ConfigManager.CONFIG.commandConfigs.teleportConfigs.backCommandWarmupSeconds, player.getYRot());
            return 1;
        }
        player.sendSystemMessage(TextUtils.formatMessage("").append(Component.literal(ConfigManager.CONFIG.commandConfigs.teleportConfigs.backCommandNoSafeLocationFound)));
        return 0;
    }

    private static int executeTpa(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        ServerPlayer p = ((CommandSourceStack) context.getSource()).getPlayer();
        ServerPlayer toP = EntityArgument.getPlayer(context, "playerName");
        if (p.getScoreboardName().equals(toP.getScoreboardName())) {
            p.sendSystemMessage(TextUtils.formatMessage("Can't send a TPA request to yourself!"));
            return 1;
        }
        if (!Permissions.cooldownChecker(p.getUUID(), Permissions.TPA_COMMAND_COOLDOWN_KEY)) {
            Permissions.handleCooldownNotExpired(p, Permissions.TPA_COMMAND_COOLDOWN_KEY);
            return 1;
        }
        Permissions.updateCooldown(p.getUUID(), Permissions.TPA_COMMAND_COOLDOWN_KEY, System.currentTimeMillis() + (((long) ConfigManager.CONFIG.commandConfigs.teleportConfigs.tpaCommandCooldownSeconds) * 1000));
        UUID reqID = UUID.randomUUID();
        TpaHandler.addTpaRequest(reqID, new Tpa(p.getUUID(), toP.getUUID(), reqID));
        p.sendSystemMessage(TextUtils.getModPrefix().append(Component.literal(ConfigManager.CONFIG.commandConfigs.teleportConfigs.tpaRequestSentText)));
        Style acceptStyle = Style.EMPTY;
        MutableComponent acceptComp = Component.literal(ConfigManager.CONFIG.commandConfigs.teleportConfigs.tpaAcceptText).withStyle(acceptStyle.withColor(ChatFormatting.GREEN).withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/he tpaaccept " + String.valueOf(reqID))).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal(ConfigManager.CONFIG.commandConfigs.teleportConfigs.tpaAcceptHoverText))));
        Style denyStyle = Style.EMPTY;
        MutableComponent denyComp = Component.literal(ConfigManager.CONFIG.commandConfigs.teleportConfigs.tpaDenyText).withStyle(denyStyle.withColor(ChatFormatting.RED).withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/he tpadeny " + String.valueOf(reqID))).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal(ConfigManager.CONFIG.commandConfigs.teleportConfigs.tpaDenyHoverText))));
        MutableComponent separator = Component.literal(" | ").withStyle(ChatFormatting.GOLD);
        toP.sendSystemMessage(TextUtils.formatMessage(ConfigManager.CONFIG.commandConfigs.teleportConfigs.tpaRequestText.replace("%playername%", p.getName().getString())));
        MutableComponent finalMsg = Component.literal("").append(acceptComp).append(separator).append(denyComp);
        toP.sendSystemMessage(TextUtils.formatMessage("").append(finalMsg));
        return 1;
    }

    private static int executeTpaHere(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        ServerPlayer toP = ((CommandSourceStack) context.getSource()).getPlayer();
        ServerPlayer p = EntityArgument.getPlayer(context, "playerName");
        if (p.getScoreboardName().equals(toP.getScoreboardName())) {
            toP.sendSystemMessage(TextUtils.formatMessage("Can't send a TPA request to yourself!"));
            return 1;
        }
        if (!Permissions.cooldownChecker(toP.getUUID(), Permissions.TPA_COMMAND_COOLDOWN_KEY)) {
            Permissions.handleCooldownNotExpired(toP, Permissions.TPA_COMMAND_COOLDOWN_KEY);
            return 1;
        }
        Permissions.updateCooldown(toP.getUUID(), Permissions.TPA_COMMAND_COOLDOWN_KEY, System.currentTimeMillis() + (((long) ConfigManager.CONFIG.commandConfigs.teleportConfigs.tpaCommandCooldownSeconds) * 1000));
        UUID reqID = UUID.randomUUID();
        TpaHandler.addTpaRequest(reqID, new Tpa(p.getUUID(), toP.getUUID(), reqID));
        p.sendSystemMessage(TextUtils.getModPrefix().append(Component.literal(ConfigManager.CONFIG.commandConfigs.teleportConfigs.tpaRequestSentText)));
        Style acceptStyle = Style.EMPTY;
        MutableComponent acceptComp = Component.literal(ConfigManager.CONFIG.commandConfigs.teleportConfigs.tpaAcceptText).withStyle(acceptStyle.withColor(ChatFormatting.GREEN).withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/he tpaaccept " + String.valueOf(reqID))).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal(ConfigManager.CONFIG.commandConfigs.teleportConfigs.tpaAcceptHoverText))));
        Style denyStyle = Style.EMPTY;
        MutableComponent denyComp = Component.literal(ConfigManager.CONFIG.commandConfigs.teleportConfigs.tpaDenyText).withStyle(denyStyle.withColor(ChatFormatting.RED).withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/he tpadeny " + String.valueOf(reqID))).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal(ConfigManager.CONFIG.commandConfigs.teleportConfigs.tpaDenyHoverText))));
        MutableComponent separator = Component.literal(" | ").withStyle(ChatFormatting.GOLD);
        p.sendSystemMessage(TextUtils.formatMessage(ConfigManager.CONFIG.commandConfigs.teleportConfigs.tpaHereRequestText.replace("%playername%", toP.getName().getString())));
        MutableComponent finalMsg = Component.literal("").append(acceptComp).append(separator).append(denyComp);
        p.sendSystemMessage(TextUtils.formatMessage("").append(finalMsg));
        return 1;
    }

    private static int executeTpaAccept(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        UUID reqUUID = UuidArgument.getUuid(context, "requestUUID");
        if (!TpaHandler.tpaReqs.containsKey(reqUUID)) {
            ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage(ConfigManager.CONFIG.commandConfigs.teleportConfigs.tpaErrorText));
            return 1;
        }
        Tpa tpa = TpaHandler.tpaReqs.get(reqUUID);
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.getModPrefix().append(Component.literal(ConfigManager.CONFIG.commandConfigs.teleportConfigs.tpaRequestAcceptText)));
        ServerPlayer playerToTeleport = ((CommandSourceStack) context.getSource()).getServer().getPlayerList().getPlayer(tpa.UUIDToTeleport);
        ServerPlayer playerToTeleportTO = ((CommandSourceStack) context.getSource()).getServer().getPlayerList().getPlayer(tpa.teleportToUUID);
        String dim = playerToTeleportTO.serverLevel().dimension().location().toString();
        if (ConfigManager.CONFIG.permissionConfigs.permissionRequiredToEnterDimensions && !dim.equals(ConfigManager.CONFIG.permissionConfigs.defaultDimensionNoPermsRequired) && !Permissions.permissionCheck(playerToTeleport.getUUID(), "dimension." + dim + ".tpa", ((CommandSourceStack) context.getSource()).getServer())) {
            playerToTeleport.sendSystemMessage(TextUtils.formatMessage(ConfigManager.CONFIG.commandConfigs.teleportConfigs.tpaNoPermissionDimension.replace("%dimension%", dim)));
            return 1;
        }
        TpaHandler.tpaReqs.remove(reqUUID);
        teleportPlayer(playerToTeleport, GlobalPos.of(playerToTeleportTO.level().dimension(), playerToTeleportTO.getOnPos()), ConfigManager.CONFIG.commandConfigs.teleportConfigs.tpaCommandWarmupSeconds, playerToTeleport.getYRot());
        return 1;
    }

    public static void teleportPlayer(ServerPlayer playerToTeleport, GlobalPos location, int warmupSeconds, float rotation) {
        if (warmupSeconds <= 0) {
            ServerLevel sLevel = CommonClass.minecraftServer.getLevel(location.dimension());
            if (ConfigManager.CONFIG.permissionConfigs.permissionRequiredToEnterDimensions && !ConfigManager.CONFIG.permissionConfigs.defaultDimensionNoPermsRequired.equals(sLevel.dimension().location().toString()) && !Permissions.permissionCheck(playerToTeleport.getUUID(), "dimension." + String.valueOf(sLevel.dimension().location()), CommonClass.minecraftServer)) {
                playerToTeleport.sendSystemMessage(TextUtils.formatMessage(ConfigManager.CONFIG.commandConfigs.teleportConfigs.normalTeleportToDimNoPermission.replace("%dimension%", sLevel.dimension().location().toString())));
                return;
            }
            if (ConfigManager.CONFIG.commandConfigs.teleportConfigs.backCommandSavesLastTeleport) {
                BackHandler.setLastDeathLocation(playerToTeleport, GlobalPos.of(playerToTeleport.level().dimension(), playerToTeleport.getOnPos()));
            }
            playerToTeleport.teleportTo(sLevel, location.pos().getCenter().x(), location.pos().getCenter().y() + 1.0d, location.pos().getCenter().z(), rotation, playerToTeleport.getXRot());
            return;
        }
        AtomicInteger seconds = new AtomicInteger(warmupSeconds);
        UUID taskID = UUID.randomUUID();
        playerToTeleport.sendSystemMessage(TextUtils.formatMessage(ConfigManager.CONFIG.commandConfigs.teleportConfigs.beforeTPText.replace("%warmupseconds%", String.valueOf(warmupSeconds))));
        CommonClass.teleportMoveLock.put(playerToTeleport.getUUID(), playerToTeleport.getOnPos());
        TaskManager.addTask(Task.builder().name(taskID.toString()).interval(1, TimeUnit.SECONDS).execute(task -> {
            seconds.getAndDecrement();
            if (seconds.get() == 0) {
                if (playerToTeleport != null && location != null) {
                    BlockPos prev = CommonClass.teleportMoveLock.get(playerToTeleport.getUUID());
                    BlockPos now = playerToTeleport.getOnPos();
                    boolean isPos = prev.getX() == now.getX() && prev.getZ() == now.getZ();
                    if (isPos || !ConfigManager.CONFIG.commandConfigs.teleportConfigs.teleportsShouldEnforceNoMovementWhileWaitingForWarmup) {
                        if (ConfigManager.CONFIG.commandConfigs.teleportConfigs.backCommandSavesLastTeleport) {
                            BackHandler.setLastDeathLocation(playerToTeleport, GlobalPos.of(playerToTeleport.level().dimension(), playerToTeleport.getOnPos()));
                        }
                        playerToTeleport.teleportTo(CommonClass.minecraftServer.getLevel(location.dimension()), location.pos().getCenter().x(), location.pos().getCenter().y() + 0.5d, location.pos().getCenter().z(), rotation, 0.0f);
                    } else {
                        playerToTeleport.sendSystemMessage(TextUtils.formatMessage(ConfigManager.CONFIG.commandConfigs.teleportConfigs.teleportCancelledText));
                    }
                }
                task.completed = true;
            }
        }).build());
    }

    private static int executeTpaDeny(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        if (!((CommandSourceStack) context.getSource()).isPlayer()) {
            return 1;
        }
        UUID reqUUID = UuidArgument.getUuid(context, "requestUUID");
        if (!TpaHandler.tpaReqs.containsKey(reqUUID)) {
            return 1;
        }
        Tpa tpa = TpaHandler.tpaReqs.get(reqUUID);
        ServerPlayer playerToTeleport = ((CommandSourceStack) context.getSource()).getServer().getPlayerList().getPlayer(tpa.UUIDToTeleport);
        ServerPlayer playerToTeleportTO = ((CommandSourceStack) context.getSource()).getServer().getPlayerList().getPlayer(tpa.teleportToUUID);
        playerToTeleport.sendSystemMessage(TextUtils.formatMessage("TPA request denied."));
        playerToTeleportTO.sendSystemMessage(TextUtils.formatMessage("TPA request denied."));
        TpaHandler.tpaReqs.remove(reqUUID);
        return 1;
    }
}
