package com.henny.hennyessentials.data;

import com.henny.hennyessentials.CommonClass;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.datafix.DataFixTypes;
import net.minecraft.world.level.saveddata.SavedData;

public class PermissionGroupData extends SavedData {
    public Map<String, List<String>> groupPermissions;
    public Map<String, Component> groupPrefixes;
    public Map<String, Component> groupSuffixes;

    public PermissionGroupData(Map<String, List<String>> groupPermissions, Map<String, Component> groupPrefixes, Map<String, Component> groupSuffixes) {
        this.groupPermissions = groupPermissions;
        this.groupPrefixes = groupPrefixes;
        this.groupSuffixes = groupSuffixes;
    }

    public PermissionGroupData() {
        this.groupPermissions = new HashMap();
        this.groupPrefixes = new HashMap();
        this.groupSuffixes = new HashMap();
    }

    public static SavedData.Factory<PermissionGroupData> factory() {
        return new SavedData.Factory<>(PermissionGroupData::new, PermissionGroupData::load, DataFixTypes.LEVEL);
    }

    private static PermissionGroupData load(CompoundTag compoundTag, HolderLookup.Provider provider) {
        Map<String, List<String>> allGroupPermsTempList = new HashMap<>();
        Map<String, Component> allGroupPrefixesList = new HashMap<>();
        Map<String, Component> allGroupSuffixesList = new HashMap<>();
        CompoundTag groupPermsTag = compoundTag.getCompound("groupPerms");
        CompoundTag groupPrefixesTag = compoundTag.getCompound("groupPrefixes");
        CompoundTag groupSuffixesTag = compoundTag.getCompound("groupSuffixes");
        for (String groupName : groupPermsTag.getAllKeys()) {
            ArrayList<String> specificGroupPermsTempList = new ArrayList<>();
            ListTag specificGroupPermsNBTList = groupPermsTag.get(groupName);
            specificGroupPermsNBTList.forEach(tag -> {
                specificGroupPermsTempList.add(tag.getAsString());
            });
            if (!specificGroupPermsTempList.stream().anyMatch(s -> {
                return s.startsWith("weight.");
            })) {
                specificGroupPermsTempList.add("weight.1");
            }
            allGroupPermsTempList.put(groupName, specificGroupPermsTempList);
        }
        for (String groupName2 : groupPrefixesTag.getAllKeys()) {
            String prefix = groupPrefixesTag.getString(groupName2);
            allGroupPrefixesList.put(groupName2, Component.Serializer.fromJsonLenient(prefix, provider));
        }
        for (String groupName3 : groupSuffixesTag.getAllKeys()) {
            String suffix = groupSuffixesTag.getString(groupName3);
            allGroupSuffixesList.put(groupName3, Component.Serializer.fromJsonLenient(suffix, provider));
        }
        return new PermissionGroupData(allGroupPermsTempList, allGroupPrefixesList, allGroupSuffixesList);
    }

    public CompoundTag save(CompoundTag compoundTag, HolderLookup.Provider provider) {
        CompoundTag groupPerms = new CompoundTag();
        CompoundTag groupPrefxs = new CompoundTag();
        CompoundTag groupSuffxs = new CompoundTag();
        for (Map.Entry<String, List<String>> entry : this.groupPermissions.entrySet()) {
            ListTag individualGroupPerms = new ListTag();
            for (String individualPermNode : entry.getValue()) {
                individualGroupPerms.add(StringTag.valueOf(individualPermNode));
            }
            groupPerms.put(entry.getKey(), individualGroupPerms);
        }
        for (Map.Entry<String, Component> entry2 : this.groupPrefixes.entrySet()) {
            Component prefix = entry2.getValue();
            String prefixString = Component.Serializer.toJson(prefix, provider);
            groupPrefxs.put(entry2.getKey(), StringTag.valueOf(prefixString));
        }
        for (Map.Entry<String, Component> entry3 : this.groupSuffixes.entrySet()) {
            Component suffix = entry3.getValue();
            String suffixString = Component.Serializer.toJson(suffix, provider);
            groupSuffxs.put(entry3.getKey(), StringTag.valueOf(suffixString));
        }
        compoundTag.put("groupPerms", groupPerms);
        compoundTag.put("groupPrefixes", groupPrefxs);
        compoundTag.put("groupSuffixes", groupSuffxs);
        return compoundTag;
    }

    public static List<String> getPermissionsForGroup(String group, MinecraftServer server) {
        return getPermissionGroupData(CommonClass.minecraftServer).groupPermissions.getOrDefault(group, List.of(""));
    }

    public static boolean permissionCheckGroup(String groupName, String permission, MinecraftServer minecraftServer) {
        PermissionGroupData perms = getPermissionGroupData(minecraftServer);
        List<String> groupPerms = perms.groupPermissions.getOrDefault(groupName, List.of());
        if (groupPerms.contains(permission)) {
            return true;
        }
        String[] parts = permission.split("\\.");
        if (parts.length >= 2) {
            String commandWildcard = parts[0] + "." + parts[1] + ".*";
            if (groupPerms.contains(commandWildcard)) {
                return true;
            }
        }
        if (groupPerms.contains(parts[0] + ".*")) {
            return true;
        }
        for (String group : groupPerms) {
            if (group.startsWith("group.")) {
                String inheritedGroup = group.substring(6);
                if (permissionCheckGroup(inheritedGroup, permission, minecraftServer)) {
                    return true;
                }
            }
        }
        return false;
    }

    public void addGroupPermission(String groupName, String permission) {
        if (!this.groupPermissions.containsKey(groupName)) {
            this.groupPermissions.put(groupName, new ArrayList());
        }
        List<String> groupPermList = this.groupPermissions.get(groupName);
        if (!groupPermList.contains(permission.toLowerCase())) {
            groupPermList.add(permission.toLowerCase());
        }
        this.groupPermissions.put(groupName, groupPermList);
        setDirty();
    }

    public void removeGroupPermission(String groupName, String permission) {
        if (!this.groupPermissions.containsKey(groupName)) {
            this.groupPermissions.put(groupName, new ArrayList());
        }
        List<String> groupPermList = this.groupPermissions.get(groupName);
        groupPermList.removeIf(next -> {
            return Objects.equals(next, permission);
        });
        this.groupPermissions.put(groupName, groupPermList);
        setDirty();
    }

    public static Optional<String> findHighestWeightedGroup(List<String> groups, MinecraftServer minecraftServer) {
        return groups.stream().max(Comparator.comparingInt(group -> {
            return getGroupWeight(group, minecraftServer);
        }));
    }

    public static Optional<Component> getGroupPrefix(String group, MinecraftServer minecraftServer) {
        PermissionGroupData perms = getPermissionGroupData(minecraftServer);
        return Optional.ofNullable(perms.groupPrefixes.get(group));
    }

    public static Optional<Component> getGroupSuffix(String group, MinecraftServer minecraftServer) {
        PermissionGroupData perms = getPermissionGroupData(minecraftServer);
        return Optional.ofNullable(perms.groupSuffixes.get(group));
    }

    public static int getGroupWeight(String group, MinecraftServer minecraftServer) {
        return getPermissionGroupData(minecraftServer).groupPermissions.getOrDefault(group, List.of()).stream().filter(perm -> {
            return perm.startsWith("weight.");
        }).mapToInt(perm2 -> {
            return Integer.parseInt(perm2.replace("weight.", ""));
        }).max().orElse(0);
    }

    public void addGroupPrefix(String groupName, Component prefix) {
        this.groupPrefixes.put(groupName, prefix);
        setDirty();
    }

    public void removeGroupPrefix(String groupName) {
        this.groupPrefixes.remove(groupName);
        setDirty();
    }

    public void addGroupSuffix(String groupName, Component suffix) {
        this.groupSuffixes.put(groupName, suffix);
        setDirty();
    }

    public void removeGroupSuffix(String groupName) {
        this.groupSuffixes.remove(groupName);
        setDirty();
    }

    public static PermissionGroupData getPermissionGroupData(MinecraftServer minecraftServer) {
        return (PermissionGroupData) minecraftServer.overworld().getDataStorage().computeIfAbsent(factory(), "hennyessentials-permissions-group");
    }
}
