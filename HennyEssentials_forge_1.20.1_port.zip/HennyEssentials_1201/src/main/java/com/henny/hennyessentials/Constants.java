package com.henny.hennyessentials;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Constants {
    public static final String MOD_ID = "hennyessentials";
    public static final String MOD_NAME = "Henny Essentials";
    public static final Logger LOG = LoggerFactory.getLogger(MOD_NAME);
    public static final int VERSION = 104;
    public static final int SUB_VERSION = 7;
}
