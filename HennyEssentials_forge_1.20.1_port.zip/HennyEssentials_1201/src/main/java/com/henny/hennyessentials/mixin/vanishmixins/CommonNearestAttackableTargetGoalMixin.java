package com.henny.hennyessentials.mixin.vanishmixins;

import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({NearestAttackableTargetGoal.class})
public abstract class CommonNearestAttackableTargetGoalMixin {
}
