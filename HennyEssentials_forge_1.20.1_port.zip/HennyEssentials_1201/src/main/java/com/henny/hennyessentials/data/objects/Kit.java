package com.henny.hennyessentials.data.objects;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class Kit {
    public String name;
    public int cooldownSeconds;
    public List<ItemStack> items;
    public String category;
    public ItemStack displayItem;
    public ItemStack categoryDisplayItem;

    public Kit(String name) {
        this.category = "default";
        this.displayItem = new ItemStack(Items.CHEST);
        this.categoryDisplayItem = new ItemStack(Items.SHULKER_BOX);
        this.name = name;
        this.cooldownSeconds = 0;
        this.items = new ArrayList();
        this.category = "default";
    }

    public Kit(String name, int cooldownSeconds) {
        this.category = "default";
        this.displayItem = new ItemStack(Items.CHEST);
        this.categoryDisplayItem = new ItemStack(Items.SHULKER_BOX);
        this.name = name;
        this.cooldownSeconds = cooldownSeconds;
        this.items = new ArrayList();
        this.category = "default";
    }

    public Kit(String name, int cooldownSeconds, List<ItemStack> items) {
        this.category = "default";
        this.displayItem = new ItemStack(Items.CHEST);
        this.categoryDisplayItem = new ItemStack(Items.SHULKER_BOX);
        this.name = name;
        this.cooldownSeconds = cooldownSeconds;
        this.items = items;
        this.category = "default";
    }
}
