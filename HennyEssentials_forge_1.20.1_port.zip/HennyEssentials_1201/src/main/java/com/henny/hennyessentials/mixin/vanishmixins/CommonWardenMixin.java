package com.henny.hennyessentials.mixin.vanishmixins;

import com.henny.hennyessentials.CommonClass;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.warden.Warden;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({Warden.class})
public class CommonWardenMixin {
    @Inject(method = {"canTargetEntity"}, at = {@At("HEAD")}, cancellable = true)
    private void onCanTargetEntity(Entity p_219386_, CallbackInfoReturnable<Boolean> cir) {
        if (p_219386_ instanceof ServerPlayer) {
            ServerPlayer p = (ServerPlayer) p_219386_;
            if (CommonClass.playersInVanish.getOrDefault(p.getUUID(), false).booleanValue()) {
                cir.setReturnValue(false);
            }
        }
    }

    @Inject(method = {"setAttackTarget"}, at = {@At("HEAD")}, cancellable = true)
    private void something(LivingEntity pAttackTarget, CallbackInfo ci) {
        if (pAttackTarget instanceof ServerPlayer) {
            ServerPlayer p = (ServerPlayer) pAttackTarget;
            if (CommonClass.playersInVanish.getOrDefault(p.getUUID(), false).booleanValue()) {
                ci.cancel();
            }
        }
    }
}
