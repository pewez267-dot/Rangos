package com.henny.hennyessentials.platform;

import com.henny.hennyessentials.platform.services.IPlatformHelper;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.loading.FMLLoader;

public class ForgePlatformHelper implements IPlatformHelper {
    @Override // com.henny.hennyessentials.platform.services.IPlatformHelper
    public String getPlatformName() {
        return "Forge";
    }

    @Override // com.henny.hennyessentials.platform.services.IPlatformHelper
    public boolean isModLoaded(String modId) {
        return ModList.get().isLoaded(modId);
    }

    @Override // com.henny.hennyessentials.platform.services.IPlatformHelper
    public boolean isDevelopmentEnvironment() {
        return !FMLLoader.isProduction();
    }
}
