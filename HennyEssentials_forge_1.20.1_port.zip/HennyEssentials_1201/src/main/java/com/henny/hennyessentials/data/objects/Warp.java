package com.henny.hennyessentials.data.objects;

import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class Warp {
    public long expiry;
    public BlockPos blockPos;
    public String name;
    public String dimension;
    public String category;
    public ItemStack displayItem;
    public ItemStack categoryDisplayItem;
    public float rotation;

    public Warp(String name, BlockPos blockPos, String dimension) {
        this.category = "default";
        this.displayItem = new ItemStack(Items.ENDER_PEARL);
        this.categoryDisplayItem = new ItemStack(Items.END_PORTAL_FRAME);
        this.rotation = 0.0f;
        this.name = name;
        this.blockPos = blockPos;
        this.dimension = dimension;
        this.expiry = 0L;
        this.displayItem = new ItemStack(Items.ENDER_PEARL);
        this.categoryDisplayItem = new ItemStack(Items.END_PORTAL_FRAME);
        this.rotation = 0.0f;
    }

    public Warp(String name, BlockPos blockPos, String dimension, long expiry) {
        this.category = "default";
        this.displayItem = new ItemStack(Items.ENDER_PEARL);
        this.categoryDisplayItem = new ItemStack(Items.END_PORTAL_FRAME);
        this.rotation = 0.0f;
        this.name = name;
        this.blockPos = blockPos;
        this.dimension = dimension;
        this.expiry = expiry;
        this.displayItem = new ItemStack(Items.ENDER_PEARL);
        this.categoryDisplayItem = new ItemStack(Items.END_PORTAL_FRAME);
        this.rotation = 0.0f;
    }
}
