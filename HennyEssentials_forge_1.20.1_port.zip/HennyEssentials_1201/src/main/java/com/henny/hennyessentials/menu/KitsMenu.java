package com.henny.hennyessentials.menu;

import com.henny.hennyessentials.command.KitCommands;
import com.henny.hennyessentials.data.KitData;
import com.henny.hennyessentials.data.objects.Kit;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.jetbrains.annotations.NotNull;

public class KitsMenu extends AbstractContainerMenu {
    private final SimpleContainer container;
    private final List<ItemStack> allItems;
    private int currentPage;
    private String currentCategory;
    private final int itemsPerPage = 26;
    private final int totalSlots = 54;
    private static final int PREV_PAGE_SLOT = 52;
    private static final int NEXT_PAGE_SLOT = 53;
    private final KitData kitData;

    public KitsMenu(int id, Inventory playerInventory, KitData kitData) {
        super(MenuType.GENERIC_9x6, id);
        this.currentPage = 0;
        this.currentCategory = null;
        this.itemsPerPage = 26;
        this.totalSlots = 54;
        this.kitData = kitData;
        this.container = new SimpleContainer(54);
        this.allItems = new ArrayList();
        for (int i = 0; i < this.container.getContainerSize(); i++) {
            addSlot(new Slot(this, this.container, i, 8 + ((i % 9) * 18), 18 + ((i / 9) * 18)) { // from class: com.henny.hennyessentials.menu.KitsMenu.1
                public boolean mayPlace(ItemStack pStack) {
                    return false;
                }

                public boolean mayPickup(Player pPlayer) {
                    return false;
                }
            });
        }
        if (kitData.currentlyMoreThanOneCategory()) {
            loadCategoryItems();
        } else {
            loadDefaultItems();
        }
        populatePage();
    }

    private void loadDefaultItems() {
        this.allItems.clear();
        for (Kit kit : this.kitData.kits.values()) {
            ItemStack kitItem = new ItemStack(Items.SHULKER_BOX);
            if (!kit.displayItem.isEmpty()) {
                kitItem = kit.displayItem;
            }
            kitItem.setHoverName(Component.literal("Kit: " + kit.name));
            CompoundTag tag = new CompoundTag();
            tag.putString("he-kit", kit.name);
            kitItem.setTag(tag);
            this.allItems.add(kitItem);
        }
    }

    private void loadCategoryItems() {
        this.allItems.clear();
        List<String> categories = new ArrayList<>();
        for (Kit kit : this.kitData.kits.values()) {
            String category = kit.category != null ? kit.category : "default";
            if (!categories.contains(category)) {
                categories.add(category);
                ItemStack categoryItem = new ItemStack(Items.SHULKER_BOX);
                if (!kit.categoryDisplayItem.isEmpty()) {
                    categoryItem = kit.categoryDisplayItem;
                }
                categoryItem.setHoverName(Component.literal("Category: " + category));
                CompoundTag tag = new CompoundTag();
                tag.putString("he-category", category);
                categoryItem.setTag(tag);
                this.allItems.add(categoryItem);
            }
        }
    }

    private void loadKitsForCategory(String category) {
        this.allItems.clear();
        for (Map.Entry<String, Kit> entry : this.kitData.kits.entrySet()) {
            Kit kit = entry.getValue();
            String kitCategory = kit.category != null ? kit.category : "default";
            if (kitCategory.equals(category)) {
                ItemStack kitItem = new ItemStack(Items.CHEST);
                if (!kit.displayItem.isEmpty()) {
                    kitItem = kit.displayItem;
                }
                kitItem.setHoverName(Component.literal("Kit: " + entry.getKey()));
                CompoundTag tag = new CompoundTag();
                tag.putString("he-kit", entry.getKey());
                kitItem.setTag(tag);
                this.allItems.add(kitItem);
            }
        }
        ItemStack backItem = new ItemStack(Items.BARRIER);
        backItem.setHoverName(Component.literal("Back to Categories"));
        CompoundTag tag2 = new CompoundTag();
        tag2.putBoolean("he-back", true);
        backItem.setTag(tag2);
        this.allItems.add(backItem);
    }

    public void clicked(int slotId, int button, @NotNull ClickType clickType, @NotNull Player player) {
        if (player instanceof ServerPlayer) {
            ServerPlayer sp = (ServerPlayer) player;
            if (slotId == PREV_PAGE_SLOT) {
                if (this.currentPage > 0) {
                    this.currentPage--;
                    populatePage();
                    return;
                }
                return;
            }
            if (slotId == NEXT_PAGE_SLOT) {
                if (this.currentPage < getMaxPage()) {
                    this.currentPage++;
                    populatePage();
                    return;
                }
                return;
            }
            if (slotId < 0 || slotId >= this.container.getContainerSize()) {
                return;
            }
            ItemStack clicked = getSlot(slotId).getItem();
            CompoundTag itemCustomData = clicked.hasTag() ? clicked.getTag() : new CompoundTag();
            if (itemCustomData.contains("he-kit")) {
                String kitName = itemCustomData.getString("he-kit");
                if (this.kitData.kits.containsKey(kitName)) {
                    KitCommands.giveKitToPlayer(sp, kitName);
                    sp.closeContainer();
                    return;
                }
                return;
            }
            if (itemCustomData.contains("he-category")) {
                this.currentCategory = itemCustomData.getString("he-category");
                loadKitsForCategory(this.currentCategory);
                this.currentPage = 0;
                populatePage();
                return;
            }
            if (itemCustomData.contains("he-back")) {
                this.currentCategory = null;
                loadCategoryItems();
                this.currentPage = 0;
                populatePage();
            }
        }
    }

    public ItemStack quickMoveStack(Player player, int i) {
        return ItemStack.EMPTY;
    }

    public boolean stillValid(Player player) {
        return true;
    }

    private void populatePage() {
        for (int i = 0; i < 26; i++) {
            this.container.setItem(i, ItemStack.EMPTY);
        }
        ItemStack blackGlass = new ItemStack(Items.BLACK_STAINED_GLASS_PANE);
        blackGlass.setHoverName(Component.literal("Henny Essentials Mod").withStyle(ChatFormatting.GREEN));
        ItemStack limeGlass = new ItemStack(Items.LIME_STAINED_GLASS_PANE);
        limeGlass.setHoverName(Component.literal("Henny Essentials Mod").withStyle(ChatFormatting.GREEN));
        int i2 = 0;
        while (i2 < 54) {
            boolean isBorder = i2 < 9 || i2 >= 45 || i2 % 9 == 0 || i2 % 9 == 8;
            if (isBorder && i2 != PREV_PAGE_SLOT && i2 != NEXT_PAGE_SLOT) {
                ItemStack glass = i2 % 2 == 0 ? blackGlass.copy() : limeGlass.copy();
                this.container.setItem(i2, glass);
            }
            i2++;
        }
        int start = this.currentPage * 26;
        int itemIndex = 0;
        int i3 = 0;
        while (i3 < 54) {
            boolean isBorder2 = i3 < 9 || i3 >= 45 || i3 % 9 == 0 || i3 % 9 == 8;
            if (!isBorder2 && i3 != PREV_PAGE_SLOT && i3 != NEXT_PAGE_SLOT) {
                int i4 = itemIndex;
                itemIndex++;
                int index = start + i4;
                if (index < this.allItems.size()) {
                    this.container.setItem(i3, this.allItems.get(index));
                }
            }
            i3++;
        }
        ItemStack nextPage = new ItemStack(Items.ARROW);
        nextPage.setHoverName(Component.literal("Next Page"));
        ItemStack prevPage = new ItemStack(Items.ARROW);
        prevPage.setHoverName(Component.literal("Previous Page"));
        this.container.setItem(PREV_PAGE_SLOT, this.currentPage > 0 ? prevPage : ItemStack.EMPTY);
        this.container.setItem(NEXT_PAGE_SLOT, this.currentPage < getMaxPage() ? nextPage : ItemStack.EMPTY);
    }

    private int getMaxPage() {
        return ((int) Math.ceil(((double) this.allItems.size()) / 26.0d)) - 1;
    }
}
