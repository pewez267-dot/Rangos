package com.henny.hennyessentials.config.objects;

import com.google.gson.annotations.Expose;
import com.henny.hennyessentials.data.objects.ConfigPage;
import java.util.ArrayList;
import java.util.List;

public class PagesConfig {

    @Expose
    public List<ConfigPage> pages = new ArrayList<ConfigPage>() { // from class: com.henny.hennyessentials.config.objects.PagesConfig.1
        {
            add(new ConfigPage(5, List.of("§aA line on a page.", "§bAnother line!"), "§bDefault §aPage", "default", "§8~"));
        }
    };
}
