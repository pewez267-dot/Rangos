package com.henny.hennyessentials.config.objects;

import com.google.gson.annotations.Expose;
import com.henny.hennyessentials.data.objects.CommandToken;
import java.util.List;

public class CommandTokensConfig {

    @Expose
    public List<CommandToken> tokens = List.of(new CommandToken("example", List.of("give %p minecraft:diamond 2"), "example", "hi"), new CommandToken("examplewithpermission", (List<String>) List.of("say %p has the correct permission!"), "permission", "IF permissions are enabled, this token will only work for players with permission: some.random.permission", "some.random.permission"));
}
