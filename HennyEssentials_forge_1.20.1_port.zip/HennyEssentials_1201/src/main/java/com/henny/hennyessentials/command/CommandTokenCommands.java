package com.henny.hennyessentials.command;

import com.henny.hennyessentials.config.ConfigManager;
import com.henny.hennyessentials.data.objects.CommandToken;
import com.henny.hennyessentials.permission.Permissions;
import com.henny.hennyessentials.util.TextUtils;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class CommandTokenCommands {
    public static List<LiteralArgumentBuilder<CommandSourceStack>> buildCommandTokenCommands() {
        ArrayList<LiteralArgumentBuilder<CommandSourceStack>> returnList = new ArrayList<>();
        LiteralArgumentBuilder<CommandSourceStack> tokenCommand = Commands.literal("token");
        LiteralArgumentBuilder<CommandSourceStack> giveTokenCommand = Commands.literal("give");
        LiteralArgumentBuilder<CommandSourceStack> reloadConfigCommand = Commands.literal("reloadConfig");
        reloadConfigCommand.executes(CommandTokenCommands::executeReloadConfig).requires(src -> {
            return ModCommands.getRequirements(src, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.TOKEN_RELOAD_PERMISSION));
        });
        tokenCommand.requires(src2 -> {
            return ModCommands.getRequirements(src2, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.TOKEN_PERMISSION));
        });
        giveTokenCommand.requires(src3 -> {
            return ModCommands.getRequirements(src3, (List<String>) List.of(Permissions.ADMIN_PERMISSIONS, Permissions.TOKEN_GIVE_PERMISSION));
        });
        giveTokenCommand.then(Commands.argument("player", EntityArgument.player()).then(Commands.argument("token", StringArgumentType.string()).suggests(CommandTokenCommands::suggestTokenOptions).then(Commands.argument("isLockedToReceivingPlayer?", BoolArgumentType.bool()).executes(CommandTokenCommands::executeGiveToken)).executes(CommandTokenCommands::executeGiveToken)));
        tokenCommand.then(giveTokenCommand);
        tokenCommand.then(reloadConfigCommand);
        returnList.add(tokenCommand);
        return returnList;
    }

    private static int executeGiveToken(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        ServerPlayer targetPlayer = EntityArgument.getPlayer(context, "player");
        String tokenName = StringArgumentType.getString(context, "token");
        ItemStack tokenItem = new ItemStack(Items.PAPER);
        boolean isLockedToReceivingPlayer = context.getNodes().stream().map((v0) -> {
            return v0.getNode();
        }).anyMatch(node -> {
            return node.getName().equals("isLockedToReceivingPlayer?");
        }) ? BoolArgumentType.getBool(context, "isLockedToReceivingPlayer?") : false;
        ItemStack tokenStack = CommandToken.createTokenItemStack(tokenItem, tokenName, isLockedToReceivingPlayer, targetPlayer);
        targetPlayer.getInventory().add(tokenStack);
        return 1;
    }

    private static int executeReloadConfig(CommandContext<CommandSourceStack> context) {
        ConfigManager.reloadCommandTokens();
        ((CommandSourceStack) context.getSource()).sendSystemMessage(TextUtils.formatMessage("CommandTokens config reloaded"));
        return 1;
    }

    private static CompletableFuture<Suggestions> suggestTokenOptions(CommandContext<CommandSourceStack> context, SuggestionsBuilder builder) {
        for (String tokenAlias : ConfigManager.TOKENS.keySet()) {
            builder.suggest(tokenAlias);
        }
        return builder.buildFuture();
    }
}
