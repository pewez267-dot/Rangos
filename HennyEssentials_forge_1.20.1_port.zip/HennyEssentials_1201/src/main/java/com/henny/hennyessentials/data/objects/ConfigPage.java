package com.henny.hennyessentials.data.objects;

import com.google.gson.annotations.Expose;
import java.util.ArrayList;
import java.util.List;

public class ConfigPage {

    @Expose
    public int linesPerPage;

    @Expose
    public List<String> content;

    @Expose
    public String header;

    @Expose
    public String pageID;

    @Expose
    public String padding;

    public ConfigPage(int linesPerPage, List<String> content, String header, String pageID, String padding) {
        this.linesPerPage = 5;
        this.content = new ArrayList();
        this.header = "Page Name";
        this.pageID = "apageid";
        this.padding = "~";
        this.linesPerPage = linesPerPage;
        this.content = content;
        this.header = header;
        this.pageID = pageID;
        this.padding = padding;
    }

    public ConfigPage(int linesPerPage, String header, String pageID, String padding) {
        this.linesPerPage = 5;
        this.content = new ArrayList();
        this.header = "Page Name";
        this.pageID = "apageid";
        this.padding = "~";
        this.linesPerPage = linesPerPage;
        this.content = this.content;
        this.header = header;
        this.pageID = pageID;
        this.padding = padding;
    }

    public void addContent(String line) {
        this.content.add(line);
    }

    public void addContent(List<String> lines) {
        this.content.addAll(lines);
    }

    public void setContent(List<String> lines) {
        this.content.clear();
        this.content.addAll(lines);
    }
}
