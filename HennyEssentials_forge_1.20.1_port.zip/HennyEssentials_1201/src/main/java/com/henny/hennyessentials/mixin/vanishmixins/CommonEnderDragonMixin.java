package com.henny.hennyessentials.mixin.vanishmixins;

import com.henny.hennyessentials.CommonClass;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({EnderDragon.class})
public class CommonEnderDragonMixin {
    @Inject(method = {"canAttack"}, at = {@At("HEAD")}, cancellable = true)
    private void onCanAttack(LivingEntity pTarget, CallbackInfoReturnable<Boolean> cir) {
        if (pTarget instanceof ServerPlayer) {
            ServerPlayer p = (ServerPlayer) pTarget;
            if (CommonClass.playersInVanish.getOrDefault(p.getUUID(), false).booleanValue()) {
                cir.setReturnValue(false);
            }
        }
    }
}
