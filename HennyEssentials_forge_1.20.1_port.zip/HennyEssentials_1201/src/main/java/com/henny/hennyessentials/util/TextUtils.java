package com.henny.hennyessentials.util;

import com.henny.hennyessentials.config.ConfigManager;
import java.time.Duration;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.ChatFormatting;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.HoverEvent;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

public class TextUtils {
    private static final String DURATION_REGEX = "(\\d+)([YMWDms])";
    private static final Pattern pattern = Pattern.compile(DURATION_REGEX);

    public static String readableDuration(long millis) {
        Duration duration = Duration.ofMillis(millis);
        long days = duration.toDays();
        long years = days / 365;
        long months = (days % 365) / 30;
        long weeks = ((days % 365) % 30) / 7;
        long remainingDays = ((days % 365) % 30) % 7;
        long hours = duration.toHours() % 24;
        long minutes = duration.toMinutes() % 60;
        long seconds = duration.getSeconds() % 60;
        Map<String, Long> timeMap = new LinkedHashMap<>();
        timeMap.put("Y", Long.valueOf(years));
        timeMap.put("M", Long.valueOf(months));
        timeMap.put("W", Long.valueOf(weeks));
        timeMap.put("d", Long.valueOf(remainingDays));
        timeMap.put("h", Long.valueOf(hours));
        timeMap.put("m", Long.valueOf(minutes));
        timeMap.put("s", Long.valueOf(seconds));
        StringBuilder readableTime = new StringBuilder();
        for (Map.Entry<String, Long> entry : timeMap.entrySet()) {
            long value = entry.getValue().longValue();
            if (value > 0) {
                readableTime.append(value).append(entry.getKey());
            }
        }
        return readableTime.length() > 0 ? readableTime.toString() : "less than a second";
    }

    public static String serializeGlobalPos(GlobalPos pos) {
        ResourceLocation dimensionId = pos.dimension().location();
        BlockPos blockPos = pos.pos();
        return String.valueOf(dimensionId) + ":" + blockPos.getX() + "," + blockPos.getY() + "," + blockPos.getZ();
    }

    public static Set<Character> extractFormats(String rawMessage) {
        Set<Character> usedCodes = new HashSet<>();
        for (int i = 0; i < rawMessage.length() - 1; i++) {
            if (rawMessage.charAt(i) == 167) {
                char code = Character.toLowerCase(rawMessage.charAt(i + 1));
                usedCodes.add(Character.valueOf(code));
            }
        }
        return usedCodes;
    }

    public static GlobalPos deserializeGlobalPos(String str) {
        try {
            String[] parts = str.split(":");
            if (parts.length != 3) {
                return null;
            }
            ResourceLocation dimensionId = ResourceLocation.fromNamespaceAndPath(parts[0], parts[1]);
            String[] coords = parts[2].split(",");
            if (coords.length != 3) {
                return null;
            }
            int x = Integer.parseInt(coords[0]);
            int y = Integer.parseInt(coords[1]);
            int z = Integer.parseInt(coords[2]);
            ResourceKey<Level> dimension = ResourceKey.create(Registries.DIMENSION, dimensionId);
            return GlobalPos.of(dimension, new BlockPos(x, y, z));
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static MutableComponent formatMessage(String message) {
        Style grayBoldStyle = Style.EMPTY.applyFormats(new ChatFormatting[]{ChatFormatting.BOLD, ChatFormatting.DARK_GRAY});
        Style greenStyle = Style.EMPTY.applyFormats(new ChatFormatting[]{ChatFormatting.GREEN});
        MutableComponent prefix = Component.literal("[").withStyle(new ChatFormatting[]{ChatFormatting.BOLD, ChatFormatting.DARK_GRAY});
        MutableComponent restOfPrefix = Component.literal("HEssentials").withStyle(greenStyle);
        MutableComponent endOfPrefix = Component.literal("]").withStyle(grayBoldStyle);
        MutableComponent resetComponent = Component.literal("").withStyle(ChatFormatting.RESET);
        Style style = Style.EMPTY.withColor(ChatFormatting.GREEN).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal("Henny Essentials Mod").withStyle(ChatFormatting.GREEN)));
        Component.literal("").append(prefix).append(resetComponent).withStyle(ChatFormatting.RESET).append(restOfPrefix).append(endOfPrefix).withStyle(style);
        Component.literal("");
        MutableComponent prefixComp = Component.literal("");
        if (!ConfigManager.CONFIG.modMessagePrefix.isBlank()) {
            MutableComponent idk = Component.literal(ConfigManager.CONFIG.modMessagePrefix);
            Style style2 = idk.getStyle();
            prefixComp = Component.literal("").append(idk.withStyle(style2.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal("Henny Essentials Mod").withStyle(ChatFormatting.GREEN)))));
        }
        if (!ConfigManager.CONFIG.modMessagePrefix.isBlank()) {
            Component.literal("").append(prefixComp).append(Component.literal(" " + message).withStyle(ChatFormatting.GREEN));
        } else {
            Component.literal("").append(Component.literal(message).withStyle(ChatFormatting.GREEN));
        }
        return Component.literal("").append(prefixComp).append(Component.literal(message).withStyle(ChatFormatting.GREEN));
    }

    public static MutableComponent formatAndHighlight(String message) {
        Style grayBoldStyle = Style.EMPTY.applyFormats(new ChatFormatting[]{ChatFormatting.BOLD, ChatFormatting.DARK_GRAY});
        Style greenStyle = Style.EMPTY.applyFormats(new ChatFormatting[]{ChatFormatting.GREEN});
        Component.literal("[").withStyle(new ChatFormatting[]{ChatFormatting.BOLD, ChatFormatting.DARK_GRAY});
        Component.literal("HEssentials").withStyle(greenStyle);
        Component.literal("]").withStyle(grayBoldStyle);
        MutableComponent resetComponent = Component.literal("").withStyle(ChatFormatting.RESET);
        Style.EMPTY.withColor(ChatFormatting.GREEN).withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal("Henny Essentials Mod").withStyle(ChatFormatting.GREEN)));
        MutableComponent prefixComp = Component.literal("");
        if (!ConfigManager.CONFIG.modMessagePrefix.isBlank()) {
            MutableComponent idk = Component.literal(ConfigManager.CONFIG.modMessagePrefix);
            Style style2 = idk.getStyle();
            prefixComp = Component.literal("").append(idk.withStyle(style2.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal("Henny Essentials Mod").withStyle(ChatFormatting.GREEN)))));
        }
        MutableComponent result = Component.literal("").append(prefixComp).append(resetComponent);
        int i = 0;
        while (true) {
            int index = i;
            if (index >= message.length()) {
                break;
            }
            int start = message.indexOf(91, index);
            if (start == -1) {
                result.append(Component.literal(message.substring(index)).withStyle(ChatFormatting.GREEN));
                break;
            }
            if (start > index) {
                result.append(Component.literal(message.substring(index, start)).withStyle(ChatFormatting.GREEN));
            }
            int end = message.indexOf(93, start);
            if (end == -1) {
                result.append(Component.literal(message.substring(start)).withStyle(ChatFormatting.GREEN));
                break;
            }
            String inside = message.substring(start + 1, end);
            result.append(Component.literal("[" + inside + "]").withStyle(ChatFormatting.GOLD));
            i = end + 1;
        }
        return result;
    }

    public static MutableComponent getModPrefix() {
        MutableComponent prefixComp = Component.literal("");
        if (!ConfigManager.CONFIG.modMessagePrefix.isBlank()) {
            MutableComponent idk = Component.literal(ConfigManager.CONFIG.modMessagePrefix);
            Style style = idk.getStyle();
            prefixComp = Component.literal("").append(idk.withStyle(style.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal("Henny Essentials Mod").withStyle(ChatFormatting.GREEN)))));
        }
        return prefixComp;
    }

    public static MutableComponent formatMessageWithHighlight(String prefixStr, String highlight, String suffixStr) {
        Style grayBoldStyle = Style.EMPTY.applyFormats(new ChatFormatting[]{ChatFormatting.BOLD, ChatFormatting.DARK_GRAY});
        Style greenStyle = Style.EMPTY.applyFormats(new ChatFormatting[]{ChatFormatting.GREEN});
        Component.literal("[").withStyle(new ChatFormatting[]{ChatFormatting.BOLD, ChatFormatting.DARK_GRAY});
        Component.literal("HEssentials").withStyle(greenStyle);
        Component.literal("]").withStyle(grayBoldStyle);
        MutableComponent resetComponent = Component.literal("").withStyle(ChatFormatting.RESET);
        MutableComponent prefixComp = Component.literal("");
        if (!ConfigManager.CONFIG.modMessagePrefix.isBlank()) {
            MutableComponent idk = Component.literal(ConfigManager.CONFIG.modMessagePrefix);
            Style style = idk.getStyle();
            prefixComp = Component.literal("").append(idk.withStyle(style.withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Component.literal("Henny Essentials Mod").withStyle(ChatFormatting.GREEN)))));
        }
        return Component.literal("").append(prefixComp).append(resetComponent).withStyle(ChatFormatting.RESET).append(resetComponent).append(Component.literal(prefixStr).append(Component.literal(highlight).withStyle(ChatFormatting.GOLD)).append(resetComponent).append(Component.literal(suffixStr).withStyle(ChatFormatting.GREEN)).withStyle(ChatFormatting.GREEN));
    }

    public static boolean canBeParsed(String input) {
        Matcher matcher = pattern.matcher(input);
        return matcher.find();
    }

    public static void sendParseError(CommandSourceStack src, String duration) {
        src.sendSystemMessage(formatMessageWithHighlight("Could not find a valid time format in string: ", duration, "."));
        src.sendSystemMessage(formatMessage("Valid time format examples:"));
        src.sendSystemMessage(formatMessage("1M1W1D = 1 Month + 1 Week + 1 Day"));
        src.sendSystemMessage(formatMessage("5m = 5 minutes"));
    }

    public static String parseToISO8601(String input) {
        int value;
        String unit;
        Matcher matcher = pattern.matcher(input);
        if (!canBeParsed(input)) {
            throw new IllegalArgumentException("Invalid input format: " + input);
        }
        StringBuilder duration = new StringBuilder("P");
        boolean hasTime = false;
        while (matcher.find()) {
            value = Integer.parseInt(matcher.group(1));
            unit = matcher.group(2);
            switch (unit) {
                case "Y":
                    duration.append(value).append("Y");
                    break;
                case "M":
                    duration.append(value).append("M");
                    break;
                case "W":
                    duration.append(value).append("W");
                    break;
                case "D":
                    duration.append(value).append("D");
                    break;
                case "m":
                case "s":
                    if (!hasTime) {
                        duration.append("T");
                        hasTime = true;
                    }
                    if (unit.equals("m")) {
                        duration.append(value).append("M");
                        break;
                    } else {
                        duration.append(value).append("S");
                        break;
                    }
                    break;
            }
        }
        return duration.toString();
    }
}
