package com.henny.hennyessentials.mixin.vanishmixins;

import com.henny.hennyessentials.CommonClass;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.sensing.Sensor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({Sensor.class})
public class CommonSensorMixin {
    @Inject(method = {"isEntityTargetable"}, at = {@At("HEAD")}, cancellable = true)
    private static void onIsEntityTargetable(LivingEntity pLivingEntity, LivingEntity pTarget, CallbackInfoReturnable<Boolean> cir) {
        if (pTarget instanceof ServerPlayer) {
            ServerPlayer player = (ServerPlayer) pTarget;
            if (CommonClass.playersInVanish.getOrDefault(player.getUUID(), false).booleanValue()) {
                cir.setReturnValue(false);
            }
        }
    }
}
