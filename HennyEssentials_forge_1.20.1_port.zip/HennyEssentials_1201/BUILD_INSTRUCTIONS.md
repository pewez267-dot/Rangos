# Henny Essentials — Ported to Forge 1.20.1

## Cambios realizados del port (1.21.1 → 1.20.1)

### Problema raíz
Minecraft 1.20.5 introdujo el sistema `DataComponents` para items (reemplazando el viejo sistema NBT).
Tu mod usaba ese sistema nuevo, que no existe en 1.20.1. Se convirtió todo de vuelta al API legacy.

### Archivos modificados

| Archivo | Cambio |
|---|---|
| `HennyEssentials.java` | `TickEvent.ServerTickEvent.getServer()` → `CommonClass.minecraftServer` |
| `CommonClass.java` | `DataComponents.CUSTOM_DATA` / `CustomData` → `ItemStack.getTag()` / `setTag()` |
| `CommandToken.java` | `DataComponents.ITEM_NAME` / `LORE` / `ItemLore` → `setHoverName()` + NBT lore |
| `PlayerCommands.java` | `DataComponents.DAMAGE` → `isDamageableItem()` / `setDamageValue(0)` |
| `KitsMenu.java` | `DataComponents.CUSTOM_NAME/DATA` / `CustomData` → `setHoverName()` / `setTag()` |
| `WarpsMenu.java` | Igual que KitsMenu |
| `KitCommands.java` | `ResolvableProfile` + `DataComponents.PROFILE` → `SkullOwner` NBT (1.20.1) |
| `mods.toml` | `loaderVersion "[51,)"` → `"[47,)"`, Forge `"[52,)"` → `"[47.2.0,)"`, MC `[1.21,1.22)` → `[1.20.1,1.21)` |
| `hennyessentials.mixins.json` | `compatibilityLevel: JAVA_18` → `JAVA_17` |
| `hennyessentials.forge.mixins.json` | `compatibilityLevel: JAVA_18` → `JAVA_17` |
| `pack.mcmeta` | `pack_format 18` → `15` (1.20.1) |
| `build.gradle` | Forge `1.20.1-47.3.0`, Java 17 toolchain |

---

## Cómo compilar

### Requisitos
- **Java 17** (obligatorio — Forge 1.20.1 no soporta Java 21)
  - Descargá desde: https://adoptium.net/temurin/releases/?version=17
- **Git** (opcional, solo si clonás)

### Pasos

1. **Descomprimí** este ZIP en una carpeta, por ejemplo `HennyEssentials_1201/`

2. **Verificá que usás Java 17**:
   ```bash
   java -version
   # Debe decir: openjdk version "17.x.x"
   ```
   Si tenés múltiples Java, en Windows podés setear:
   ```cmd
   set JAVA_HOME=C:\Program Files\Eclipse Adoptium\jdk-17.0.x.x-hotspot
   ```
   En Linux/Mac:
   ```bash
   export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
   ```

3. **Descargá el Forge 1.20.1 MDK** (solo necesitás el `build.gradle` del MDK para setup, no el MDK completo — el nuestro ya está configurado):
   - El primer build descargará todo automáticamente vía Gradle.

4. **Compilá**:
   ```bash
   # Linux / Mac
   chmod +x gradlew
   ./gradlew build

   # Windows
   gradlew.bat build
   ```

5. El JAR del mod estará en: `build/libs/HennyEssentials-forge-1.20.1-1.0.4-H3.jar`

### Solución de problemas

**Error: `Unsupported class file major version`**
→ Estás usando Java 21. Cambiá a Java 17.

**Error: `Could not resolve net.minecraftforge:forge:1.20.1-47.3.0`**
→ Problemas de red o proxy. Verificá conexión a internet. Forge descarga unos 2 GB la primera vez.

**Error en mixins / refmap**
→ Si aparece error de refmap, probá: `./gradlew --rerun-tasks build`

**`LuckPerms API` no encontrado**
→ Es `compileOnly` (opcional). Si falla, comentá la línea `compileOnly 'net.luckperms:api:5.4'` en `build.gradle`.

---

## Dependencias de tiempo de ejecución (servidor)

Poné en la carpeta `mods/` de tu servidor 1.20.1:
- `HennyEssentials-forge-1.20.1-1.0.4-H3.jar` (el JAR compilado)
- Forge 1.20.1-47.3.0 instalado en el servidor
- LuckPerms para Forge 1.20.1 (opcional)
