// 
// Decompiled by Procyon v0.6.0
// 

package com.fscrates.block;

import net.minecraft.nbt.ListTag;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundSource;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.RandomSource;
import org.joml.Vector3f;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.world.level.Level;
import com.fscrates.config.ParticleLayer;
import java.util.Iterator;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import com.fscrates.config.Rarity;
import java.util.ArrayList;
import com.fscrates.animation.AnimationRegistry;
import com.fscrates.registry.ModRegistry;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.BlockPos;
import java.util.List;
import net.minecraft.world.item.ItemStack;
import com.fscrates.animation.CrateAnimation;
import com.fscrates.config.CrateConfig;
import net.minecraft.world.level.block.entity.BlockEntity;

public class CrateBlockEntity extends BlockEntity
{
    private CrateConfig config;
    public static final float P_ANTICIPATION_END = 0.1f;
    public static final float P_OPEN_END = 0.22f;
    /**
     * Fraccion de la duracion BASE de la animacion en la que la ruleta se detiene
     * en el premio. Es el instante EXACTO en que el servidor entrega la recompensa
     * (CrateOpeningService usa esta misma constante), de modo que ruleta + sonido +
     * entrega quedan sincronizados. El "hold" (mostrar el item) y el cierre de la
     * tapa son ticks EXTRA que se anaden DESPUES (solo cosmeticos, cliente).
     */
    public static final float P_REVEAL_END = 0.90f;
    /**
     * Pasos (items) FIJOS que recorre la ruleta antes de parar, INDEPENDIENTE del
     * tamano del pool. Asi la velocidad visual (items que cruzan el centro por
     * segundo) es la MISMA con pocos o muchos items. Antes se usaba n*loops, que
     * hacia la ruleta mas rapida cuando habia mas items.
     */
    public static final int REEL_STEPS = 130;
    // ---- Tiempos EXTRA (en ticks; 20 ticks = 1 segundo) que se anaden DESPUES de
    // que la ruleta para. Son puramente cosmeticos en el cliente. ----
    private static final int OPEN_TICKS = 16;   // lo que tarda la tapa en abrirse (mas peso al destapar)
    private static final int HOLD_TICKS = 70;   // ~3.5s mostrando el item ganado
    private static final int CLOSE_TICKS = 26;  // ~1.3s cerrando (el item se mete despacio)
    // Fraccion del base que dura el ESPIRAL/anticipacion ANTES de abrir la tapa.
    // ALARGADO: hay tiempo de sobra para que el "reloj" suba acelerando hasta la nota
    // mas aguda y se oiga BIEN, COMPLETA, antes del estallido.
    private static final float SPIRAL_FRAC = 0.64f; // % del base para el espiral epico (mas anticipacion)
    private static final int SPIRAL_MIN_TICKS = 130; // minimo ~6.5s de build-up en cada cofre
    // VENTANA DE RESONANCIA: ticks finales del espiral en los que el "reloj" YA llego
    // a su nota mas aguda y la DEJA SONAR (sin abrir la tapa todavia). Esto evita que
    // el estallido pise/corte la nota aguda: primero se oye COMPLETA y luego abre.
    private static final int PEAK_HOLD_TICKS = 18; // ~0.9s para que la nota aguda resuene
    public boolean animating;
    public int animTick;
    public int animTotal;
    // Umbrales ABSOLUTOS de la linea de tiempo (calculados en startAnimation):
    //   0 .. tSpiralEnd   -> ESPIRAL epico (tapa cerrada, el cofre "carga")
    //   tSpiralEnd .. tOpenEnd -> la tapa se ABRE
    //   tOpenEnd .. tSpinStop  -> gira la RULETA y para en el premio
    //   tSpinStop .. tHoldEnd  -> HOLD: se muestra el item (2.5-3s)
    //   tHoldEnd .. animTotal  -> la tapa se CIERRA (con sonido/particulas)
    private int tSpiralEnd;
    private int tOpenEnd;
    private int tSpinStop;
    private int tHoldEnd;
    // Instante en que el "reloj" alcanza su nota mas aguda. Es ANTES de tSpiralEnd
    // (por PEAK_HOLD_TICKS) para que la nota suene completa antes de abrir la tapa.
    private int tRiseEnd;
    private boolean peakPlayed;
    private boolean instant;
    private CrateAnimation animation;
    private int animColor;
    private ItemStack rewardIcon;
    private final List<ItemStack> candidates;
    private int winnerIndex;
    private Rarity effectRarity;
    private int[] candidateRarities;
    private int soundStage;
    private int winTick;
    private int noteIndex;
    private int lastReelIndex;
    private int lastRiseTick;
    public float ambientTime;
    
    public CrateBlockEntity(final BlockPos pos, final BlockState state) {
        super((BlockEntityType)ModRegistry.CRATE_BE.get(), pos, state);
        this.config = new CrateConfig();
        this.animating = false;
        this.animTick = 0;
        this.animTotal = 150;
        this.tSpiralEnd = 0;
        this.tOpenEnd = 0;
        this.tSpinStop = 0;
        this.tHoldEnd = 0;
        this.tRiseEnd = 0;
        this.peakPlayed = false;
        this.instant = false;
        this.animation = AnimationRegistry.get(AnimationRegistry.defaultId());
        this.animColor = 16777215;
        this.rewardIcon = ItemStack.EMPTY;
        this.candidates = new ArrayList<ItemStack>();
        this.winnerIndex = 0;
        this.effectRarity = Rarity.COMMON;
        this.candidateRarities = new int[0];
        this.soundStage = 0;
        this.winTick = -1;
        this.noteIndex = 0;
        this.lastReelIndex = -1;
        this.lastRiseTick = -100;
        this.ambientTime = 0.0f;
    }
    
    public CrateConfig getConfig() {
        return this.config;
    }
    
    public void setConfig(final CrateConfig config) {
        this.config = ((config == null) ? new CrateConfig() : config);
        this.animColor = this.config.rarity.rgb();
        this.setChanged();
        if (this.level != null && !this.level.isClientSide) {
            this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), 3);
        }
    }
    
    public Rarity getRarity() {
        return this.config.rarity;
    }
    
    public CrateAnimation getAnimation() {
        return this.animation;
    }
    
    public int getAnimColor() {
        return this.animColor;
    }
    
    public ItemStack getRewardIcon() {
        return this.rewardIcon;
    }
    
    public List<ItemStack> getCandidates() {
        return this.candidates;
    }
    
    public int getWinnerIndex() {
        return this.winnerIndex;
    }

    /** Rareza EFECTIVA del premio ganador (define luz, sonido y particulas). */
    public Rarity getEffectRarity() {
        return this.effectRarity;
    }

    /** Rareza (ordinal) de cada item del carrusel, para colorear el haz segun el
     *  item que va pasando por el centro. */
    public int[] getCandidateRarities() {
        return this.candidateRarities;
    }

    /** Lee el array de rarezas de los candidatos del NBT de candidatos. */
    public static int[] decodeRarities(final CompoundTag wrap) {
        if (wrap == null || !wrap.contains("rar")) {
            return new int[0];
        }
        return wrap.getIntArray("rar");
    }
    
    public void startAnimation(final String animationId, final int rarityColor, final int winnerIndex, final int winnerRarity, final int[] candRarities, final List<ItemStack> cands) {
        this.animation = AnimationRegistry.get(animationId);
        final int base = Math.max(6, this.animation.durationTicks());
        this.instant = (this.animation.style() == CrateAnimation.Style.INSTANT);
        if (this.instant) {
            // Modo instantaneo: sin la coreografia (espiral/apertura/hold/cierre).
            this.tSpiralEnd = 0;
            this.tOpenEnd = 0;
            this.tSpinStop = 0;
            this.tHoldEnd = 0;
            this.tRiseEnd = 0;
            this.animTotal = base;
        }
        else {
            // La ruleta para (y el servidor entrega el premio) en base*P_REVEAL_END.
            this.tSpinStop = Math.round(base * P_REVEAL_END);
            this.tSpiralEnd = Math.max(SPIRAL_MIN_TICKS, Math.round(base * SPIRAL_FRAC));
            this.tOpenEnd = this.tSpiralEnd + OPEN_TICKS;
            // Salvaguarda: que siempre quede ventana de ruleta entre abrir y parar.
            if (this.tOpenEnd >= this.tSpinStop - 4) {
                this.tOpenEnd = Math.max(this.tSpiralEnd + 2, this.tSpinStop - 6);
            }
            // El "reloj" llega a su nota mas aguda PEAK_HOLD_TICKS antes de abrir la
            // tapa, asi la nota suena COMPLETA y resuena antes del estallido.
            this.tRiseEnd = Math.max(4, this.tSpiralEnd - PEAK_HOLD_TICKS);
            // HOLD (mostrar el item) + CIERRE de la tapa: ticks EXTRA cosmeticos.
            this.tHoldEnd = this.tSpinStop + HOLD_TICKS;
            this.animTotal = this.tHoldEnd + CLOSE_TICKS;
        }
        this.animColor = rarityColor;
        final Rarity[] rv = Rarity.values();
        this.effectRarity = rv[Math.max(0, Math.min(rv.length - 1, winnerRarity))];
        this.candidateRarities = (candRarities == null) ? new int[0] : candRarities;
        this.candidates.clear();
        if (cands != null) {
            for (final ItemStack s : cands) {
                if (s != null && !s.isEmpty()) {
                    this.candidates.add(s);
                }
            }
        }
        this.winnerIndex = (this.candidates.isEmpty() ? 0 : Math.max(0, Math.min(this.candidates.size() - 1, winnerIndex)));
        this.rewardIcon = (this.candidates.isEmpty() ? ItemStack.EMPTY : this.candidates.get(this.winnerIndex));
        this.animTick = 0;
        this.soundStage = 0;
        this.winTick = -1;
        this.noteIndex = 0;
        this.lastReelIndex = -1;
        this.lastRiseTick = -100;
        this.peakPlayed = false;
        this.animating = true;
        if (this.level != null) {
            // Sonido de apertura/desbloqueo PROPIO de cada cofre segun su tier.
            this.playUnlock(this.config.rarity);
        }
    }
    
    public float progress() {
        return this.animating ? Math.min(1.0f, this.animTick / (float)Math.max(1, this.animTotal)) : 0.0f;
    }

    // --- Getters de la linea de tiempo (los usa el renderer para sincronizar) ---
    public int getSpiralEndTick() {
        return this.tSpiralEnd;
    }

    public int getOpenEndTick() {
        return this.tOpenEnd;
    }

    public int getSpinStopTick() {
        return this.tSpinStop;
    }

    public int getHoldEndTick() {
        return this.tHoldEnd;
    }

    public boolean isInstant() {
        return this.instant;
    }
    
    public ParticleLayer.Phase currentPhase() {
        if (!this.animating) {
            return ParticleLayer.Phase.IDLE;
        }
        if (this.instant) {
            return ParticleLayer.Phase.REVEAL;
        }
        final int t = this.animTick;
        if (t < this.tSpiralEnd) {
            return ParticleLayer.Phase.ANTICIPATION;
        }
        if (t < this.tOpenEnd) {
            return ParticleLayer.Phase.OPEN;
        }
        if (t < this.tSpinStop) {
            return ParticleLayer.Phase.REVEAL;
        }
        return ParticleLayer.Phase.FINALE; // hold + cierre
    }
    
    public float lidOpen(final float partial) {
        if (!this.animating) {
            return 0.0f;
        }
        if (this.instant) {
            return 1.0f;
        }
        final float t = this.animTick + partial;
        if (t <= this.tSpiralEnd) {
            return 0.0f; // cerrada durante el espiral epico
        }
        if (t < this.tOpenEnd) {
            return easeOutBack((t - this.tSpiralEnd) / Math.max(1.0f, this.tOpenEnd - this.tSpiralEnd));
        }
        if (t < this.tHoldEnd) {
            return 1.0f; // abierta: ruleta + hold (mostrando el item)
        }
        if (t < this.animTotal) {
            return 1.0f - easeInOut(Math.min(1.0f, (t - this.tHoldEnd) / Math.max(1.0f, this.animTotal - this.tHoldEnd)));
        }
        return 0.0f;
    }
    
    public float shake(final float partial) {
        if (!this.animating || this.instant) {
            return 0.0f;
        }
        final float t = this.animTick + partial;
        if (t >= this.tSpiralEnd) {
            return 0.0f;
        }
        final float intensity = (this.tSpiralEnd - t) / Math.max(1.0f, this.tSpiralEnd);
        return (float)Math.sin(t * 2.4f) * 0.06f * intensity;
    }
    
    public float revealProgress(final float partial) {
        if (this.instant) {
            return 1.0f;
        }
        final float t = this.animTick + partial;
        if (t <= this.tOpenEnd) {
            return 0.0f;
        }
        if (t >= this.tSpinStop) {
            return 1.0f;
        }
        return (t - this.tOpenEnd) / Math.max(1.0f, this.tSpinStop - this.tOpenEnd);
    }
    
    public float finaleProgress(final float partial) {
        if (this.instant) {
            return 1.0f;
        }
        final float t = this.animTick + partial;
        if (t <= this.tSpinStop) {
            return 0.0f;
        }
        return Math.min(1.0f, (t - this.tSpinStop) / 14.0f);
    }

    /** Progreso del CIERRE de la tapa (0 mientras se muestra el item, 1 al final).
     *  Lo usa el renderer para "retraer" el item dentro del cofre al cerrarse. */
    public float closeProgress(final float partial) {
        if (!this.animating || this.instant) {
            return 0.0f;
        }
        final float t = this.animTick + partial;
        if (t <= this.tHoldEnd) {
            return 0.0f;
        }
        if (t >= this.animTotal) {
            return 1.0f;
        }
        return (t - this.tHoldEnd) / Math.max(1.0f, this.animTotal - this.tHoldEnd);
    }
    
    public static void clientTick(final Level level, final BlockPos pos, final BlockState state, final CrateBlockEntity be) {
        ++be.ambientTime;
        if (be.animating) {
            ++be.animTick;
            be.emitLayers(level, pos, be.currentPhase());
            be.emitAccent(level, pos);
            be.emitBuildupSpiral(level, pos);
            be.emitSpiralBurst(level, pos);
            be.advanceSounds();
            if (be.animTick >= be.animTotal) {
                be.animating = false;
                be.animTick = 0;
                be.rewardIcon = ItemStack.EMPTY;
                be.candidates.clear();
                // Restaura el color de la crate para las particulas de reposo.
                be.animColor = be.config.rarity.rgb();
                be.effectRarity = be.config.rarity;
            }
        }
        else if (be.config.particles) {
            be.emitLayers(level, pos, ParticleLayer.Phase.IDLE);
        }
    }
    
    private void emitLayers(final Level level, final BlockPos pos, final ParticleLayer.Phase phase) {
        for (final ParticleLayer layer : this.config.particleLayers) {
            if (layer.phase != phase) {
                continue;
            }
            if (phase == ParticleLayer.Phase.IDLE && level.getGameTime() % Math.max(1, layer.interval) != 0L) {
                continue;
            }
            final ParticleOptions opt = this.resolve(layer);
            if (opt == null) {
                continue;
            }
            this.emitShape(level, pos, layer, opt);
        }
    }
    
    private ParticleOptions resolve(final ParticleLayer layer) {
        final String id = (layer.particleId == null) ? "" : layer.particleId.trim();
        if (id.equals("minecraft:dust") || id.equals("dust")) {
            final int color = layer.useRarityColor ? this.animColor : parseHex(layer.colorHex, this.animColor);
            return (ParticleOptions)this.dust(color, 1.4f);
        }
        final ResourceLocation rl = ResourceLocation.tryParse(id);
        if (rl == null) {
            return null;
        }
        final ParticleType<?> type = (ParticleType<?>)ForgeRegistries.PARTICLE_TYPES.getValue(rl);
        SimpleParticleType simpleParticleType;
        if (type instanceof final SimpleParticleType simpleParticleType2) {
            final SimpleParticleType simple = simpleParticleType = simpleParticleType2;
        }
        else {
            simpleParticleType = null;
        }
        return (ParticleOptions)simpleParticleType;
    }
    
    private DustParticleOptions dust(final int color, final float scale) {
        return new DustParticleOptions(new Vector3f((color >> 16 & 0xFF) / 255.0f, (color >> 8 & 0xFF) / 255.0f, (color & 0xFF) / 255.0f), scale);
    }

    /** Factor de densidad de particulas por rareza. La caja comun reduce la cantidad
     *  para que no se "abulten" demasiado (es pequena); el resto queda igual. */
    private double particleDensity() {
        return (this.config.rarity == Rarity.COMMON) ? 0.55 : 1.0;
    }
    
    private void emitShape(final Level level, final BlockPos pos, final ParticleLayer layer, final ParticleOptions opt) {
        // Las particulas deben quedar PEGADAS al cofre. Antes se multiplicaba el
        // radio por el tamano COMPLETO del cofre (sizeScale, hasta 2.6x en legendary)
        // y los anillos/halos quedaban a 2-3 BLOQUES del cofre. Ahora se usa un factor
        // SUAVE: el anillo solo se abre lo justo para rodear el borde del cofre grande.
        final double crateScale = this.config.rarity.sizeScale();
        final double scale = 1.0 + (crateScale - 1.0) * 0.22; // pegado al cofre
        final double cx = pos.getX() + 0.5;
        final double cy = pos.getY() + Math.max(0.0, layer.yOffset) * scale;
        final double cz = pos.getZ() + 0.5;
        final RandomSource rng = level.random;
        // La caja COMUN es pequena y sus particulas se "abultaban": reducimos su
        // densidad (cantidad) para que se vean mas limpias. El resto no cambia.
        final int n = Math.max(1, (int)Math.round(Math.max(1, layer.count) * this.particleDensity()));
        final double r = layer.radius * scale;       // radio escalado al cofre
        final double sp = layer.speed;
        final double spread = layer.spread * scale;   // dispersion escalada al cofre
        final double t = this.ambientTime * 0.1;
        for (int i = 0; i < n; ++i) {
            switch (layer.shape) {
                case HALO: {
                    final double angle = t + i * (6.283185307179586 / n);
                    level.addParticle(opt, cx + Math.cos(angle) * r, cy + 0.05 * scale * Math.sin(t * 1.7 + i), cz + Math.sin(angle) * r, -Math.sin(angle) * sp, sp * 0.4, Math.cos(angle) * sp);
                    break;
                }
                case RING: {
                    final double angle = i * (6.283185307179586 / n);
                    level.addParticle(opt, cx + Math.cos(angle) * r, cy, cz + Math.sin(angle) * r, Math.cos(angle) * sp, 0.0, Math.sin(angle) * sp);
                    break;
                }
                case BURST: {
                    final double ax = (rng.nextDouble() - 0.5) * 2.0;
                    final double az = (rng.nextDouble() - 0.5) * 2.0;
                    final double ay = 0.4 + rng.nextDouble() * 0.6;
                    final double mag = Math.max(0.001, Math.sqrt(ax * ax + ay * ay + az * az));
                    level.addParticle(opt, cx, cy, cz, ax / mag * (sp + spread), ay / mag * (sp + spread), az / mag * (sp + spread));
                    break;
                }
                case COLUMN: {
                    level.addParticle(opt, cx + (rng.nextDouble() - 0.5) * spread, cy + rng.nextDouble() * (0.4 * scale + r), cz + (rng.nextDouble() - 0.5) * spread, 0.0, sp, 0.0);
                    break;
                }
                case SPIRAL: {
                    // Helice que ENVUELVE el cofre (radio = tamano del cofre) y SUBE,
                    // cerrandose un poco al ascender. Gira con el tiempo -> torbellino.
                    final double tt = this.ambientTime * 0.18;
                    final double frac = ((i + (int)(this.ambientTime % 3)) % n) / (double)n; // reparte la altura
                    final double ang = tt + frac * 12.566370614359172;   // 2 vueltas completas
                    final double rr = r * (1.05 - frac * 0.4);            // se cierra al subir
                    level.addParticle(opt, cx + Math.cos(ang) * rr, cy + frac * 1.5 * scale, cz + Math.sin(ang) * rr, -Math.sin(ang) * sp, sp + 0.02, Math.cos(ang) * sp);
                    break;
                }
                case FOUNTAIN: {
                    final double angle = rng.nextDouble() * 3.141592653589793 * 2.0;
                    level.addParticle(opt, cx, cy, cz, Math.cos(angle) * spread, sp + rng.nextDouble() * 0.15, Math.sin(angle) * spread);
                    break;
                }
                case VORTEX: {
                    final double angle = t * 4.0 + i * (6.283185307179586 / n);
                    final double rr2 = r * (0.6 + 0.4 * Math.sin(t * 2.0 + i));
                    level.addParticle(opt, cx + Math.cos(angle) * rr2, cy + rng.nextDouble() * 0.5 * scale, cz + Math.sin(angle) * rr2, -Math.cos(angle) * sp * 2.0, sp, -Math.sin(angle) * sp * 2.0);
                    break;
                }
                case RAIN: {
                    level.addParticle(opt, cx + (rng.nextDouble() - 0.5) * (spread + r * 2.0), cy + rng.nextDouble() * 0.5 * scale, cz + (rng.nextDouble() - 0.5) * (spread + r * 2.0), 0.0, -sp, 0.0);
                    break;
                }
                case POINT: {
                    level.addParticle(opt, cx, cy, cz, (rng.nextDouble() - 0.5) * sp, rng.nextDouble() * sp, (rng.nextDouble() - 0.5) * sp);
                    break;
                }
            }
        }
    }
    
    private void emitAccent(final Level level, final BlockPos pos) {
        if (this.instant) {
            return;
        }
        final int t = this.animTick;
        final double cx = pos.getX() + 0.5;
        final double cz = pos.getZ() + 0.5;
        final double cyTop = pos.getY() + 1.5;
        final RandomSource rng = level.random;
        // Aura ambiental segun el TEMA de la animacion: BAJA y alrededor del cofre,
        // SOLO mientras gira la ruleta (no tapa el carrusel que esta a y~1.5).
        if (t >= this.tOpenEnd && t < this.tSpinStop && t % 3 == 0) {
            final ParticleOptions amb = this.themeParticle(this.animation.theme());
            final double ang = rng.nextDouble() * 6.283185307179586;
            final double rad = 0.5 + rng.nextDouble() * 0.2;
            level.addParticle(amb, cx + Math.cos(ang) * rad, pos.getY() + 0.2 + rng.nextDouble() * 0.5, cz + Math.sin(ang) * rad, 0.0, 0.02 + rng.nextDouble() * 0.03, 0.0);
        }
        // CELEBRACION en el HOLD (cuando se revela el item) segun la RAREZA ganada:
        // un estallido fuerte al revelar y luego un goteo suave mientras se muestra.
        if (t >= this.tSpinStop && t < this.tHoldEnd && t % 2 == 0) {
            final ParticleOptions fin = this.finaleParticle(this.effectRarity);
            final int burst = (t < this.tSpinStop + 12) ? 6 : 2; // mas intenso al revelar
            for (int i = 0; i < burst; ++i) {
                final double a2 = rng.nextDouble() * 6.283185307179586;
                final double s = 0.2 + rng.nextDouble() * 0.5;
                level.addParticle(fin, cx, cyTop, cz, Math.cos(a2) * s, 0.15 + rng.nextDouble() * 0.3, Math.sin(a2) * s);
            }
            for (int i = 0; i < 3; ++i) {
                final double a3 = rng.nextDouble() * 6.283185307179586;
                final double s2 = 0.15 + rng.nextDouble() * 0.35;
                level.addParticle((ParticleOptions)this.dust(this.animColor, 1.5f), cx, cyTop, cz, Math.cos(a3) * s2, 0.1 + rng.nextDouble() * 0.2, Math.sin(a3) * s2);
            }
        }
        // Puff de CIERRE: al cerrarse la tapa, particulas que bajan hacia el cofre
        // (como si el premio se guardara dentro).
        if (t >= this.tHoldEnd && t < this.animTotal && t % 2 == 0) {
            final double a = rng.nextDouble() * 6.283185307179586;
            final double rad = 0.2 + rng.nextDouble() * 0.25;
            level.addParticle((ParticleOptions)this.dust(this.config.rarity.rgb(), 1.2f), cx + Math.cos(a) * rad, cyTop - 0.2, cz + Math.sin(a) * rad, 0.0, -0.06, 0.0);
        }
    }

    /** Particula de FINALE segun la rareza del premio (escala de "epicidad"). */
    private ParticleOptions finaleParticle(final Rarity r) {
        return switch (r) {
            case COMMON -> (ParticleOptions)ParticleTypes.END_ROD;
            case RARE -> (ParticleOptions)ParticleTypes.GLOW;
            case EPIC -> (ParticleOptions)ParticleTypes.WITCH;
            case LEGENDARY -> (ParticleOptions)ParticleTypes.FIREWORK;
            case MYTHIC -> (ParticleOptions)ParticleTypes.FLAME;
            default -> (ParticleOptions)ParticleTypes.FIREWORK;
        };
    }

    /**
     * ACENTO de transicion: un anillo de ESTALLIDO que rodea el cofre justo cuando
     * el espiral termina y la tapa va a abrirse (un "pop" sincronizado con el tiempo).
     *
     * El espiral CONTINUO ya NO esta hardcodeado: ahora es una CAPA de particulas
     * EDITABLE (forma "Espiral", fase "Tension") que viene por defecto en cada cofre
     * y envuelve el cofre segun su TAMANO real. El jugador puede editarla/quitarla
     * en la pestana de Particulas. Esto solo aporta el remate final del build-up.
     */
    /**
     * ESPIRAL garantizado del build-up: una helice de varios brazos que SUBE y se
     * cierra alrededor del cofre mientras la tapa esta cerrada (fase de tension).
     * Se emite SIEMPRE (no depende de las capas configurables) para que el espiral
     * sea VISIBLE antes de la apertura. Va de menos a mas (mas brazos/brillo conforme
     * se acerca el estallido) y queda PEGADO al cofre.
     */
    private void emitBuildupSpiral(final Level level, final BlockPos pos) {
        if (this.instant || this.tSpiralEnd <= 1) {
            return;
        }
        final int t = this.animTick;
        if (t <= 0 || t >= this.tSpiralEnd) {
            return;
        }
        final Rarity r = this.config.rarity;
        final double pscale = 1.0 + (r.sizeScale() - 1.0) * 0.22; // pegado al cofre
        final float p = Math.min(1.0f, t / (float)Math.max(1, this.tSpiralEnd));
        final double cx = pos.getX() + 0.5;
        final double cz = pos.getZ() + 0.5;
        final double baseY = pos.getY() + 0.1;
        final DustParticleOptions dust = this.dust(r.rgb(), 1.2f);
        final ParticleOptions spark = this.openingSparkle(r);
        final int arms = (r == Rarity.COMMON)
                ? 1 + Math.round(p * 2)        // comun: menos brazos (1-3) para no abultarse
                : 2 + Math.round(p * 4);       // resto: 2-6 brazos
        final double turns = 2.0 + p * 1.5;            // mas vueltas al final
        final double height = (1.25 + p * 0.45) * pscale;
        final double baseR = 0.55 * pscale;            // hugea el cofre
        final double spin = this.ambientTime * 0.30;   // gira con el tiempo
        final int steps = (r == Rarity.COMMON) ? 2 : 3; // comun: menos particulas por brazo
        for (int a = 0; a < arms; ++a) {
            final double armOff = a * (6.283185307179586 / arms);
            for (int s = 0; s < steps; ++s) {
                final double frac = (s + (this.ambientTime % 4) * 0.25) / steps; // sube 0..1
                final double ang = spin + armOff + frac * turns * 6.283185307179586;
                final double rr = baseR * (1.05 - frac * 0.45);  // se cierra al subir
                final double px = cx + Math.cos(ang) * rr;
                final double pz = cz + Math.sin(ang) * rr;
                final double py = baseY + frac * height;
                final double vTan = 0.04 + p * 0.05;
                level.addParticle((ParticleOptions)dust, px, py, pz, -Math.sin(ang) * vTan, 0.02 + p * 0.03, Math.cos(ang) * vTan);
                if (s == steps - 1 || p > 0.6f) {
                    level.addParticle(spark, px, py, pz, -Math.sin(ang) * vTan * 0.6, 0.03, Math.cos(ang) * vTan * 0.6);
                }
            }
        }
    }

    private void emitSpiralBurst(final Level level, final BlockPos pos) {
        if (this.instant || this.tSpiralEnd <= 1 || this.animTick != this.tSpiralEnd - 1) {
            return;
        }
        final Rarity r = this.config.rarity;
        final int tier = r.ordinal();
        final double scale = 1.0 + (r.sizeScale() - 1.0) * 0.22; // pegado al cofre (no 2-3 bloques)
        final RandomSource rng = level.random;
        final double cx = pos.getX() + 0.5;
        final double cz = pos.getZ() + 0.5;
        final double y = pos.getY() + 0.6 * scale;
        final double rad = 0.5 * scale;        // rodea el cofre REAL (no el bloque)
        final DustParticleOptions dust = this.dust(r.rgb(), 1.4f);
        final ParticleOptions spark = this.openingSparkle(r);
        final float power = 1.0f + tier * 0.35f; // legendary/mythic estallan mas fuerte

        // 1) DESTELLO + puffs de impacto en el centro: el "flash" del estallido.
        level.addParticle((ParticleOptions)ParticleTypes.FLASH, cx, y, cz, 0.0, 0.0, 0.0);
        final int puffs = 2 + tier;
        for (int i = 0; i < puffs; ++i) {
            level.addParticle((ParticleOptions)ParticleTypes.EXPLOSION, cx + (rng.nextDouble() - 0.5) * rad, y + (rng.nextDouble() - 0.5) * 0.3 * scale, cz + (rng.nextDouble() - 0.5) * rad, 0.0, 0.0, 0.0);
        }

        // 2) ANILLO horizontal que se EXPANDE (onda de choque) rodeando el cofre real.
        final int ringN = 20 + tier * 6;
        for (int i = 0; i < ringN; ++i) {
            final double ang = i * (6.283185307179586 / ringN);
            final double px = cx + Math.cos(ang) * rad;
            final double pz = cz + Math.sin(ang) * rad;
            final double v = 0.18 * power;
            level.addParticle((ParticleOptions)dust, px, y, pz, Math.cos(ang) * v, 0.06, Math.sin(ang) * v);
            level.addParticle(spark, px, y, pz, Math.cos(ang) * v * 0.7, 0.08, Math.sin(ang) * v * 0.7);
        }

        // 3) ESFERA de chispas DESPEDIDAS en todas direcciones (sale disparado, con
        // sesgo hacia arriba). Mezcla cohete + chispa del tier + polvo de color.
        final int sphereN = 24 + tier * 10;
        for (int i = 0; i < sphereN; ++i) {
            final double ax = rng.nextDouble() - 0.5;
            final double ay = rng.nextDouble() * 0.9 + 0.1; // sesgo hacia arriba
            final double az = rng.nextDouble() - 0.5;
            final double mag = Math.max(0.001, Math.sqrt(ax * ax + ay * ay + az * az));
            final double sp = (0.25 + rng.nextDouble() * 0.35) * power;
            final ParticleOptions p = (i % 3 == 0) ? (ParticleOptions)ParticleTypes.FIREWORK : ((i % 3 == 1) ? spark : (ParticleOptions)dust);
            level.addParticle(p, cx, y, cz, ax / mag * sp, ay / mag * sp, az / mag * sp);
        }

        // 4) COLUMNA ascendente: chispas que salen DESPEDIDAS hacia arriba del cofre.
        final int upN = 8 + tier * 4;
        for (int i = 0; i < upN; ++i) {
            final double a = rng.nextDouble() * 6.283185307179586;
            final double rr = rng.nextDouble() * rad * 0.6;
            level.addParticle(spark, cx + Math.cos(a) * rr, y, cz + Math.sin(a) * rr, (rng.nextDouble() - 0.5) * 0.06, (0.25 + rng.nextDouble() * 0.4) * power, (rng.nextDouble() - 0.5) * 0.06);
        }
    }

    /** Chispa que acompana la espiral de apertura, segun la rareza del cofre. */
    private ParticleOptions openingSparkle(final Rarity r) {
        return switch (r) {
            case COMMON -> (ParticleOptions)ParticleTypes.END_ROD;
            case RARE -> (ParticleOptions)ParticleTypes.GLOW;
            case EPIC -> (ParticleOptions)ParticleTypes.WITCH;
            case LEGENDARY -> (ParticleOptions)ParticleTypes.ENCHANT;
            case MYTHIC -> (ParticleOptions)ParticleTypes.FLAME;
            default -> (ParticleOptions)ParticleTypes.END_ROD;
        };
    }

    /** Particula ambiental segun el TEMA de la animacion (da identidad a cada una). */
    private ParticleOptions themeParticle(final CrateAnimation.Theme t) {
        return switch (t) {
            case INFERNAL -> (ParticleOptions)ParticleTypes.FLAME;
            case CELESTIAL -> (ParticleOptions)ParticleTypes.END_ROD;
            case NEON -> (ParticleOptions)ParticleTypes.GLOW;
            case MAGIC -> (ParticleOptions)ParticleTypes.WITCH;
            case ANCIENT -> (ParticleOptions)ParticleTypes.ENCHANT;
            case NATURE -> (ParticleOptions)ParticleTypes.HAPPY_VILLAGER;
            case CASINO -> (ParticleOptions)ParticleTypes.FIREWORK;
            default -> (ParticleOptions)this.dust(this.animColor, 1.0f);
        };
    }
    
    private static int parseHex(final String hex, final int fallback) {
        if (hex == null) {
            return fallback;
        }
        try {
            return (int)Long.parseLong(hex.replace("#", "").trim(), 16);
        }
        catch (final NumberFormatException e) {
            return fallback;
        }
    }
    
    private void advanceSounds() {
        if (this.instant) {
            if (this.soundStage < 60) {
                this.playWin(this.effectRarity);
                this.soundStage = 60;
            }
            return;
        }
        final int t = this.animTick;
        final Rarity cr = this.config.rarity;
        // 1) ESPIRAL: "carga" de energia epica al meter la llave (sube el vortice).
        if (this.soundStage == 0 && t >= 2) {
            this.playSpiralCharge(cr);
            this.soundStage = 1;
        }
        // 1b) TIMER / RELOJ: secuencia de pings que ACELERA y SUBE de tono durante
        // el build-up. AHORA termina de subir en tRiseEnd (NO en tSpiralEnd), que es
        // PEAK_HOLD_TICKS ANTES de abrir la tapa. Asi la nota mas aguda se oye COMPLETA
        // y resuena antes del estallido, en vez de quedar cortada al abrirse la caja.
        if (this.soundStage == 1 && t > 2 && t < this.tRiseEnd) {
            final float p = Math.min(1.0f, (t - 2) / (float)Math.max(1, this.tRiseEnd - 2));
            final int interval = Math.max(2, Math.round(10.0f - p * 8.0f)); // 10 -> 2 ticks: acelera claro
            if (t - this.lastRiseTick >= interval) {
                this.lastRiseTick = t;
                this.playSpiralRise(cr, p);
            }
        }
        // 1c) NOTA PICO: al llegar a tRiseEnd, el "reloj" toca su nota MAS AGUDA y la
        // DEJA SONAR (sostenida) durante toda la ventana de resonancia antes de abrir.
        // Es la culminacion del build-up: clara, potente y SIN que la tapa la corte.
        if (this.soundStage == 1 && !this.peakPlayed && t >= this.tRiseEnd) {
            this.peakPlayed = true;
            this.playSpiralPeak(cr);
        }
        // 2) APERTURA: acento de "se abre la tapa" (el ESTALLIDO) al terminar el espiral.
        if (this.soundStage == 1 && t >= this.tSpiralEnd) {
            this.playOpenAccent(cr);
            this.soundStage = 2;
        }
        // 3) RULETA: tick LIMPIO y SUAVE por cada item que cruza el centro (estilo
        // CS:GO). Sin piano. La misma formula que el render -> perfectamente
        // sincronizado: rapidisimo al inicio y cada vez mas espaciado al frenar.
        if (this.soundStage >= 2 && t >= this.tOpenEnd && t < this.tSpinStop && !this.candidates.isEmpty()) {
            final float rp = this.revealProgress(0.0f);
            final int n = this.candidates.size();
            final int winner = Math.max(0, Math.min(n - 1, this.winnerIndex));
            final float maxTravel = reelTravel(n, winner);
            final int idx = (int)Math.floor(easeOutReel(Math.min(1.0f, rp)) * maxTravel);
            if (idx != this.lastReelIndex) {
                this.lastReelIndex = idx;
                final float pitch = 0.9f + rp * 0.7f; // sube de tono al acercarse al premio
                this.play(SoundEvents.UI_BUTTON_CLICK, 0.4f, pitch);
            }
        }
        // 4) VICTORIA: golpe SEGUN LA RAREZA del item ganado, justo al parar la ruleta
        // (mismo instante en que el servidor entrega el premio). Cola 4 ticks despues.
        if (t >= this.tSpinStop && this.soundStage >= 2 && this.soundStage < 60) {
            this.playWin(this.effectRarity);
            this.soundStage = 60;
            this.winTick = t;
            this.noteIndex = 0;
        }
        else if (this.soundStage == 60 && this.noteIndex == 0 && t - this.winTick >= 4) {
            this.playWinTail(this.effectRarity);
            this.noteIndex = 1;
        }
        // 5) CIERRE: sonido PROPIO de cada cofre cuando la tapa empieza a cerrarse
        // (tras los ~2.7s de hold mostrando el item).
        if (this.soundStage >= 60 && this.soundStage < 70 && t >= this.tHoldEnd) {
            this.playClose(cr);
            this.soundStage = 70;
        }
    }

    /**
     * Sonido de APERTURA con llave, PROPIO de cada cofre segun su tier. Cada rareza
     * tiene una identidad sonora completamente distinta al insertar la llave.
     * WARDEN_HEARTBEAT y ENDER_DRAGON_GROWL son EXCLUSIVOS del mitico.
     */
    private void playUnlock(final Rarity r) {
        switch (r) {
            case COMMON: {
                // Clic ligero: anchor suave + selector del faro
                this.play(SoundEvents.RESPAWN_ANCHOR_CHARGE, 0.5f, 1.4f);
                this.play(SoundEvents.BEACON_POWER_SELECT, 0.45f, 1.25f);
                break;
            }
            case RARE: {
                // Desbloqueo mistico-acuatico: conducto + encantamiento sutil
                this.play(SoundEvents.RESPAWN_ANCHOR_CHARGE, 0.55f, 1.2f);
                this.play(SoundEvents.CONDUIT_AMBIENT, 0.5f, 1.15f);
                this.play(SoundEvents.ENCHANTMENT_TABLE_USE, 0.4f, 1.1f);
                break;
            }
            case EPIC: {
                // Energia magica: evocador que siente la llave + faro que se activa
                this.play(SoundEvents.RESPAWN_ANCHOR_CHARGE, 0.6f, 1.1f);
                this.play(SoundEvents.BEACON_ACTIVATE, 0.5f, 1.0f);
                this.play(SoundEvents.EVOKER_PREPARE_ATTACK, 0.5f, 1.0f);
                break;
            }
            case LEGENDARY: {
                // Apertura heroica: cuerno de raid + trueno + faro. SIN warden ni dragon.
                this.play(SoundEvents.RESPAWN_ANCHOR_CHARGE, 0.6f, 0.9f);
                this.play(SoundEvents.BEACON_ACTIVATE, 0.55f, 0.9f);
                this.play(SoundEvents.RAID_HORN, 0.45f, 1.1f);
                this.play(SoundEvents.TRIDENT_THUNDER, 0.35f, 1.4f);
                break;
            }
            case MYTHIC: {
                // El unico con latido del warden + rugido del dragon: terror puro.
                this.play(SoundEvents.RESPAWN_ANCHOR_CHARGE, 0.6f, 0.7f);
                this.play(SoundEvents.CONDUIT_ACTIVATE, 0.55f, 0.8f);
                this.play(SoundEvents.WARDEN_HEARTBEAT, 0.55f, 0.85f);   // EXCLUSIVO mitico
                this.play(SoundEvents.ENDER_DRAGON_GROWL, 0.4f, 0.9f);   // EXCLUSIVO mitico
                break;
            }
        }
    }

    /**
     * Sonido de CARGA del espiral epico (suena al inicio, mientras el vortice de
     * particulas sube alrededor del cofre). Es un "whoosh"/energia que crece y
     * se hace mas grande e imponente cuanto mayor es la rareza del cofre.
     */
    private void playSpiralCharge(final Rarity r) {
        // Energia que carga, sin bloques musicales. Crece con la rareza.
        switch (r) {
            case COMMON: {
                this.play(SoundEvents.RESPAWN_ANCHOR_CHARGE, 0.45f, 1.5f);
                break;
            }
            case RARE: {
                this.play(SoundEvents.RESPAWN_ANCHOR_CHARGE, 0.5f, 1.35f);
                this.play(SoundEvents.BEACON_POWER_SELECT, 0.4f, 1.3f);
                break;
            }
            case EPIC: {
                this.play(SoundEvents.RESPAWN_ANCHOR_CHARGE, 0.55f, 1.2f);
                this.play(SoundEvents.BEACON_ACTIVATE, 0.5f, 1.1f);
                this.play(SoundEvents.EVOKER_CAST_SPELL, 0.4f, 1.1f);
                break;
            }
            case LEGENDARY: {
                this.play(SoundEvents.RESPAWN_ANCHOR_CHARGE, 0.6f, 1.0f);
                this.play(SoundEvents.BEACON_ACTIVATE, 0.55f, 1.0f);
                this.play(SoundEvents.EVOKER_CAST_SPELL, 0.45f, 0.9f);
                break;
            }
            case MYTHIC: {
                this.play(SoundEvents.RESPAWN_ANCHOR_CHARGE, 0.6f, 0.85f);
                this.play(SoundEvents.CONDUIT_ACTIVATE, 0.6f, 1.0f);
                this.play(SoundEvents.ENDER_DRAGON_GROWL, 0.4f, 1.2f);
                this.play(SoundEvents.WARDEN_HEARTBEAT, 0.45f, 0.9f);
                break;
            }
        }
    }

    /**
     * TIMER de tension durante el espiral, ANTES de abrir la tapa. Va de MENOR a
     * MAYOR: el tono y el volumen suben con el progreso 'p' (0..1) y la cadencia
     * ACELERA (ver advanceSounds).
     *
     * CADA rareza tiene su propio "instrumento" para que las secuencias sean
     * completamente distintas entre si. El pitch maximo esta CAPADO por rareza
     * (nunca llega a 2.0) para evitar que el sonido quede tan corto que parezca
     * cortado. En los ultimos tramos se agrega un complemento con mas sustain
     * para mantener la tension audible incluso en el instante mas agudo.
     */
    private void playSpiralRise(final Rarity r, final float p) {
        final float vol = Math.min(1.0f, 0.45f + p * 0.55f);
        switch (r) {
            case COMMON: {
                // Selector de faro clasico, tono capado a 1.55 (no se corta).
                final float pitch = Math.min(1.55f, 0.55f + p * 1.0f);
                this.play(SoundEvents.BEACON_POWER_SELECT, vol * 0.85f, pitch);
                break;
            }
            case RARE: {
                // Mesa de encantar: mistico y acuatico. Cap 1.50.
                final float pitch = Math.min(1.50f, 0.55f + p * 0.95f);
                this.play(SoundEvents.ENCHANTMENT_TABLE_USE, vol, pitch);
                // Capa de conducto cuando ya esta bien avanzado: sustain acuatico
                if (p > 0.55f) {
                    this.play(SoundEvents.CONDUIT_AMBIENT, vol * 0.30f, 0.85f + p * 0.40f);
                }
                break;
            }
            case EPIC: {
                // Encantamiento + evocador: magia acelerando. Cap 1.50.
                final float pitch = Math.min(1.50f, 0.50f + p * 1.0f);
                this.play(SoundEvents.ENCHANTMENT_TABLE_USE, vol, pitch);
                // El evocador siente la energia acumularse
                if (p > 0.30f) {
                    this.play(SoundEvents.EVOKER_CAST_SPELL, vol * (0.10f + p * 0.35f), 0.60f + p * 0.60f);
                }
                // Refuerzo final para no quedar cortado: conducto que se despierta
                if (p > 0.80f) {
                    this.play(SoundEvents.CONDUIT_ACTIVATE, vol * 0.40f, 0.85f + p * 0.30f);
                }
                break;
            }
            case LEGENDARY: {
                // Pulso bajo del faro (mas grave = mas epico). Cap 1.25.
                final float pitch = Math.min(1.25f, 0.40f + p * 0.85f);
                this.play(SoundEvents.BEACON_POWER_SELECT, vol, pitch);
                // Carga sonica del warden aparece a mitad del build-up
                if (p > 0.35f) {
                    this.play(SoundEvents.WARDEN_SONIC_CHARGE, 0.15f + p * 0.25f, 0.70f + p * 0.45f);
                }
                // Cuerno que asoma al final, presagiando el estallido heroico
                if (p > 0.75f) {
                    this.play(SoundEvents.RAID_HORN, vol * 0.28f, 0.72f + p * 0.32f);
                }
                break;
            }
            case MYTHIC: {
                // El mas grave y ominoso: pulso profundo + latido del warden. Cap 1.05.
                final float pitch = Math.min(1.05f, 0.30f + p * 0.75f);
                this.play(SoundEvents.BEACON_POWER_SELECT, vol, pitch);
                // Latido del warden acelerando (el warden despierta)
                if (p > 0.20f) {
                    this.play(SoundEvents.WARDEN_HEARTBEAT, vol * (0.20f + p * 0.40f), 0.55f + p * 0.50f);
                }
                // Carga sonica del warden en la segunda mitad
                if (p > 0.50f) {
                    this.play(SoundEvents.WARDEN_SONIC_CHARGE, 0.20f + p * 0.25f, 0.65f + p * 0.45f);
                }
                // Murmuro del dragon justo antes del estallido: el dragon despierta
                if (p > 0.88f) {
                    this.play(SoundEvents.ENDER_DRAGON_GROWL, 0.18f, 1.2f);
                }
                break;
            }
        }
    }

    /**
     * NOTA PICO del "reloj": la culminacion mas AGUDA del build-up, sostenida durante
     * la ventana de resonancia (PEAK_HOLD_TICKS) ANTES de que la tapa se abra. Cada
     * rareza tiene su propia nota pico, con sustain (campana/cuerno/carga) para que
     * resuene CLARA y COMPLETA y no la pise el estallido. Mas epica segun el tier.
     */
    private void playSpiralPeak(final Rarity r) {
        switch (r) {
            case COMMON: {
                // Campana cristalina aguda que tintinea.
                this.play(SoundEvents.BELL_BLOCK, 0.7f, 1.9f);
                this.play(SoundEvents.BEACON_POWER_SELECT, 0.6f, 1.6f);
                break;
            }
            case RARE: {
                // Campana + conducto que se eleva: brillo mistico sostenido.
                this.play(SoundEvents.BELL_BLOCK, 0.75f, 1.7f);
                this.play(SoundEvents.CONDUIT_ACTIVATE, 0.55f, 1.5f);
                this.play(SoundEvents.ENCHANTMENT_TABLE_USE, 0.6f, 1.55f);
                break;
            }
            case EPIC: {
                // Campana grave + carga del evocador: la magia llega a su tope.
                this.play(SoundEvents.BELL_BLOCK, 0.8f, 1.5f);
                this.play(SoundEvents.ENCHANTMENT_TABLE_USE, 0.65f, 1.35f);
                this.play(SoundEvents.EVOKER_CAST_SPELL, 0.6f, 1.3f);
                this.play(SoundEvents.CONDUIT_ACTIVATE, 0.55f, 1.35f);
                break;
            }
            case LEGENDARY: {
                // Campana profunda + carga sonica del warden sostenida + cuerno tenue:
                // tension maxima retenida justo antes de estallar.
                this.play(SoundEvents.BELL_BLOCK, 0.85f, 1.3f);
                this.play(SoundEvents.WARDEN_SONIC_CHARGE, 0.6f, 1.25f);
                this.play(SoundEvents.RAID_HORN, 0.5f, 1.1f);
                this.play(SoundEvents.BEACON_ACTIVATE, 0.6f, 1.4f);
                break;
            }
            case MYTHIC: {
                // La nota pico MAS imponente: campana grave + carga sonica + latido del
                // warden acelerado + susurro del dragon. El clima absoluto del build-up.
                this.play(SoundEvents.BELL_BLOCK, 0.9f, 1.15f);
                this.play(SoundEvents.WARDEN_SONIC_CHARGE, 0.7f, 1.1f);
                this.play(SoundEvents.WARDEN_HEARTBEAT, 0.6f, 1.2f);    // EXCLUSIVO mitico
                this.play(SoundEvents.ENDER_DRAGON_GROWL, 0.45f, 1.25f); // EXCLUSIVO mitico
                break;
            }
        }
    }

    /**
     * Acento que suena cuando la TAPA se ABRE (justo despues del espiral). Cada
     * rareza tiene un estallido COMPLETAMENTE DISTINTO al resto. Reglas:
     *  - COMMON:  estallido contenido con campana cristalina
     *  - RARE:    detonacion acuatico-mistica, sin boom del warden
     *  - EPIC:    estallido magico con evocador (SIN dragon)
     *  - LEGENDARY: explosion heroica con cuerno de raid como firma (SIN dragon)
     *  - MYTHIC:  el mas imponente + ENDER_DRAGON_GROWL EXCLUSIVO (solo el mitico)
     */
    private void playOpenAccent(final Rarity r) {
        switch (r) {
            case COMMON: {
                // Estallido contenido pero con peso: explosion + boom suave + campana.
                this.play(SoundEvents.GENERIC_EXPLODE, 0.8f, 1.5f);
                this.play(SoundEvents.BEACON_ACTIVATE, 0.8f, 1.2f);
                this.play(SoundEvents.BEACON_POWER_SELECT, 0.6f, 1.6f);
                this.play(SoundEvents.BELL_BLOCK, 0.5f, 1.7f);         // destello cristalino
                break;
            }
            case RARE: {
                // Detonacion acuatico-mistica MAS grande: conducto + trueno + carga sonica
                // suave + encantamiento + explosion. SIN warden sonic boom (epico/legendario).
                this.play(SoundEvents.CONDUIT_ACTIVATE, 0.9f, 1.1f);
                this.play(SoundEvents.TRIDENT_THUNDER, 0.75f, 1.3f);
                this.play(SoundEvents.WARDEN_SONIC_CHARGE, 0.45f, 1.3f);
                this.play(SoundEvents.ENCHANTMENT_TABLE_USE, 0.6f, 1.2f);
                this.play(SoundEvents.GENERIC_EXPLODE, 0.75f, 1.35f);
                break;
            }
            case EPIC: {
                // Estallido magico MAS imponente: triple explosion + boom sonico + trueno
                // + evocador + faro. SIN dragon (eso es exclusivo del mitico).
                this.play(SoundEvents.GENERIC_EXPLODE, 1.0f, 1.0f);
                this.play(SoundEvents.GENERIC_EXPLODE, 0.75f, 1.18f);
                this.play(SoundEvents.GENERIC_EXPLODE, 0.55f, 0.85f);
                this.play(SoundEvents.WARDEN_SONIC_BOOM, 0.80f, 1.2f);
                this.play(SoundEvents.LIGHTNING_BOLT_THUNDER, 0.70f, 1.1f);
                this.play(SoundEvents.EVOKER_CAST_SPELL, 0.55f, 0.95f);
                this.play(SoundEvents.BEACON_ACTIVATE, 0.6f, 1.25f);
                break;
            }
            case LEGENDARY: {
                // Explosion heroica: triple impacto + cuerno de raid (firma del legendary)
                // + truenos + beacon. SIN ENDER_DRAGON_GROWL (exclusivo del mitico).
                this.play(SoundEvents.GENERIC_EXPLODE, 1.0f, 0.88f);
                this.play(SoundEvents.GENERIC_EXPLODE, 0.9f, 1.05f);
                this.play(SoundEvents.GENERIC_EXPLODE, 0.7f, 1.22f);
                this.play(SoundEvents.WARDEN_SONIC_BOOM, 1.0f, 1.0f);
                this.play(SoundEvents.LIGHTNING_BOLT_THUNDER, 0.9f, 1.0f);
                this.play(SoundEvents.TRIDENT_THUNDER, 0.75f, 1.15f);
                this.play(SoundEvents.RAID_HORN, 0.85f, 1.0f);         // la firma del legendary
                this.play(SoundEvents.BEACON_ACTIVATE, 0.65f, 1.2f);
                break;
            }
            case MYTHIC: {
                // El estallido MAS imponente: cuadruple explosion + warden + DRAGON EXCLUSIVO.
                // ENDER_DRAGON_GROWL solo aqui: si lo oyes, es el mitico.
                this.play(SoundEvents.GENERIC_EXPLODE, 1.0f, 0.7f);
                this.play(SoundEvents.GENERIC_EXPLODE, 1.0f, 0.92f);
                this.play(SoundEvents.GENERIC_EXPLODE, 0.85f, 1.15f);
                this.play(SoundEvents.WARDEN_SONIC_BOOM, 1.0f, 0.85f);
                this.play(SoundEvents.WARDEN_ROAR, 0.8f, 1.0f);
                this.play(SoundEvents.LIGHTNING_BOLT_THUNDER, 1.0f, 0.95f);
                this.play(SoundEvents.ENDER_DRAGON_GROWL, 0.85f, 0.9f); // EXCLUSIVO mitico
                this.play(SoundEvents.RAID_HORN, 0.8f, 0.82f);
                break;
            }
        }
    }

    /**
     * Golpe de victoria segun la RAREZA del item ganado. Cada rareza suena distinto.
     * ENDER_DRAGON_GROWL es EXCLUSIVO del mitico en toda la secuencia de sonidos.
     * Suena en el instante exacto en que para la ruleta y se entrega el premio.
     */
    private void playWin(final Rarity r) {
        switch (r) {
            case COMMON: {
                // Victoria sencilla: selector + activacion del faro.
                this.play(SoundEvents.BEACON_POWER_SELECT, 0.6f, 1.5f);
                this.play(SoundEvents.BEACON_ACTIVATE, 0.5f, 1.3f);
                break;
            }
            case RARE: {
                // Victoria mistica: faro + conducto + encantamiento.
                this.play(SoundEvents.BEACON_ACTIVATE, 0.65f, 1.2f);
                this.play(SoundEvents.CONDUIT_ACTIVATE, 0.55f, 1.3f);
                this.play(SoundEvents.ENCHANTMENT_TABLE_USE, 0.5f, 1.2f);
                break;
            }
            case EPIC: {
                // Victoria magica: encantamiento + conducto + evocador + faro.
                this.play(SoundEvents.ENCHANTMENT_TABLE_USE, 0.7f, 1.0f);
                this.play(SoundEvents.CONDUIT_ACTIVATE, 0.6f, 1.2f);
                this.play(SoundEvents.EVOKER_CAST_SPELL, 0.55f, 1.1f);
                this.play(SoundEvents.BEACON_ACTIVATE, 0.55f, 1.3f);
                break;
            }
            case LEGENDARY: {
                // Victoria heroica: cuerno de raid (firma) + truenos + boom sonico + faro.
                // SIN ENDER_DRAGON_GROWL: eso es EXCLUSIVO del mitico.
                this.play(SoundEvents.RAID_HORN, 0.85f, 0.95f);
                this.play(SoundEvents.LIGHTNING_BOLT_THUNDER, 0.80f, 1.0f);
                this.play(SoundEvents.TRIDENT_THUNDER, 0.70f, 1.2f);
                this.play(SoundEvents.WARDEN_SONIC_BOOM, 0.55f, 1.1f);
                this.play(SoundEvents.BEACON_ACTIVATE, 0.75f, 1.3f);
                this.play(SoundEvents.CONDUIT_ACTIVATE, 0.60f, 1.1f);
                break;
            }
            case MYTHIC: {
                // Victoria APOTEOSICA: RUGIDO del dragon EXCLUSIVO + warden + cuerno + trueno.
                this.play(SoundEvents.ENDER_DRAGON_GROWL, 0.95f, 1.0f);   // EXCLUSIVO mitico
                this.play(SoundEvents.WARDEN_SONIC_BOOM, 0.85f, 0.95f);
                this.play(SoundEvents.WARDEN_ROAR, 0.7f, 1.0f);
                this.play(SoundEvents.RAID_HORN, 0.8f, 0.85f);
                this.play(SoundEvents.LIGHTNING_BOLT_THUNDER, 0.8f, 1.1f);
                this.play(SoundEvents.BEACON_ACTIVATE, 0.8f, 1.1f);
                break;
            }
        }
    }

    /** Cola (4 ticks despues del golpe): segunda ola que refuerza la epicidad SIN
     *  fuegos, exp, amatista ni bloques musicales. */
    private void playWinTail(final Rarity r) {
        switch (r) {
            case COMMON: {
                this.play(SoundEvents.BEACON_POWER_SELECT, 0.45f, 1.8f);
                break;
            }
            case RARE: {
                this.play(SoundEvents.BEACON_POWER_SELECT, 0.5f, 1.7f);
                this.play(SoundEvents.CONDUIT_AMBIENT, 0.4f, 1.3f);
                break;
            }
            case EPIC: {
                this.play(SoundEvents.ENCHANTMENT_TABLE_USE, 0.5f, 1.3f);
                this.play(SoundEvents.CONDUIT_AMBIENT, 0.45f, 1.2f);
                break;
            }
            case LEGENDARY: {
                this.play(SoundEvents.TRIDENT_THUNDER, 0.6f, 1.2f);
                this.play(SoundEvents.RAID_HORN, 0.5f, 1.05f);
                this.play(SoundEvents.BEACON_ACTIVATE, 0.5f, 1.5f);
                break;
            }
            case MYTHIC: {
                this.play(SoundEvents.ENDER_DRAGON_GROWL, 0.65f, 1.3f);
                this.play(SoundEvents.WARDEN_ROAR, 0.5f, 1.1f);
                this.play(SoundEvents.LIGHTNING_BOLT_THUNDER, 0.55f, 1.25f);
                break;
            }
        }
    }

    /**
     * Sonido de CIERRE de la tapa, PROPIO de cada cofre segun su tier. Suena tras
     * el "hold" (cuando el jugador ya pudo ver el item) y acompana la animacion de
     * cierre. SIN sonidos de puerta ni de cofre vanilla: usa un "sellado" energetico
     * (faro/conducto que se apagan) + un golpe grave, mas imponente segun la rareza.
     */
    private void playClose(final Rarity r) {
        // Sellado energetico que se apaga. SIN fuegos, amatista ni bloques musicales.
        switch (r) {
            case COMMON: {
                this.play(SoundEvents.BEACON_DEACTIVATE, 0.5f, 1.1f);
                break;
            }
            case RARE: {
                this.play(SoundEvents.BEACON_DEACTIVATE, 0.5f, 1.0f);
                this.play(SoundEvents.CONDUIT_DEACTIVATE, 0.4f, 1.2f);
                break;
            }
            case EPIC: {
                this.play(SoundEvents.BEACON_DEACTIVATE, 0.55f, 1.0f);
                this.play(SoundEvents.CONDUIT_DEACTIVATE, 0.45f, 0.9f);
                break;
            }
            case LEGENDARY: {
                this.play(SoundEvents.CONDUIT_DEACTIVATE, 0.55f, 0.95f);
                this.play(SoundEvents.BEACON_DEACTIVATE, 0.5f, 0.85f);
                break;
            }
            case MYTHIC: {
                this.play(SoundEvents.CONDUIT_DEACTIVATE, 0.55f, 0.9f);
                this.play(SoundEvents.WARDEN_HEARTBEAT, 0.45f, 0.8f);
                this.play(SoundEvents.ENDER_DRAGON_GROWL, 0.4f, 0.85f);
                break;
            }
        }
    }
    
    private void play(final SoundEvent sound, final float vol, final float pitch) {
        if (this.level == null || sound == null) {
            return;
        }
        this.level.playLocalSound(this.worldPosition.getX() + 0.5, this.worldPosition.getY() + 0.5, this.worldPosition.getZ() + 0.5, sound, SoundSource.BLOCKS, vol, pitch, false);
    }

    /**
     * Overload que acepta sonidos envueltos en Holder (p.ej. los NOTE_BLOCK_* y
     * UI_BUTTON_CLICK lo son en 1.20.1). Permite referirlos sin .value() y hace
     * que el codigo compile sea cual sea su tipo exacto en el mapping.
     */
    private void play(final net.minecraft.core.Holder<SoundEvent> sound, final float vol, final float pitch) {
        if (sound != null) {
            this.play((SoundEvent)sound.value(), vol, pitch);
        }
    }
    
    private static float easeOutBack(final float t) {
        final float c1 = 1.70158f;
        final float c2 = c1 + 1.0f;
        final float x = t - 1.0f;
        return 1.0f + c2 * x * x * x + c1 * x * x;
    }
    
    private static float easeInOut(final float t) {
        return (t < 0.5f) ? (2.0f * t * t) : (1.0f - (float)Math.pow(-2.0f * t + 2.0f, 2.0) / 2.0f);
    }

    /** Curva de desaceleracion COMPARTIDA por la ruleta (render del carrusel + sonido).
     *  easeOutQuart: arranca rapidisima y se ARRASTRA mas al final, de modo que la
     *  ruleta pasa LENTA por los ultimos items y crea tension antes de parar en el
     *  premio. Combinada con REEL_STEPS (distancia fija) mantiene una velocidad
     *  inicial consistente sin importar cuantos items haya. */
    public static float easeOutReel(final float t) {
        final float x = 1.0f - t;
        return 1.0f - x * x * x * x; // quart: cola lenta = mas tension al final
    }

    /**
     * Distancia total (en items) que recorre la ruleta para esta apertura. Es ~fija
     * (REEL_STEPS) -> misma velocidad con pocos o muchos items, y garantiza que el
     * centro caiga EXACTAMENTE en el premio: maxTravel ≡ winner (mod n).
     * La usan render y sonido por igual (perfectamente sincronizados).
     */
    public static float reelTravel(final int n, final int winner) {
        if (n <= 0) {
            return REEL_STEPS;
        }
        return REEL_STEPS + Math.floorMod(winner - REEL_STEPS, n);
    }
    
    protected void saveAdditional(final CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("config", (Tag)this.config.save());
    }
    
    public void load(final CompoundTag tag) {
        super.load(tag);
        if (tag.contains("config")) {
            this.config = CrateConfig.load(tag.getCompound("config"));
            this.animColor = this.config.rarity.rgb();
        }
    }
    
    public CompoundTag getUpdateTag() {
        final CompoundTag tag = super.getUpdateTag();
        tag.put("config", (Tag)this.config.save());
        return tag;
    }
    
    public void handleUpdateTag(final CompoundTag tag) {
        super.handleUpdateTag(tag);
        if (tag.contains("config")) {
            this.config = CrateConfig.load(tag.getCompound("config"));
            this.animColor = this.config.rarity.rgb();
        }
    }
    
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return (Packet<ClientGamePacketListener>)ClientboundBlockEntityDataPacket.create((BlockEntity)this);
    }
    
    public void onDataPacket(final Connection net, final ClientboundBlockEntityDataPacket pkt) {
        final CompoundTag tag = pkt.getTag();
        if (tag != null && tag.contains("config")) {
            this.config = CrateConfig.load(tag.getCompound("config"));
            this.animColor = this.config.rarity.rgb();
        }
    }
    
    public static List<ItemStack> decodeItems(final CompoundTag wrap) {
        final List<ItemStack> out = new ArrayList<ItemStack>();
        if (wrap == null) {
            return out;
        }
        final ListTag list = wrap.getList("items", 10);
        for (int i = 0; i < list.size(); ++i) {
            out.add(ItemStack.of(list.getCompound(i)));
        }
        return out;
    }
}
