// 
// FSCrates - Varita del Editor: click derecho sobre un cofre para editarlo en sitio.
// 

package com.fscrates.item;

import net.minecraft.ChatFormatting;
import net.minecraft.world.item.TooltipFlag;
import java.util.List;
import org.jetbrains.annotations.Nullable;
import net.minecraft.world.level.Level;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

/**
 * Varita de administracion: al hacer click derecho con ella sobre un cofre de
 * FSCrates, abre el EDITOR de ESE cofre directamente (lo gestiona CrateBlock.use).
 * No tiene logica de uso propia para no interferir con la interaccion del bloque.
 */
public class EditorWandItem extends Item
{
    public EditorWandItem() {
        super(new Item.Properties().stacksTo(1).rarity(net.minecraft.world.item.Rarity.EPIC));
    }
    
    public Component getName(final ItemStack stack) {
        return (Component)Component.literal("\u2726 Varita del Editor \u2726").withStyle(ChatFormatting.LIGHT_PURPLE);
    }
    
    public boolean isFoil(final ItemStack stack) {
        return true;
    }
    
    public void appendHoverText(final ItemStack stack, @Nullable final Level level, final List<Component> tooltip, final TooltipFlag flag) {
        tooltip.add((Component)Component.literal("Click derecho sobre un cofre para EDITARLO en el sitio.").withStyle(ChatFormatting.GRAY));
        tooltip.add((Component)Component.literal("Los cambios se aplican a ese cofre sin duplicar items.").withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add((Component)Component.literal("Solo administradores.").withStyle(ChatFormatting.DARK_GRAY));
    }
}
